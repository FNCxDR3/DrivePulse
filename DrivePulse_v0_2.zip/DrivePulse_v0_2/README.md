# DrivePulse – Version 0.2 (GPS + automatische Tempolimit-Erkennung)

**Status:** Funktionsfähiges Quellcode-Konzept mit implementierter GPS-/OSM-Verknüpfung und automatischen Logiktests. **Noch nicht als iPhone-App gebaut, nicht auf realen Fahrten getestet und nicht als verlässliches Tempolimit-System freigegeben.**

## Neu in 0.2

- **Keine manuelle Tempolimit-Auswahl mehr.** Sobald der GPS-Zugriff aktiv ist, fragt die App Straßenobjekte der Umgebung bei OpenStreetMap über die öffentliche Overpass-API ab.
- Verknüpft das aktuelle GPS-Signal mit dem geometrisch nächstgelegenen passenden Straßenabschnitt, unter Berücksichtigung von Fahrt-/Straßenrichtung und GPS-Genauigkeit.
- Zeigt, wenn ausreichend eindeutig: **hinterlegtes Tempolimit und Straßenname** auf Tacho und Karte.
- Berechnet dazu **den simulierten deutschen Pkw-Bußgeld-Regelsatz** anhand der *gemessenen* GPS-Geschwindigkeit und der *aus der Karte abgeleiteten* Begrenzung.
- Wenn aus dem Straßen-Datensatz nicht eindeutig hervorgeht, ob der Abschnitt innerorts oder außerorts liegt, werden **beide möglichen Beträge** angezeigt – statt ohne Grundlage eine Lage anzunehmen.
- Zeigt **„Unbekannt“** bei fehlenden OSM-Daten, unklarer Fahrtrichtung, schlechtem GPS, konkurrierenden Straßen oder zeitlich/dynamisch bedingten Limits.
- Berücksichtigt `maxspeed`, einige deutsche implizite Tag-Werte, `maxspeed:motorcar`, `maxspeed:forward/backward` und `maxspeed=none`. Erkennt `maxspeed:conditional`/variable Grenzen als *nicht zuverlässig automatisch bestimmbar*, statt deren Basiswert zu behaupten.
- Begrenzt externe Abfragen bewusst (ca. max. eine pro 30 s, nur bei ausreichend genauer Position und nach Ortsänderung; dynamische Geometrie für dazwischenliegende Straßen). **Das ist keine lückenlose Echtzeit-Datenerkennung.**

## Bestehende Funktionen aus 0.1

- Kartenansicht ohne Zielführung, GPS-Tacho, manuell gestartete Fahrtaufzeichnung, Gesamtkilometer, Fahrzeit, Höchst-/Durchschnittsgeschwindigkeit, lokale Fahrtenliste.
- Hintergrund-GPS für **bereits gestartete** Fahrten bei gesperrtem Smartphone in einem eigenen iOS/Android-Build und mit Berechtigung; **nicht in Expo Go**.
- Grundlegende GPS-Ausreißerfilter, Statistik „Heute/Woche/Monat/Gesamt“.
- Freunde und Community sind bislang Platzhalter – keine Cloud, keine sozialen Konten.

## Was 0.2 nicht zuverlässig kann

1. **Keine Echtzeitgarantie:** Ein mobiler GPS-Punkt identifiziert bei Kreuzungen, Auffahrten, Parallelstraßen und Brücken nicht sicher die richtige Straße. Auch OSM-Limits können fehlen/veraltet sein, Beschilderungen, variable LED-Schilder, Zusatzzeichen, Wetter oder Baustellen weichen ab.
2. **Kein vollständiger Kartenabgleich / keine kommerzielle Navigationsengine:** Der eingeschränkte, öffentliche Overpass-Dienst ist nur für *private Prototyp-Tests* gedacht. Im Alltag und für viele Nutzer ist ein dedizierter Speed-Limit-/Map-Matching-Dienst mit nutzungsbasiertem Vertrag oder ein eigener OSM-Dienst nötig. Bei schnellem Fahren können die Daten zwischen den Anfragen auslaufen: Dann zeigt die App bewusst „Unbekannt“.
3. **Keine garantierte Ortslagenkennung:** Falls OSM nicht eindeutig „DE:urban“, „DE:rural“ etc. taggt, werden zwei mögliche Pkw-Regelsätze („innerorts / außerorts“) angezeigt. Die Grenze geschlossener Ortschaften kann nicht allein anhand der Straßenart bestimmt werden.
4. **Bußgeld nur Simulation:** Keine Messgenauigkeit wie eine behördliche Messung. Kein Toleranzabzug, keine Gebühren/Auslagen, Vorsatz, Wiederholung, Sondertatbestände, besondere Fahrzeugklassen, Punkteregeln und Fahrverbotsregeln. Für Autos ohne Anhänger nach Tabelle 1 c BKatV.
5. **Nur während aktiver App-Nutzung wird das Tempolimit live aktualisiert.** Die separate, bereits gestartete GPS-Fahrtenaufzeichnung ist bei erteilter Berechtigung im Hintergrund vorgesehen. Automatischer Fahrtbeginn ohne Öffnen der App ist noch nicht implementiert.
6. **Keine Blitzer-Erkennung oder Blitzerwarnung** (nicht vorgesehen).

## Datenschutz und Datenübertragung

- **Fahrtenhistorie und GPS-Routen bleiben lokal** im AsyncStorage des Geräts, ohne zusätzliche Verschlüsselung.
- Für jede aktuelle **Online-Tempolimit-Abfrage wird die Standortkoordinate (auf sechs Dezimalstellen gerundet) an den Overpass-Betreiber übertragen.** Das entspricht einer hochpräzisen Standortangabe. Der Betreiber kann Anfragen protokollieren. Kein privater Login oder Fahrzeugprofil wird versendet.
- Keine Standortfreigabe an Freunde implementiert.
- **Wichtig:** Bei Erweiterung der App um einen eigenen Kartendienst müssen eine Transparenz-/Datenschutzoberfläche und Einwilligungs-/Berechtigungsregeln neu bewertet werden. Ein Widerruf der Standortberechtigung ist in den Geräteeinstellungen möglich.

## Installation des Quellcodes

1. ZIP in einer Entwicklungsumgebung oder GitHub Codespaces entpacken.
2. Node.js >= 22.13 bereitstellen und `npm install` ausführen.
3. `npx expo install --check` ausführen und bei Abweichungen `npx expo install --fix`.
4. Mit `npm start` beginnen; die App ist damit noch **nicht** automatisch auf dem iPhone installiert.
5. Für Hintergrund-GPS einen eigenen Entwicklungs-/Testbuild (z. B. EAS Build) erstellen und passende Standortberechtigungen erteilen; Expo Go unterstützt Hintergrund-Tracking nicht.
6. Bei Standortfreigabe und aktiver App wird der OSM-Request ausgelöst. Eine aktive Internetverbindung ist für die Tempolimitdaten erforderlich.

**Lokale Tests:** `npm run test:logic` – 14 Tests erfolgreich (7 vorhandene + 7 neue OSM-/GPS-Zuordnungstests). **Kein Gerätetest und kein EAS-Build erfolgt.** Im aktuellen Ausführungscontainer war die npm-Registry nicht erreichbar; deshalb konnten Abhängigkeiten nicht heruntergeladen und kein vollständiger TypeScript-/Native-Build durchgeführt werden.

## Quellen / technische Dokumentation

- OpenStreetMap: `maxspeed` https://wiki.openstreetmap.org/wiki/Key:maxspeed
- OpenStreetMap: `maxspeed:conditional` https://wiki.openstreetmap.org/wiki/Key:maxspeed:conditional
- Overpass offizielle API-Doku: https://dev.overpass-api.de/overpass-doc/de/full_data/polygon.html
- Overpass Nutzung/Resourcen: https://dev.overpass-api.de/overpass-doc/de/preface/commons.html
- BKatV Anlage Tabelle 1 c: https://www.gesetze-im-internet.de/bkatv_2013/anhang.html
- Expo Location: https://docs.expo.dev/versions/latest/sdk/location/

© OpenStreetMap-Mitwirkende, ODbL: https://www.openstreetmap.org/copyright
