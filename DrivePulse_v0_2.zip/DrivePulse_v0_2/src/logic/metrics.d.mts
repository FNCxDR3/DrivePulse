export type PointLike = { latitude: number; longitude: number; timestamp: number; accuracy: number; speed: number | null };
export function haversineMeters(a: Pick<PointLike, 'latitude' | 'longitude'>, b: Pick<PointLike, 'latitude' | 'longitude'>): number;
export function measureStep(previous: PointLike | undefined, current: PointLike): {distanceMeters: number; speedKmh: number} | null;
export function formatDuration(ms: number): string;
export function fineForCar(overKmh: number, innerorts: boolean): number;
