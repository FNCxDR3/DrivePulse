import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, AppState, Linking, Pressable, ScrollView,
  StatusBar, StyleSheet, Text, View, TextInput, Keyboard, Platform
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Marker, Polyline, type Region } from 'react-native-maps';
import { WebView } from 'react-native-webview';
import { LEAFLET_HTML } from './src/map/leafletHtml';
import * as Location from 'expo-location';
import * as Speech from 'expo-speech';
import * as TaskManager from 'expo-task-manager';
import { appendGPS, clearTrips, finishTrip, getTrips, setTrackingMode, startTrip } from './src/tracking/store';
import { LOCATION_TASK, toPoint } from './src/tracking/backgroundTask';
import type { GPSPoint, Trip, TripData } from './src/tracking/types';
import { fineForCar, sanctionForCar, formatDuration } from './src/logic/metrics.mjs';
import { matchSpeedLimit, pointDistanceMeters } from './src/speed/roadMatching.mjs';
import type { MatchedLimit, OsmRoad, RoadPoint } from './src/speed/roadMatching.mjs';
import { queryOsmRoads } from './src/speed/osmProvider';
import { searchDestinations, getDrivingRoute, type GeoDestination } from './src/navigation/providers';
import { routeProgress, maneuverInstruction, metersLabel, type DrivingRoute } from './src/navigation/routing.mjs';

const C = {
  bg: '#0B111D', panel: '#152235', panel2: '#1B2D45', border: '#2C4057',
  white: '#F8FAFD', muted: '#A2B6CB', accent: '#43DBC4', amber: '#FFBD68', red: '#FF747A'
};
const DEFAULT_REGION: Region = { latitude: 51.16, longitude: 10.45, latitudeDelta: 5, longitudeDelta: 5 };
const INITIAL_DATA: TripData = { active: null, trips: [] };
type Page = 'Karte' | 'Tacho' | 'Statistik' | 'Freunde' | 'Profil';
type Period = 'Heute' | 'Woche' | 'Monat' | 'Gesamt';

function fmtKm(meters: number) { return (meters / 1000).toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 }); }
function fmtSpeed(kmh: number) { return Math.round(Math.max(0, kmh)).toLocaleString('de-DE'); }
function fmtDate(date: number) { return new Date(date).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function elapsedMs(trip: Trip, now: number) { return Math.max(0, (trip.endedAt ?? now) - trip.startedAt); }
function calcMeanKmh(trip: Trip, now: number) { const hours = elapsedMs(trip, now) / 3600000; return hours > 0 ? trip.distanceMeters / 1000 / hours : 0; }
function withinPeriod(trip: Trip, period: Period, now: number) {
  const day = new Date(now); const start = new Date(day);
  if (period === 'Gesamt') return true;
  start.setHours(0, 0, 0, 0);
  if (period === 'Woche') start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  if (period === 'Monat') start.setDate(1);
  return trip.startedAt >= start.getTime();
}

function Chip({ children, active, onPress }: {children: React.ReactNode; active?: boolean; onPress: () => void}) {
  return <Pressable onPress={onPress} style={[styles.chip, active && styles.chipActive]}>
    <Text style={[styles.chipText, active && styles.chipTextActive]}>{children}</Text>
  </Pressable>;
}
function MainButton({ label, onPress, danger = false, disabled = false }: {label: string; onPress: () => void; danger?: boolean; disabled?: boolean}) {
  return <Pressable disabled={disabled} onPress={onPress} style={[styles.mainButton, danger && styles.dangerButton, disabled && {opacity: .5}]}>
    <Text style={[styles.mainButtonText, danger && {color: C.white}]}>{label}</Text>
  </Pressable>;
}
function Label({children}: {children: React.ReactNode}) { return <Text style={styles.label}>{children}</Text>; }
function Metric({ label, value, unit }: {label: string; value: string | number; unit?: string}) {
  return <View style={styles.metric}><Text style={styles.metricLabel}>{label}</Text>
    <View style={styles.metricNumber}><Text style={styles.metricValue}>{value}</Text>
      {!!unit && <Text style={styles.metricUnit}> {unit}</Text>}</View>
  </View>;
}
function Info({children}: {children: React.ReactNode}) { return <Text style={styles.info}>{children}</Text>; }

function DrivePulse() {
  const [page, setPage] = useState<Page>('Karte');
  const [data, setData] = useState<TripData>(INITIAL_DATA);
  const [pos, setPos] = useState<GPSPoint | null>(null);
  const [liveSpeed, setLiveSpeed] = useState<number | null>(null);
  const [gpsAccess, setGpsAccess] = useState(false);
  // Die native Kartenansicht kann in Expo Go leer bleiben. Ein vom MapKit-
  // Renderer unabhängiger WebView-Kartenmodus ermöglicht einen Vergleich.
  const [mapProvider, setMapProvider] = useState<'osm' | 'native'>(Platform.OS === 'ios' ? 'osm' : 'native');
  const [webMapReady, setWebMapReady] = useState(false);
  const [webMapError, setWebMapError] = useState('');
  const webMapRef = useRef<WebView>(null);
  const lastWebRouteRef = useRef<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [period, setPeriod] = useState<Period>('Woche');
  const [now, setNow] = useState(Date.now());
  const [limitState, setLimitState] = useState<MatchedLimit>({status:'unknown', reason:'GPS noch nicht aktiv'});
  const [checkingLimit, setCheckingLimit] = useState(false);
  const [destinationQuery, setDestinationQuery] = useState('');
  const [searchResults, setSearchResults] = useState<GeoDestination[]>([]);
  const [selectedDestination, setSelectedDestination] = useState<GeoDestination | null>(null);
  const [drivingRoute, setDrivingRoute] = useState<DrivingRoute | null>(null);
  const [navigationActive, setNavigationActive] = useState(false);
  const [followVehicle, setFollowVehicle] = useState(true);
  const [routeBusy, setRouteBusy] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [routeError, setRouteError] = useState('');
  const [searchBusy, setSearchBusy] = useState(false);
  const navigationRef = useRef<{active:boolean;destination:GeoDestination|null;route:DrivingRoute|null}>({active:false,destination:null,route:null});
  const rerouteRef = useRef({lastAt:0, offRouteSamples:0, running:false});
  const voicedStepRef = useRef('');
  const voiceEnabledRef = useRef(true);
  useEffect(() => {voiceEnabledRef.current = voiceEnabled; if (!voiceEnabled) void Speech.stop();}, [voiceEnabled]);
  const cameraLastAt = useRef(0);
  const mapRef = useRef<MapView>(null);
  const subscription = useRef<Location.LocationSubscription | null>(null);
  const activeRef = useRef<Trip | null>(null);
  const roadsCacheRef = useRef<{latitude:number;longitude:number;roads:OsmRoad[];at:number}|null>(null);
  const requestRef = useRef<{latitude:number;longitude:number;at:number}|null>(null);
  const requestRunningRef = useRef(false);
  const latestRoadPointRef = useRef<RoadPoint|null>(null);
  const mountedRef = useRef(true);

  const maybeReroute = useCallback((loc: Location.LocationObject) => {
    const nav = navigationRef.current;
    if (!nav.active || !nav.destination || !nav.route) return;
    if ((loc.coords.accuracy ?? 999) > 25) {rerouteRef.current.offRouteSamples = 0; return;}
    const progress = routeProgress(nav.route, loc.coords);
    if (!progress) return;
    const next = progress.nextStep;
    if (voiceEnabledRef.current && next && progress.nextStepDistanceMeters != null &&
        progress.nextStepDistanceMeters <= 300 && (loc.coords.speed ?? -1) >= 0 &&
        !progress.arrived) {
      const identity = `${next.type}:${next.location.latitude.toFixed(5)}:${next.location.longitude.toFixed(5)}`;
      if (voicedStepRef.current !== identity) {
        voicedStepRef.current = identity;
        const instruction = maneuverInstruction(next);
        const lead = progress.nextStepDistanceMeters > 45 ? `In etwa ${Math.round(progress.nextStepDistanceMeters / 10) * 10} Metern: ` : '';
        void Speech.stop().then(() => Speech.speak(lead + instruction, {language:'de-DE',rate:0.95})).catch(() => undefined);
      }
    }
    if (progress.arrived) return;
    if (progress.offRouteMeters > 75) rerouteRef.current.offRouteSamples++;
    else rerouteRef.current.offRouteSamples = 0;
    if (rerouteRef.current.offRouteSamples < 3 || rerouteRef.current.running || Date.now() - rerouteRef.current.lastAt < 45000) return;
    rerouteRef.current.running = true;
    rerouteRef.current.lastAt = Date.now();
    rerouteRef.current.offRouteSamples = 0;
    const dest = nav.destination;
    void getDrivingRoute(loc.coords, dest).then(r => {
      if (mountedRef.current && navigationRef.current.active && navigationRef.current.destination?.id === dest.id) {
        navigationRef.current.route = r;
        setDrivingRoute(r);
        setRouteError('Route nach Standortabweichung neu berechnet.');
      }
    }).catch(() => {if (mountedRef.current) setRouteError('Neuberechnung momentan nicht möglich.');})
      .finally(() => {rerouteRef.current.running = false;});
  }, []);

  useEffect(() => {
    if (page !== 'Karte' || !pos || !followVehicle) return;
    if (Date.now() - cameraLastAt.current < 1200) return;
    cameraLastAt.current = Date.now();
    mapRef.current?.animateCamera({center:{latitude:pos.latitude,longitude:pos.longitude},
      zoom: navigationActive ? 17 : 15, pitch: navigationActive ? 42 : 0,
      heading: navigationActive && pos.heading != null && pos.heading >= 0 && (pos.speed ?? 0) > 3.3 ? pos.heading : 0}, {duration:750});
  }, [page,pos,followVehicle,navigationActive]);

  // Live-Kartendaten werden nur bei App-Nutzung online abgefragt. Eine
  // bereits gestartete Fahrt zeichnet der separate Hintergrundtask lokal auf.
  // Die öffentliche Overpass-API ist lediglich eine Testdatenquelle; nach
  // mindestens 30 Sekunden erneut anfragen und aktuelle Position nie erraten.
  const updateAutoLimit = useCallback((loc: Location.LocationObject) => {
    const latest: RoadPoint = {
      latitude:loc.coords.latitude, longitude:loc.coords.longitude,
      accuracy:loc.coords.accuracy ?? 999,
      heading:loc.coords.heading,
      speedKmh:loc.coords.speed != null && loc.coords.speed >= 0 ? loc.coords.speed * 3.6 : null
    };
    latestRoadPointRef.current = latest;
    const cache = roadsCacheRef.current;
    const distance = cache ? pointDistanceMeters(latest, cache) : Infinity;
    if (cache && distance < 225 && Date.now() - cache.at < 300000) {
      setLimitState(matchSpeedLimit(cache.roads, latest));
    } else {
      setLimitState({status:'unknown',reason:'Für diesen Abschnitt keine aktuellen Kartendaten'});
    }
    // Nicht bei ungenauen GPS-Positionen oder parallel laufender Abfrage neu anfragen.
    if (latest.accuracy < 0 || latest.accuracy > 25 || requestRunningRef.current) return;
    const before = requestRef.current;
    const since = before ? Date.now() - before.at : Infinity;
    const changedRoadArea = !cache || distance >= 175 || Date.now() - cache.at > 300000;
    const moved = before ? pointDistanceMeters(latest, before) : Infinity;
    if (!changedRoadArea || (since < 30000) || (moved < 70 && since < 120000)) return;
    const at = Date.now();
    requestRef.current = {latitude:latest.latitude, longitude:latest.longitude, at};
    requestRunningRef.current = true;
    setCheckingLimit(true);
    void (async () => {
      try {
        const roads = await queryOsmRoads(latest.latitude, latest.longitude);
        if (!mountedRef.current) return;
        roadsCacheRef.current = {latitude:latest.latitude,longitude:latest.longitude,roads,at:Date.now()};
        const newest = latestRoadPointRef.current;
        if (newest && pointDistanceMeters(newest, latest) < 225) {
          setLimitState(matchSpeedLimit(roads, newest));
        } else {
          setLimitState({status:'unknown',reason:'Straßenabschnitt seit Abfrage gewechselt'});
        }
      } catch (e) {
        if (mountedRef.current) {
          roadsCacheRef.current = null;
          setLimitState({status:'unknown',reason:'Kartendienst nicht erreichbar oder Anfrage begrenzt'});
        }
      } finally {
        requestRunningRef.current = false;
        if (mountedRef.current) setCheckingLimit(false);
      }
    })();
  }, []);

  const refresh = useCallback(async () => {
    try {
      const restored = await getTrips();
      activeRef.current = restored.active;
      setData(restored);
      setNow(Date.now());
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Fahrtdaten können nicht geladen werden.');
    }
  }, []);

  const establishWatch = useCallback(async () => {
    if (subscription.current) return;
    subscription.current = await Location.watchPositionAsync({
      accuracy: Location.Accuracy.High, timeInterval: 1500, distanceInterval: 4
    }, async loc => {
      const point = toPoint(loc);
      setPos(point);
      setLiveSpeed(typeof point.speed === 'number' && point.speed >= 0 ? point.speed * 3.6 : null);
      updateAutoLimit(loc);
      maybeReroute(loc);
      // Nur im Vordergrund schreiben, FALLS kein Hintergrund-Task aktiv ist.
      if (activeRef.current?.mode === 'foreground') {
        try { await appendGPS(point); } catch (e) { console.warn('Fahrtdaten konnten nicht gespeichert werden', e); }
      }
    });
  }, [updateAutoLimit,maybeReroute]);

  useEffect(() => {
    mountedRef.current = true;
    let mounted = true;
    refresh();
    (async () => {
      const p = await Location.getForegroundPermissionsAsync();
      if (!mounted || p.status !== 'granted') return;
      setGpsAccess(true);
      try { await establishWatch(); } catch (e) { console.warn('GPS nicht verfügbar', e); }
    })();
    const refreshTimer = setInterval(() => { if (AppState.currentState === 'active') refresh(); }, 2500);
    const stateChange = AppState.addEventListener('change', state => { if (state === 'active') refresh(); });
    return () => {
      mounted = false;
      mountedRef.current = false;
      clearInterval(refreshTimer);
      stateChange.remove();
      subscription.current?.remove();
      subscription.current = null;
    };
  }, [refresh, establishWatch]);

  async function enableGPS() {
    try {
      setBusy(true); setError('');
      const result = await Location.requestForegroundPermissionsAsync();
      if (result.status !== 'granted') { setError('Standortzugriff fehlt. Du kannst ihn in den iPhone-Einstellungen aktivieren.'); return false; }
      setGpsAccess(true);
      await establishWatch();
      const cur = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setPos(toPoint(cur));
      setLiveSpeed(cur.coords.speed != null && cur.coords.speed >= 0 ? cur.coords.speed * 3.6 : null);
      updateAutoLimit(cur);
      return true;
    } catch (e) {
      setError('GPS konnte nicht gestartet werden. Prüfe die Standortdienste.');
      return false;
    } finally { setBusy(false); }
  }

  async function begin() {
    if (busy || data.active) return;
    const ok = gpsAccess || await enableGPS();
    if (!ok) return;
    try {
      setBusy(true); setError('');
      const trip = await startTrip();
      activeRef.current = trip;
      let mode: Trip['mode'] = 'foreground';
      try {
        const available = await TaskManager.isAvailableAsync();
        if (available) {
          const p = await Location.requestBackgroundPermissionsAsync();
          if (p.status === 'granted') {
            await Location.startLocationUpdatesAsync(LOCATION_TASK, {
              accuracy: Location.Accuracy.High,
              distanceInterval: 5,
              timeInterval: 2000,
              activityType: Location.ActivityType.AutomotiveNavigation,
              pausesUpdatesAutomatically: false,
              showsBackgroundLocationIndicator: true,
              foregroundService: {
                notificationTitle: 'DrivePulse zeichnet eine Fahrt auf',
                notificationBody: 'Tippe auf die App, um deine Fahrt zu beenden.',
                killServiceOnDestroy: false
              }
            });
            mode = 'background';
          }
        }
      } catch (e) {
        // Nicht verschleiern: Aufnahme läuft dann nur im Vordergrund weiter.
        setError('Hintergrund-GPS nicht verfügbar: Fahrt wird nur bei offener App erfasst.');
      }
      await setTrackingMode(mode);
      activeRef.current = {...trip, mode};
      if (mode === 'foreground') setError('Nur Vordergrund-Aufzeichnung aktiv. Für Hintergrund-GPS wird eine eigene App-Version und „Immer erlauben“ benötigt.');
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Fahrt konnte nicht gestartet werden.');
      await refresh();
    } finally { setBusy(false); }
  }

  async function stop() {
    if (busy) return;
    try {
      setBusy(true); setError('');
      // In Expo Go steht Hintergrund-Tracking nicht zur Verfügung; dann nichts stoppen.
      // Bei einer echten Hintergrundaufnahme muss der Dienst vor dem Abschluss stoppen.
      if (activeRef.current?.mode === 'background' &&
          await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK)) {
        await Location.stopLocationUpdatesAsync(LOCATION_TASK);
      }
      activeRef.current = null;
      await finishTrip();
      await refresh();
      setPage('Statistik');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Fahrt konnte nicht beendet werden.');
      await refresh();
    } finally { setBusy(false); }
  }

  function confirmStop() {
    Alert.alert('Fahrt beenden?', 'Deine bisherigen Kilometer werden lokal gespeichert.', [
      { text: 'Weiterfahren', style: 'cancel' },
      { text: 'Beenden', onPress: () => { void stop(); } }
    ]);
  }

  function confirmClear() {
    Alert.alert('Alle Fahrten löschen?', 'Diese Aktion kann nicht rückgängig gemacht werden.', [
      { text: 'Abbrechen', style: 'cancel' },
      { text: 'Unwiderruflich löschen', style: 'destructive', onPress: async () => {
        try { await clearTrips(); await refresh(); } catch (e) { setError(e instanceof Error ? e.message : 'Löschen fehlgeschlagen.'); }
      }}
    ]);
  }

  const active = data.active;
  const hasFreshGps = !!pos && now - pos.timestamp < 12000 && pos.accuracy <= 35;
  const speed = hasFreshGps ? (liveSpeed ?? 0) : 0;
  const freshSpeed = hasFreshGps ? liveSpeed : null;
  const knownLimit = limitState.status === 'known' ? limitState.kmh : null;
  const excess = knownLimit !== null && freshSpeed !== null ? freshSpeed - knownLimit : null;
  const fineUrban = excess !== null ? fineForCar(excess, true) : null;
  const fineRural = excess !== null ? fineForCar(excess, false) : null;
  const hasFine = excess !== null && excess >= 1;
  const sanction = hasFine && limitState.status === 'known' && limitState.context
    ? sanctionForCar(excess!, limitState.context === 'urban') : null;
  // In die WebView werden nur die notwendigen Sichtbarkeitsdaten übertragen.
  // Fahrtenhistorie bleibt auf dem Gerät; Kartenkacheln sind Online-Abfragen.
  useEffect(() => {
    if (page !== 'Karte' || mapProvider !== 'osm' || !webMapReady) return;
    const key = drivingRoute
      ? `${selectedDestination?.id ?? ''}:${drivingRoute.distanceMeters}:${drivingRoute.coordinates.length}` : '';
    const sendGeometry = lastWebRouteRef.current !== key;
    lastWebRouteRef.current = key;
    const payload = {
      gps: pos ? {lat:pos.latitude,lng:pos.longitude,heading:pos.heading ?? null} : null,
      dest: selectedDestination ? {lat:selectedDestination.latitude,lng:selectedDestination.longitude,
        name:selectedDestination.name.slice(0,120)} : null,
      follow: followVehicle && !sendGeometry,
      fitRoute: sendGeometry && !!drivingRoute && !navigationActive,
      route: sendGeometry ? (drivingRoute?.coordinates ?? []).map(p => [p.latitude,p.longitude]) : undefined,
      track: route.length >= 2 ? route.filter((_,i) => i % Math.max(1,Math.ceil(route.length/600)) === 0)
        .map(p=>[p.latitude,p.longitude]) : []
    };
    webMapRef.current?.injectJavaScript(`window.drivePulseUpdate(${JSON.stringify(payload)}); true;`);
  }, [webMapReady,page,mapProvider,pos,selectedDestination,drivingRoute,followVehicle,navigationActive,active?.distanceMeters]);
  const routeStatus = routeProgress(drivingRoute, hasFreshGps ? pos : null);
  const moving = (liveSpeed ?? 0) > 8 && hasFreshGps;
  const remainingTimeSeconds = routeStatus && drivingRoute?.distanceMeters
    ? drivingRoute.durationSeconds * Math.min(1,routeStatus.remainingMeters / drivingRoute.distanceMeters) : null;
  const fineText = !hasFine ? (excess === null ? '–' : '0 €') :
    limitState.status === 'known' && limitState.context === 'urban' ? `${fineUrban} €` :
    limitState.status === 'known' && limitState.context === 'rural' ? `${fineRural} €` :
    `${fineUrban} / ${fineRural} €`;
  const fineDescription = excess === null ? 'Keine verlässliche Berechnung möglich' :
    excess < 1 ? 'Kein berechneter Überschuss' :
    limitState.status === 'known' && limitState.context === null ?
      `+${Math.floor(excess)} km/h · innerorts / außerorts` :
      `+${Math.floor(excess)} km/h · ${limitState.status === 'known' && limitState.context === 'urban' ? 'innerorts' : 'außerorts'}`;
  const filtered = useMemo(() => data.trips.filter(t => withinPeriod(t, period, now)), [data.trips, period, now]);
  const totalMeters = filtered.reduce((sum, t) => sum + t.distanceMeters, 0);
  const totalMs = filtered.reduce((sum, t) => sum + elapsedMs(t, now), 0);
  const maxSpeed = Math.max(0, ...filtered.map(t => t.maxSpeedKmh));
  const avgSpeed = totalMs ? totalMeters / totalMs * 3600 : 0;
  const route = active?.points.map(p => ({ latitude: p.latitude, longitude: p.longitude })) ?? [];

  async function findDestination() {
    if (searchBusy || moving || navigationActive) return;
    Keyboard.dismiss(); setSearchBusy(true); setRouteError(''); setSearchResults([]);
    setDrivingRoute(null); setSelectedDestination(null); navigationRef.current = {active:false,destination:null,route:null};
    try {
      const matches = await searchDestinations(destinationQuery);
      setSearchResults(matches);
      if (!matches.length) setRouteError('Kein passendes Ziel gefunden. Versuche eine genauere Adresse.');
    } catch (e) {setRouteError(e instanceof Error ? e.message : 'Zielsuche derzeit nicht erreichbar.');}
    finally {setSearchBusy(false);}
  }

  async function chooseDestination(dest: GeoDestination) {
    if (moving || routeBusy) return;
    Keyboard.dismiss();setSearchResults([]);setSelectedDestination(dest);
    setDestinationQuery(dest.name.split(',').slice(0,2).join(','));setRouteError('');
    const current = pos;
    if (!current || !hasFreshGps) {
      setDrivingRoute(null);
      setRouteError('Für die Routenberechnung zunächst GPS aktivieren und ein aktuelles Signal abwarten.');
      return;
    }
    setRouteBusy(true);
    try {
      const result = await getDrivingRoute(current, dest);
      setDrivingRoute(result);
      navigationRef.current = {active:false,destination:dest,route:result};
      setFollowVehicle(false);
      setTimeout(() => mapRef.current?.fitToCoordinates(result.coordinates,
        {edgePadding:{top:145,right:45,bottom:240,left:45},animated:true}),250);
    } catch (e) {setDrivingRoute(null);setRouteError(e instanceof Error ? e.message : 'Route konnte nicht berechnet werden.');}
    finally {setRouteBusy(false);}
  }

  async function startNavigation() {
    if (routeBusy || !selectedDestination) return;
    setRouteBusy(true);setRouteError('');
    try {
      if (!gpsAccess && !await enableGPS()) throw new Error('Standortzugriff wird für die Navigation benötigt.');
      const current = await Location.getCurrentPositionAsync({accuracy:Location.Accuracy.High});
      if ((current.coords.accuracy ?? 999) > 45) throw new Error('GPS noch ungenau. Bitte draußen erneut versuchen.');
      const result = await getDrivingRoute(current.coords, selectedDestination);
      navigationRef.current = {active:true,destination:selectedDestination,route:result};
      voicedStepRef.current = '';
      rerouteRef.current = {lastAt:Date.now(),offRouteSamples:0,running:false};
      setDrivingRoute(result);setNavigationActive(true);setFollowVehicle(true);
    } catch (e) {setRouteError(e instanceof Error ? e.message : 'Navigation konnte nicht gestartet werden.');}
    finally {setRouteBusy(false);}
  }

  function stopNavigation() {
    navigationRef.current = {active:false,destination:null,route:null};
    voicedStepRef.current = '';
    void Speech.stop().catch(() => undefined);
    setNavigationActive(false);setDrivingRoute(null);setSelectedDestination(null);
    setSearchResults([]);setDestinationQuery('');setRouteError('');setFollowVehicle(true);
  }

  function mapContent() {
    return <View style={styles.mapContainer}>
      {mapProvider === 'osm' ? <WebView
        ref={webMapRef} style={StyleSheet.absoluteFillObject}
        originWhitelist={['*']}
        source={{html:LEAFLET_HTML,baseUrl:'https://github.com/FNCxDR3/DrivePulse/'}}
        javaScriptEnabled domStorageEnabled
        // Kennung für OSM-Testkacheln (keine Nutzung für den produktiven Verkehr).
        applicationNameForUserAgent="DrivePulsePrototype/0.3.1 (+https://github.com/FNCxDR3/DrivePulse)"
        onMessage={(event) => {
          const message = event.nativeEvent.data;
          if (message === 'ready') { lastWebRouteRef.current = null; setWebMapError(''); setWebMapReady(true); }
          else if (message === 'moved') setFollowVehicle(false);
          else if (message.startsWith('error:')) setWebMapError('Online-Karte konnte nicht geladen werden. Internetverbindung überprüfen oder zur iOS-Karte wechseln.');
        }}
        onError={() => setWebMapError('Kartenansicht nicht erreichbar. Bitte zum nativen Modus wechseln.')}
      /> : <MapView
        ref={mapRef} style={StyleSheet.absoluteFillObject}
        initialRegion={DEFAULT_REGION} showsUserLocation={gpsAccess}
        showsMyLocationButton={false} showsCompass mapType="standard"
        onPanDrag={()=>setFollowVehicle(false)}
      >
        {route.length > 1 && <Polyline coordinates={route} strokeColor="#22B9A2" strokeWidth={4} />}
        {!!drivingRoute && <Polyline coordinates={drivingRoute.coordinates} strokeColor="#327BF6" strokeWidth={7} />}
        {selectedDestination && <Marker coordinate={{latitude:selectedDestination.latitude,longitude:selectedDestination.longitude}} title={selectedDestination.name} pinColor="#327BF6"/>}
      </MapView>}
      <Pressable style={styles.mapModeButton} accessibilityRole="button"
        onPress={() => { setMapProvider(p => p === 'osm' ? 'native' : 'osm'); setWebMapReady(false);setWebMapError(''); }}>
        <Text style={styles.mapModeText}>{mapProvider === 'osm' ? 'OSM-Karte  ⇄' : 'iOS-Karte  ⇄'}</Text>
      </Pressable>
      {!!webMapError && <View pointerEvents="none" style={styles.mapDiagnostic}><Text style={styles.mapDiagnosticText}>{webMapError}</Text></View>}
      {mapProvider === 'osm' && !webMapReady && !webMapError &&
        <View pointerEvents="none" style={styles.mapLoading}><ActivityIndicator color={C.accent}/><Text style={styles.mapDiagnosticText}>Karte wird geladen …</Text></View>}
      {!navigationActive ? <View style={styles.searchCard}>
        <Text style={styles.searchTitle}>Wohin möchtest du fahren?</Text>
        <View style={styles.searchRow}>
          <TextInput style={styles.destinationInput} value={destinationQuery}
            onChangeText={setDestinationQuery} onSubmitEditing={()=>{void findDestination();}}
            placeholder="Adresse, Stadt oder Ziel" placeholderTextColor="#758BA6"
            returnKeyType="search" autoCorrect={false} editable={!moving && !searchBusy} />
          <Pressable accessibilityLabel="Ziel suchen" style={[styles.searchButton,(searchBusy || moving)&&{opacity:.5}]} disabled={searchBusy || moving} onPress={()=>{void findDestination();}}>
            <Text style={{fontWeight:'800',color:C.bg}}>{searchBusy?'…':'Suchen'}</Text>
          </Pressable>
        </View>
        {moving && <Text style={styles.mapDisclaimer}>Zieleingabe während der Fahrt gesperrt.</Text>}
        {searchResults.map(item => <Pressable key={item.id} onPress={()=>{void chooseDestination(item);}} style={styles.searchResult}>
          <Text style={styles.resultTitle} numberOfLines={2}>⌖ {item.name}</Text>
        </Pressable>)}
        {!!selectedDestination && <View style={styles.routeSummary}>
          <Text style={styles.routeDestination} numberOfLines={1}>Ziel: {selectedDestination.name}</Text>
          <Text style={styles.secondary}>{drivingRoute ? `${metersLabel(drivingRoute.distanceMeters)} · ca. ${Math.ceil(drivingRoute.durationSeconds/60)} Min. (ohne Verkehr)` : 'Route noch nicht verfügbar'}</Text>
          <MainButton label={routeBusy?'Route wird geladen…':'▶ Navigation starten'} disabled={routeBusy || !drivingRoute} onPress={()=>{void startNavigation();}} />
          <Pressable onPress={stopNavigation} style={{padding:6,alignSelf:'center'}}><Text style={styles.secondary}>Ziel entfernen</Text></Pressable>
        </View>}
        {!!routeError && <Text style={styles.mapError}>{routeError}</Text>}
        <Text style={styles.osmCredit}>Zielsuche: © OpenStreetMap/Nominatim · Routing: OSRM-Demo</Text>
      </View> : <View style={styles.navigationCard}>
        <Text style={styles.navigationEyebrow}>NAVIGATION LÄUFT</Text>
        <Text style={styles.navigationInstruction} numberOfLines={2}>{routeStatus?.arrived ? 'Ziel erreicht' : maneuverInstruction(routeStatus?.nextStep ?? null)}</Text>
        <Text style={styles.navigationDetail}>{routeStatus?.nextStepDistanceMeters != null ? `In ${metersLabel(routeStatus.nextStepDistanceMeters)}` : 'Der Route folgen'}</Text>
        <Text style={styles.navigationDetail}>{routeStatus ? `${metersLabel(routeStatus.remainingMeters)} verbleibend · ca. ${Math.ceil((remainingTimeSeconds ?? 0)/60)} Min.` : 'GPS-Signal abwarten'}</Text>
        {routeStatus?.arrived && <Text style={styles.navigationDetail}>Bitte die Navigation beenden, wenn du geparkt hast.</Text>}
        {!!routeError && <Text style={styles.mapError}>{routeError}</Text>}
        <View style={{flexDirection:'row',gap:8,marginTop:4}}>
          <Pressable onPress={()=>setVoiceEnabled(x=>!x)} style={[styles.stopNavButton,{flex:1,backgroundColor:C.panel2,marginTop:0}]}><Text style={{color:C.white,fontWeight:'800'}}>{voiceEnabled?'Ton an':'Ton aus'}</Text></Pressable>
          <Pressable onPress={stopNavigation} style={[styles.stopNavButton,{flex:2,marginTop:0}]}><Text style={{color:C.white,fontWeight:'800'}}>■ Beenden</Text></Pressable>
        </View>
      </View>}
      <View style={styles.mapFooter}>
        <View style={{flex: 1}}>
          <Text style={styles.metricLabel}>AKTUELLES TEMPO</Text>
          <Text style={styles.mapFooterSpeed}>{hasFreshGps ? fmtSpeed(speed) : '–'} <Text style={{fontSize: 16}}>km/h</Text></Text>
          <Text style={styles.mapSpeedLimit}>Tempolimit: {limitState.status === 'known' ? `${limitState.kmh} km/h` : limitState.status === 'unlimited' ? 'laut OSM ohne festes Limit*' : 'unbekannt'}</Text>
          <Text style={{color:hasFine?C.amber:C.muted,fontSize:13,fontWeight:'800',marginTop:4}}>Mögliche Geldbuße: {fineText}</Text>
        </View>
        <Pressable style={styles.roundButton} onPress={() => {
          setFollowVehicle(true);
          if (pos) mapRef.current?.animateCamera({center:{latitude:pos.latitude,longitude:pos.longitude},zoom:navigationActive?17:15,pitch:navigationActive?42:0},{duration:450});
          else void enableGPS();
        }}><Text style={{color:C.bg,fontSize:22}}>⌖</Text></Pressable>
      </View>
    </View>;
  }

  function speedContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <View style={styles.eyebrowRow}><Text style={styles.eyebrow}>LIVE FAHR-DASHBOARD</Text>
        <Text style={[styles.pill, {color: active ? C.accent : C.muted}]}>{active ? '● AUFZEICHNUNG' : '○ BEREIT'}</Text></View>
      <View style={styles.speedPanel}>
        <Text style={styles.metricLabel}>AKTUELLE GPS-GESCHWINDIGKEIT</Text>
        <Text style={[styles.hugeSpeed, {color: excess !== null && excess >= 3 ? C.red : C.white}]}>{hasFreshGps ? fmtSpeed(speed) : '–'}</Text>
        <Text style={styles.speedUnit}>km/h</Text>
        <View style={styles.separator}/>
        <View style={styles.pillRow}>
          <View style={{flex:1}}><Text style={styles.metricLabel}>ERKANNTES TEMPOLIMIT · ONLINE</Text>
            <Text style={styles.limitValue}>{knownLimit !== null ? `${knownLimit} km/h` : limitState.status === 'unlimited' ? 'Keine feste Grenze*' : 'Unbekannt'}</Text>
          </View>
          <Text style={styles.speedBadge}>{excess !== null && excess >= 1 ? `+${fmtSpeed(excess)} km/h` : checkingLimit ? '● Abfrage läuft' : '● Kartendaten'}</Text>
        </View>
        <Text style={styles.roadName}>{limitState.status !== 'unknown' ? limitState.roadName : (limitState.roadName ?? limitState.reason)}</Text>
        <Info>{checkingLimit ? 'Lade Straßeninformationen von OpenStreetMap …' : 'Automatische Zuordnung via GPS und OpenStreetMap. Fehlende oder widersprüchliche Daten werden nicht geschätzt.'}</Info>
      </View>
      <View style={[styles.finePanel, {borderColor: hasFine ? '#69373D' : C.border}]}>
        <View style={styles.pillRow}><Text style={styles.fineHeading}>BUẞGELD-SIMULATOR</Text><Text style={{color:hasFine ? C.red : C.accent}}>● SIMULATION</Text></View>
        <View style={styles.pillRow}><Text style={styles.fineValue}>{fineText}</Text><Text style={styles.fineDetail}>{fineDescription}</Text></View>
        {sanction && <Text style={styles.sanctionText}>{sanction.points ? `${sanction.points} Punkt${sanction.points > 1 ? 'e' : ''}` : 'Keine Punkte'} · {sanction.banMonths ? `${sanction.banMonths} Mon. Regelfahrverbot` : sanction.repeatBanPossible ? 'Fahrverbot bei Wiederholung möglich' : 'Kein Regelfahrverbot'}</Text>}
        <Info>Nur normale Pkw, Rohüberschreitung anhand GPS, ohne Mess-Toleranzabzug, Gebühren oder Einzelfälle. Keine geeichte Messung, keine Blitzer-Erkennung.</Info>
      </View>
      <Info>* Kartendaten können von Verkehrszeichen, Baustellen und zeitabhängigen Beschränkungen abweichen. Entscheidend sind immer die tatsächlichen Verkehrsregeln. Tempolimitdaten: © OpenStreetMap-Mitwirkende (ODbL).</Info>
      <View style={styles.columns}>
        <Metric label="STRECKE" value={fmtKm(active?.distanceMeters ?? 0)} unit="km" />
        <Metric label="FAHRZEIT" value={active ? formatDuration(elapsedMs(active, now)) : '0:00'} unit="h:min" />
      </View>
      <View style={styles.columns}>
        <Metric label="HÖCHSTWERT" value={fmtSpeed(active?.maxSpeedKmh ?? 0)} unit="km/h" />
        <Metric label="Ø GESCHW." value={active ? fmtSpeed(calcMeanKmh(active, now)) : '0'} unit="km/h" />
      </View>
      {!gpsAccess && <MainButton label="GPS aktivieren" disabled={busy} onPress={()=>{ void enableGPS(); }} />}
      <MainButton disabled={busy} danger={!!active} label={busy?'Bitte warten…':active?'■ Fahrt beenden':'+ Fahrt starten'} onPress={active?confirmStop:()=>{void begin();}} />
      {active && <Info>{active.mode === 'background' ? 'Hintergrund-Aufzeichnung angefordert. Bildschirm kann gesperrt werden; Betriebssystem kann Updates einschränken.' : 'Aufzeichnung nur bei geöffneter App. Für Hintergrund-GPS eigenen Build installieren und Berechtigung erteilen.'}</Info>}
    </ScrollView>;
  }

  function statsContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Deine Statistiken</Text>
      <Text style={styles.subtitle}>Alle Fahrten bleiben auf diesem Gerät gespeichert.</Text>
      <View style={styles.pillRow}>{(['Heute','Woche','Monat','Gesamt'] as Period[]).map(x => <Chip key={x} active={x===period} onPress={()=>setPeriod(x)}>{x}</Chip>)}</View>
      <View style={styles.columns}><Metric label="KILOMETER" value={fmtKm(totalMeters)} unit="km" /><Metric label="FAHRDAUER" value={formatDuration(totalMs)} unit="h:min" /></View>
      <View style={styles.columns}><Metric label="HÖCHSTGESCHW." value={fmtSpeed(maxSpeed)} unit="km/h" /><Metric label="Ø GESCHW." value={fmtSpeed(avgSpeed)} unit="km/h" /></View>
      <View style={styles.sectionRow}><Label>DEINE FAHRTEN</Label><Text style={styles.secondary}>{filtered.length} Fahrten</Text></View>
      {filtered.length === 0 ? <View style={styles.empty}><Text style={styles.emptyIcon}>↗</Text><Text style={styles.emptyTitle}>Noch keine Fahrten</Text><Text style={styles.secondary}>Starte deine erste Fahrt im Bereich „Tacho“.</Text></View>
        : filtered.map(t => <View key={t.id} style={styles.tripRow}>
          <View style={{flex:1}}><Text style={styles.tripHeading}>{fmtDate(t.startedAt)}</Text><Text style={styles.secondary}>{formatDuration(elapsedMs(t, now))} h:min · Spitze {fmtSpeed(t.maxSpeedKmh)} km/h</Text></View>
          <Text style={styles.tripDistance}>{fmtKm(t.distanceMeters)} km</Text>
        </View>)}
    </ScrollView>;
  }

  function friendsContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Freunde & Community</Text>
      <Text style={styles.subtitle}>Deine Fahrten bleiben privat, bis du etwas ausdrücklich freigibst.</Text>
      <View style={styles.empty}><Text style={styles.emptyIcon}>♧</Text>
        <Text style={styles.emptyTitle}>Freundesbereich in Planung</Text>
        <Text style={[styles.secondary,{textAlign:'center',lineHeight:21}]}>Freunde hinzufügen, Kilometer vergleichen, sichere Challenges und eine freiwillige Live-Freundeskarte sind für eine spätere Version vorgesehen.</Text>
      </View>
      <Label>DATENSCHUTZ</Label>
      <Info>Es existiert noch kein Benutzerkonto, kein Freundeserver und keine Standortübertragung. Andere können deine Fahrdaten in dieser Version nicht sehen.</Info>
    </ScrollView>;
  }

  function profileContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Einstellungen</Text>
      <Text style={styles.subtitle}>DrivePulse · Navigationstest 0.3.1</Text>
      <View style={styles.profileCard}>
        <Label>GPS & BERECHTIGUNGEN</Label>
        <Text style={styles.cardTitle}>{gpsAccess?'Standort freigegeben':'Standort nicht freigegeben'}</Text>
        <Info>Die manuell gestartete Aufzeichnung kann in einem eigenen Entwicklungs-Build mit „Immer erlauben“ bei gesperrtem Bildschirm weiterlaufen.</Info>
        <MainButton label="iPhone-Einstellungen öffnen" onPress={()=>{void Linking.openSettings();}} />
      </View>
      <View style={styles.profileCard}>
        <Label>DEINE DATEN</Label>
        <Text style={styles.cardTitle}>Lokal gespeicherte Fahrten</Text>
        <Info>{data.trips.length} abgeschlossene Fahrten. Gespeicherte Routen bleiben lokal. Zur automatischen Tempolimitabfrage wird die jeweilige aktuelle GPS-Position an den öffentlichen Overpass-Kartendienst übertragen. Der Betreiber kann Anfragen protokollieren. Die OSM-Webkarte lädt sichtbare Kartenkacheln von OpenStreetMap-Servern. Bei Zielsuche werden Suchbegriffe an Nominatim und bei Routenberechnung Start- und Zielposition an OSRM übertragen. Der Gerätespeicher ist nicht zusätzlich verschlüsselt.</Info>
        <Pressable disabled={!!active} onPress={confirmClear} style={[styles.deleteButton, !!active && {opacity:.35}]}><Text style={{color:C.red,fontWeight:'700'}}>Alle gespeicherten Fahrten löschen</Text></Pressable>
      </View>
      <View style={styles.profileCard}>
        <Label>PROJEKTSTATUS</Label>
        <Info>✓ GPS-Tacho, zwei Kartendarstellungen, Fahrtaufzeichnung, Statistiken</Info>
        <Info>△ Hintergrundaufzeichnung erst nach eigenem iOS/Android-Build testbar</Info>
        <Info>✓ Automatische Tempolimitabfrage aus OpenStreetMap (experimentell, nur bei aktiver App)</Info>
        <Info>△ Navigation mit OSRM-Testdienst, Zielsuche und experimentellen Sprachansagen; ohne Verkehrsdaten</Info>
        <Info>○ Automatischer Fahrtbeginn und Freunde folgen</Info>
      </View>
    </ScrollView>;
  }

  const tabs: {key:Page;icon:string}[] = [
    {key:'Karte',icon:'◇'}, {key:'Tacho',icon:'◉'}, {key:'Statistik',icon:'▥'},
    {key:'Freunde',icon:'♧'}, {key:'Profil',icon:'⚙'}
  ];

  return <SafeAreaView style={styles.safe} edges={['top','bottom']}>
    <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
    <View style={styles.header}>
      <View><Text style={styles.brand}>DRIVE<Text style={{color:C.accent}}>PULSE</Text></Text><Text style={styles.brandSub}>YOUR DRIVE. YOUR DATA.</Text></View>
      <View style={[styles.gpsIndicator,{backgroundColor:gpsAccess?'#204B47':C.panel2}]}><Text style={{color:gpsAccess?C.accent:C.muted,fontSize:11,fontWeight:'700'}}>● {gpsAccess?'GPS ERLAUBT':'GPS AUS'}</Text></View>
    </View>
    {!!error && <Pressable onPress={()=>setError('')} style={styles.error}><Text style={{color:C.white,fontSize:12,flex:1}}>{error}</Text><Text style={{color:C.white}}>×</Text></Pressable>}
    <View style={styles.body}>
      {page==='Karte' && mapContent()}
      {page==='Tacho' && speedContent()}
      {page==='Statistik' && statsContent()}
      {page==='Freunde' && friendsContent()}
      {page==='Profil' && profileContent()}
    </View>
    <View style={styles.tabBar}>
      {tabs.map(tab => <Pressable key={tab.key} onPress={()=>setPage(tab.key)} style={styles.tab} accessibilityRole="tab" accessibilityState={{selected:page===tab.key}}>
        <Text style={[styles.tabIcon,{color:page===tab.key?C.accent:C.muted}]}>{tab.icon}</Text>
        <Text style={[styles.tabText,{color:page===tab.key?C.accent:C.muted}]}>{tab.key}</Text>
      </Pressable>)}
    </View>
    {busy && <View pointerEvents="none" style={styles.busyDot}><ActivityIndicator size="small" color={C.accent}/></View>}
  </SafeAreaView>;
}

export default function App() { return <SafeAreaProvider><DrivePulse/></SafeAreaProvider>; }

const styles = StyleSheet.create({
  safe: {flex:1,backgroundColor:C.bg},
  header:{minHeight:66,flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:18,borderBottomWidth:1,borderBottomColor:C.border},
  brand:{fontWeight:'900',fontSize:22,letterSpacing:1.5,color:C.white}, brandSub:{color:C.muted,fontSize:9,letterSpacing:2.5,marginTop:2},
  gpsIndicator:{paddingHorizontal:10,paddingVertical:8,borderRadius:9},
  body:{flex:1},scrollContent:{padding:16,paddingBottom:28,gap:12},
  eyebrowRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:2},
  eyebrow:{color:C.muted,letterSpacing:2,fontSize:11,fontWeight:'700'},pill:{fontSize:11,fontWeight:'800'},
  speedPanel:{backgroundColor:C.panel,borderRadius:19,borderWidth:1,borderColor:C.border,padding:18,alignItems:'center'},
  metricLabel:{color:C.muted,fontSize:10,fontWeight:'800',letterSpacing:1.15},
  hugeSpeed:{fontSize:105,lineHeight:114,fontWeight:'800',fontVariant:['tabular-nums'],marginTop:4},
  speedUnit:{color:C.muted,fontSize:16,marginTop:-12,marginBottom:12},
  separator:{height:1,backgroundColor:C.border,width:'100%',marginVertical:15},
  pillRow:{width:'100%',flexDirection:'row',flexWrap:'wrap',gap:7,alignItems:'center',justifyContent:'space-between'},
  limitValue:{color:C.white,fontSize:24,fontWeight:'900',marginTop:3},speedBadge:{color:C.amber,fontSize:12,fontWeight:'800'},
  roadName:{alignSelf:'stretch',color:C.muted,fontSize:12,marginTop:10,marginBottom:6},
  chip:{backgroundColor:C.panel2,paddingHorizontal:10,paddingVertical:8,borderRadius:9,borderWidth:1,borderColor:C.border},
  chipActive:{backgroundColor:'#235C59',borderColor:C.accent},chipText:{fontSize:12,color:C.muted,fontWeight:'700'},chipTextActive:{color:C.white},
  finePanel:{backgroundColor:'#211E2B',borderWidth:1,borderRadius:16,padding:15,gap:8},
  fineHeading:{color:C.white,fontSize:12,letterSpacing:.8,fontWeight:'800'},
  fineValue:{color:C.white,fontSize:36,fontWeight:'900'},fineDetail:{color:C.muted,fontSize:12,maxWidth:'47%',textAlign:'right'},
  info:{color:C.muted,fontSize:12,lineHeight:18},
  columns:{flexDirection:'row',gap:10},metric:{flex:1,minWidth:0,backgroundColor:C.panel,borderRadius:15,borderColor:C.border,borderWidth:1,padding:15,gap:8},
  metricNumber:{flexDirection:'row',alignItems:'baseline',flexWrap:'wrap'},metricValue:{fontSize:27,color:C.white,fontWeight:'800',fontVariant:['tabular-nums']},metricUnit:{color:C.muted,fontSize:11},
  mainButton:{borderRadius:14,backgroundColor:C.accent,alignItems:'center',padding:17,marginTop:5},
  dangerButton:{backgroundColor:'#BD4655'},mainButtonText:{fontSize:15,fontWeight:'900',color:C.bg},
  title:{color:C.white,fontWeight:'900',fontSize:25,marginTop:4},subtitle:{color:C.muted,fontSize:12,marginBottom:12,lineHeight:20},
  sectionRow:{marginTop:12,flexDirection:'row',justifyContent:'space-between'},label:{color:C.muted,fontSize:11,fontWeight:'900',letterSpacing:1.25},
  secondary:{color:C.muted,fontSize:12,lineHeight:18},
  empty:{alignItems:'center',backgroundColor:C.panel,borderColor:C.border,borderWidth:1,borderRadius:16,padding:25,gap:10,marginVertical:6},
  emptyIcon:{fontSize:34,color:C.accent},emptyTitle:{fontSize:17,fontWeight:'800',color:C.white},
  tripRow:{backgroundColor:C.panel,borderRadius:13,padding:15,flexDirection:'row',alignItems:'center',gap:8,borderWidth:1,borderColor:C.border},
  tripHeading:{color:C.white,fontSize:14,fontWeight:'700',marginBottom:5},tripDistance:{fontSize:15,color:C.accent,fontWeight:'800'},
  profileCard:{backgroundColor:C.panel,borderColor:C.border,borderWidth:1,borderRadius:15,padding:17,gap:12},
  cardTitle:{color:C.white,fontSize:18,fontWeight:'800'},deleteButton:{padding:12,borderWidth:1,borderColor:'#6F4148',borderRadius:10,alignItems:'center'},
  tabBar:{height:66,borderTopWidth:1,borderTopColor:C.border,backgroundColor:C.bg,flexDirection:'row',paddingTop:8},
  tab:{flex:1,alignItems:'center',justifyContent:'center',gap:3},tabIcon:{fontSize:21,fontWeight:'700'},tabText:{fontSize:10,fontWeight:'700'},
  mapContainer:{flex:1,backgroundColor:'#233849'},
  mapModeButton:{position:'absolute',top:164,right:12,backgroundColor:'#0B111DE8',borderColor:C.border,borderWidth:1,paddingVertical:8,paddingHorizontal:12,borderRadius:9},
  mapModeText:{color:C.white,fontWeight:'800',fontSize:11},
  mapLoading:{position:'absolute',top:'49%',alignSelf:'center',alignItems:'center',gap:10,padding:14,backgroundColor:'#0B111DDD',borderRadius:12},
  mapDiagnostic:{position:'absolute',top:'47%',left:30,right:30,backgroundColor:'#0B111DEB',padding:14,borderRadius:12},
  mapDiagnosticText:{color:C.white,fontSize:12,textAlign:'center'},
  searchCard:{position:'absolute',top:12,left:12,right:12,borderRadius:16,backgroundColor:C.bg,padding:13,gap:9,maxHeight:'64%'},
  searchTitle:{color:C.white,fontSize:16,fontWeight:'800'},
  searchRow:{flexDirection:'row',alignItems:'center',gap:7},
  destinationInput:{flex:1,borderWidth:1,borderColor:C.border,borderRadius:10,backgroundColor:C.panel,paddingHorizontal:11,paddingVertical:10,color:C.white,fontSize:14,minHeight:44},
  searchButton:{backgroundColor:C.accent,borderRadius:10,minHeight:44,justifyContent:'center',paddingHorizontal:11},
  searchResult:{paddingVertical:9,borderBottomWidth:1,borderBottomColor:C.border},resultTitle:{color:C.white,fontSize:13},
  routeSummary:{paddingTop:8,borderTopWidth:1,borderTopColor:C.border,gap:5},
  routeDestination:{color:C.white,fontSize:13,fontWeight:'700'},
  mapError:{color:C.amber,fontSize:12,lineHeight:18},mapDisclaimer:{color:C.amber,fontSize:12},
  navigationCard:{position:'absolute',top:12,left:12,right:12,borderRadius:16,backgroundColor:'#153754',padding:15,gap:6},
  navigationEyebrow:{color:C.accent,fontSize:10,fontWeight:'900',letterSpacing:2},
  navigationInstruction:{color:C.white,fontSize:19,fontWeight:'900'},navigationDetail:{color:'#D1E3F0',fontSize:13},
  stopNavButton:{padding:12,borderRadius:10,backgroundColor:'#AA4954',alignItems:'center',marginTop:4},
  sanctionText:{color:C.white,fontSize:13,fontWeight:'700'},
  mapTop:{position:'absolute',top:12,left:15,right:15,borderRadius:12,backgroundColor:C.bg,padding:14},
  mapTopTitle:{color:C.white,fontSize:18,fontWeight:'800'},mapTopSub:{color:C.muted,fontSize:11,marginTop:4},osmCredit:{color:C.muted,fontSize:9,marginTop:4},
  mapFooter:{position:'absolute',bottom:16,left:16,right:16,backgroundColor:C.bg,borderRadius:16,padding:14,flexDirection:'row',alignItems:'center'},
  mapFooterSpeed:{fontSize:28,color:C.white,fontWeight:'800'},mapSpeedLimit:{color:C.accent,fontSize:12,marginTop:4},roundButton:{height:45,width:45,backgroundColor:C.accent,alignItems:'center',justifyContent:'center',borderRadius:30},
  error:{marginHorizontal:16,marginTop:9,padding:10,flexDirection:'row',alignItems:'center',backgroundColor:'#8B4047',borderRadius:8,gap:10},
  busyDot:{position:'absolute',top:70,right:18},
});
