import test from 'node:test';
import assert from 'node:assert/strict';
import {parseRouteResponse,maneuverInstruction,routeProgress,metersLabel} from '../src/navigation/routing.mjs';
const example = {code:'Ok',routes:[{geometry:{coordinates:[[11,49],[11.001,49],[11.002,49]]},distance:151,duration:20,
  legs:[{steps:[{maneuver:{location:[11,49],type:'depart'},name:'Hauptstraße'},
    {maneuver:{location:[11.002,49],type:'turn',modifier:'right'},name:'Bahnhofstraße'}]}]}]};
test('parses GeoJSON into map coordinates',()=>{
  const r=parseRouteResponse(example);
  assert.equal(r.coordinates.length,3);assert.equal(r.coordinates[0].latitude,49);assert.equal(r.steps.length,2);
});
test('rejects malformed routing payloads',()=>{
  assert.throws(()=>parseRouteResponse({code:'NoRoute',routes:[]}));
  assert.throws(()=>parseRouteResponse({code:'Ok',routes:[{geometry:{coordinates:[]},distance:0,duration:0}]}));
});
test('German maneuver instructions',()=>{
  const step={type:'turn',modifier:'right',name:'Marktplatz'};
  assert.match(maneuverInstruction(step),/Rechts abbiegen/);
  assert.match(maneuverInstruction({type:'roundabout',exit:2,name:'Hauptstraße'}),/Ausfahrt 2/);
});
test('route geometry progress and arrival',()=>{
  const r=parseRouteResponse(example);
  const first=routeProgress(r,{latitude:49,longitude:11});
  assert.ok(first.remainingMeters>100);assert.ok(first.offRouteMeters<1);
  const end=routeProgress(r,{latitude:49,longitude:11.002});
  assert.ok(end.arrived);assert.ok(end.remainingMeters<30);
});
test('off route detection + distance label',()=>{
  const r=parseRouteResponse(example);
  assert.ok(routeProgress(r,{latitude:49.002,longitude:11.001}).offRouteMeters>100);
  assert.equal(metersLabel(1540),'1,5 km');assert.equal(metersLabel(154),'150 m');
});
