import test from 'node:test';
import assert from 'node:assert/strict';
import { matchSpeedLimit, parseSpeedValue, contextFromTags } from '../src/speed/roadMatching.mjs';
const where = {latitude:49.477, longitude:10.998, accuracy:6, heading:0, speedKmh:45};
const road = (id,tags, offset=0) => ({id, tags:{highway:'residential',...tags},geometry:[
  {lat:49.4769,lon:10.998+offset}, {lat:49.4771,lon:10.998+offset}
]});

test('Tempo 30 on nearest street is detected automatically', () => {
  const out = matchSpeedLimit([road(1,{maxspeed:'30',name:'Musterstraße'})],where);
  assert.equal(out.status,'known'); assert.equal(out.kmh,30); assert.equal(out.roadName,'Musterstraße');
});
test('Nearest untagged road must not inherit a different road limit',()=>{
  const out=matchSpeedLimit([road(1,{}),road(2,{maxspeed:'50'},0.0003)],where);
  assert.equal(out.status,'unknown');
});
test('Two close roads with conflicting limits are ambiguous',()=>{
  const out=matchSpeedLimit([road(1,{maxspeed:'30'}),road(2,{maxspeed:'50'},0.00007)],where);
  assert.equal(out.status,'unknown');
});
test('Conditional and variable limits are never treated as permanent',()=>{
  assert.equal(matchSpeedLimit([road(1,{maxspeed:'50','maxspeed:conditional':'30 @ (Mo-Fr 07:00-17:00)'})],where).status,'unknown');
  assert.equal(matchSpeedLimit([road(1,{maxspeed:'100','maxspeed:variable':'yes'})],where).status,'unknown');
});
test('Directional speed restrictions use travel direction',()=>{
  const north=matchSpeedLimit([road(1,{'maxspeed:forward':'30','maxspeed:backward':'50'})],where);
  const south=matchSpeedLimit([road(1,{'maxspeed:forward':'30','maxspeed:backward':'50'})],{...where,heading:180});
  assert.equal(north.kmh,30);assert.equal(south.kmh,50);
  assert.equal(matchSpeedLimit([road(1,{'maxspeed:forward':'30','maxspeed:backward':'50'})],{...where,heading:null}).status,'unknown');
});
test('No general numeric limit and implicit German road rules are distinct',()=>{
  assert.equal(matchSpeedLimit([road(1,{maxspeed:'none'})],where).status,'unlimited');
  assert.equal(matchSpeedLimit([road(1,{'maxspeed:type':'DE:urban'})],where).kmh,50);
  assert.equal(contextFromTags({'source:maxspeed':'DE:rural'}),'rural');
});
test('Unit conversion and GPS quality filtering',()=>{
  assert.equal(parseSpeedValue('30 mph').kmh,48);
  assert.equal(parseSpeedValue('walk').kind,'unknown');
  assert.equal(matchSpeedLimit([road(1,{maxspeed:'50'})],{...where,accuracy:100}).status,'unknown');
});
