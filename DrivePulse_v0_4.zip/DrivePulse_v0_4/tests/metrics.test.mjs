import test from 'node:test';
import assert from 'node:assert/strict';
import { haversineMeters, measureStep, formatDuration, fineForCar } from '../src/logic/metrics.mjs';

test('Gleiche Position = 0 Meter', () => {
  const p = {latitude: 49, longitude: 10};
  assert.equal(haversineMeters(p,p),0);
});
test('Ein Längengrad auf Äquator ~111.2km', () => {
  assert.ok(Math.abs(haversineMeters({latitude:0, longitude:0},{latitude:0, longitude:1})-111195) < 100);
});
test('Doppelte und ungenaue GPS-Punkte werden nicht gezählt', () => {
  const p = {latitude: 49, longitude: 10, timestamp: 10000, accuracy: 10, speed: 10};
  assert.equal(measureStep(p,{...p}),null);
  assert.equal(measureStep(p,{...p,timestamp:11000,accuracy:70}),null);
});
test('Ausreißer fließen nicht in Kilometer ein', () => {
  const p = {latitude: 49, longitude: 10, timestamp: 10000, accuracy: 10, speed: 10};
  const q = {...p,latitude:50,timestamp:11000};
  assert.equal(measureStep(p,q),null);
});
test('Realistischer GPS-Schritt erhöht Distanz', () => {
  const p = {latitude: 49, longitude: 10, timestamp: 10000, accuracy: 10, speed: 8};
  const q = {...p,latitude:49.00012,timestamp:12000};
  const result = measureStep(p,q);
  assert.ok(result?.distanceMeters > 12 && result?.distanceMeters < 15);
});
test('Bußgeld-Staffeln Pkw: 20 km/h innerorts = 70 Euro', () => {
  assert.equal(fineForCar(20, true),70);
  assert.equal(fineForCar(20, false),60);
  assert.equal(fineForCar(0, true),0);
  assert.equal(fineForCar(21, true),115);
  assert.equal(fineForCar(71, true),800);
});
test('Zeitdarstellung Stunden:Minuten', () => {
  assert.equal(formatDuration(3660000),'1:01');
});
