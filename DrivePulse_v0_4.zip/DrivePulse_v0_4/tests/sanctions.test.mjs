import test from 'node:test';
import assert from 'node:assert/strict';
import { sanctionForCar } from '../src/logic/metrics.mjs';
test('Pkw innerorts BKatV threshold and points',()=>{
  assert.deepEqual(sanctionForCar(20,true),{euro:70,points:0,banMonths:0,repeatBanPossible:false});
  assert.deepEqual(sanctionForCar(21,true),{euro:115,points:1,banMonths:0,repeatBanPossible:false});
  assert.deepEqual(sanctionForCar(30,true),{euro:180,points:1,banMonths:0,repeatBanPossible:true});
  assert.deepEqual(sanctionForCar(31,true),{euro:260,points:2,banMonths:1,repeatBanPossible:false});
});
test('Pkw außerorts BKatV thresholds',()=>{
  assert.deepEqual(sanctionForCar(31,false),{euro:200,points:1,banMonths:0,repeatBanPossible:true});
  assert.deepEqual(sanctionForCar(41,false),{euro:320,points:2,banMonths:1,repeatBanPossible:false});
});
