import test from 'node:test';
import assert from 'node:assert/strict';
import { fineForCar, sanctionForCar } from '../src/logic/metrics.mjs';
const catalog = [
  { upTo:10, urban:30, rural:20, urbanPoints:0, ruralPoints:0, urbanBan:0, ruralBan:0 },
  { upTo:15, urban:50, rural:40, urbanPoints:0, ruralPoints:0, urbanBan:0, ruralBan:0 },
  { upTo:20, urban:70, rural:60, urbanPoints:0, ruralPoints:0, urbanBan:0, ruralBan:0 },
  { upTo:25, urban:115, rural:100, urbanPoints:1, ruralPoints:1, urbanBan:0, ruralBan:0 },
  { upTo:30, urban:180, rural:150, urbanPoints:1, ruralPoints:1, urbanBan:0, ruralBan:0 },
  { upTo:40, urban:260, rural:200, urbanPoints:2, ruralPoints:1, urbanBan:1, ruralBan:0 },
  { upTo:50, urban:400, rural:320, urbanPoints:2, ruralPoints:2, urbanBan:1, ruralBan:1 },
  { upTo:60, urban:560, rural:480, urbanPoints:2, ruralPoints:2, urbanBan:2, ruralBan:1 },
  { upTo:70, urban:700, rural:600, urbanPoints:2, ruralPoints:2, urbanBan:3, ruralBan:2 },
  { upTo:120, urban:800, rural:700, urbanPoints:2, ruralPoints:2, urbanBan:3, ruralBan:3 },
];
test('All official car fine bands innerorts/außerorts with points and rule bans',()=>{
  for(const b of catalog){
    for(const inside of [true,false]) {
      const r=sanctionForCar(b.upTo, inside);
      assert.equal(r.euro,inside?b.urban:b.rural,`fine ${b.upTo} ${inside}`);
      assert.equal(r.points,inside?b.urbanPoints:b.ruralPoints,`points ${b.upTo} ${inside}`);
      assert.equal(r.banMonths,inside?b.urbanBan:b.ruralBan,`ban ${b.upTo} ${inside}`);
    }
  }
});
test('Threshold boundaries and fractional speeds do not round a sub-one-kmh overage up',()=>{
  assert.equal(fineForCar(0.5,true),0);
  assert.equal(fineForCar(10.99,true),30);
  assert.equal(fineForCar(11,true),50);
  assert.equal(fineForCar(20,true),70);
  assert.equal(fineForCar(20.999,true),70);
  assert.equal(fineForCar(21,true),115);
  assert.equal(fineForCar(70,false),600);
  assert.equal(fineForCar(71,false),700);
});
test('Repeat offender condition is identified without declaring a ban automatically',()=>{
  for(const innerorts of [true,false]) {
    assert.equal(sanctionForCar(25,innerorts).repeatBanPossible,false);
    assert.equal(sanctionForCar(26,innerorts).repeatBanPossible,true);
  }
});
