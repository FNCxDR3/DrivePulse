export type GeoPoint = {latitude:number; longitude:number};
export type ManeuverStep = { location:GeoPoint; type:string;modifier:string;exit:number;name:string;distanceMeters:number;durationSeconds:number;routeIndex?:number };
export type DrivingRoute = {coordinates:GeoPoint[];steps:ManeuverStep[];distanceMeters:number;durationSeconds:number};
export function parseRouteResponse(payload:unknown): DrivingRoute;
export function maneuverInstruction(step:ManeuverStep|null):string;
export function routeProgress(route: DrivingRoute|null, position:GeoPoint|null): {offRouteMeters:number;remainingMeters:number;nextStep:ManeuverStep|null;nextStepDistanceMeters:number|null;arrived:boolean}|null;
export function metersLabel(distanceMeters:number):string;
