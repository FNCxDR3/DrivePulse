/** Pure routing and maneuver helpers. No external network calls. */
import { haversineMeters } from '../logic/metrics.mjs';

export function parseRouteResponse(payload) {
  const first = payload?.routes?.[0];
  if (payload?.code !== 'Ok' || !first || !Array.isArray(first?.geometry?.coordinates)) {
    throw new Error('Für dieses Ziel wurde keine befahrbare Route gefunden.');
  }
  const coordinates = first.geometry.coordinates.map((pair) => ({
    longitude: Number(pair?.[0]), latitude: Number(pair?.[1])
  })).filter(p => Number.isFinite(p.latitude) && Number.isFinite(p.longitude)
    && Math.abs(p.latitude) <= 90 && Math.abs(p.longitude) <= 180);
  if (coordinates.length < 2 || coordinates.length > 150000 || !Number.isFinite(first.distance) || !Number.isFinite(first.duration)) {
    throw new Error('Der Kartendienst hat eine ungültige Route geliefert.');
  }
  const steps = (first.legs || []).flatMap(l => l.steps || []).map((s) => ({
    location: { longitude: Number(s.maneuver?.location?.[0]), latitude: Number(s.maneuver?.location?.[1]) },
    type: String(s.maneuver?.type || ''), modifier: String(s.maneuver?.modifier || ''),
    exit: Number(s.maneuver?.exit || 0), name: String(s.name || ''),
    distanceMeters: Math.max(0, Number(s.distance) || 0),
    durationSeconds: Math.max(0, Number(s.duration) || 0)
  })).filter(s => Number.isFinite(s.location.latitude) && Number.isFinite(s.location.longitude));
  // Maneuver indices are computed once per route, not on every GPS sample.
  // Exact OSRM maneuver locations normally coincide with route geometry points.
  // Near-coincident matching tolerates GeoJSON rounding differences.
  let indexStart = 0;
  for (const step of steps) {
    let nearestIndex = indexStart;
    let nearestMeters = Infinity;
    for (let j = indexStart; j < coordinates.length; j++) {
      const d = haversineMeters(coordinates[j], step.location);
      if (d < nearestMeters) {nearestMeters = d;nearestIndex = j;}
      if (nearestMeters < 0.2) break;
    }
    step.routeIndex = nearestIndex;
    indexStart = nearestIndex;
  }
  return {coordinates, steps, distanceMeters: first.distance, durationSeconds: first.duration};
}

export function maneuverInstruction(step) {
  if (!step) return 'Route folgen';
  const {type, modifier, name, exit} = step;
  const road = name ? ` auf ${name}` : '';
  if (type === 'arrive') return 'Du hast dein Ziel erreicht';
  if (type === 'depart') return `Fahrt starten${road}`;
  if (type === 'roundabout' || type === 'rotary') return exit > 0 ? `Im Kreisverkehr Ausfahrt ${exit} nehmen${road}` : `In den Kreisverkehr fahren${road}`;
  if (type === 'merge') return `Einfädeln${road}`;
  if (type === 'on ramp') return `Auffahrt nehmen${road}`;
  if (type === 'off ramp') return `Ausfahrt nehmen${road}`;
  if (type === 'fork') return `An der Gabelung ${directionText(modifier)} halten${road}`;
  if (type === 'end of road') return `Am Straßenende ${directionText(modifier)} abbiegen${road}`;
  if (type === 'notification') return `Weiterfahren${road}`;
  if (type === 'new name') return `Weiter auf ${name || 'der Straße'}`;
  if (type === 'continue') return `Geradeaus weiterfahren${road}`;
  if (modifier === 'uturn') return `Wenden${road}`;
  if (type === 'turn') return `${directionText(modifier)} abbiegen${road}`;
  return `Weiterfahren${road}`;
}
function directionText(modifier) {
  if (modifier === 'sharp left') return 'Scharf links';
  if (modifier === 'slight left') return 'Leicht links';
  if (modifier === 'left') return 'Links';
  if (modifier === 'sharp right') return 'Scharf rechts';
  if (modifier === 'slight right') return 'Leicht rechts';
  if (modifier === 'right') return 'Rechts';
  if (modifier === 'uturn') return 'Wenden';
  return 'Geradeaus';
}

function nearestOnSegment(point, a, b) {
  const lat = point.latitude * Math.PI / 180;
  const scaleY = 111195;
  const scaleX = scaleY * Math.cos(lat);
  const ax = (a.longitude - point.longitude) * scaleX, ay = (a.latitude - point.latitude) * scaleY;
  const bx = (b.longitude - point.longitude) * scaleX, by = (b.latitude - point.latitude) * scaleY;
  const dx = bx - ax, dy = by - ay;
  const t = dx * dx + dy * dy < 0.01 ? 0 : Math.min(1, Math.max(0, -(ax * dx + ay * dy) / (dx * dx + dy * dy)));
  return {distanceMeters: Math.hypot(ax + dx * t, ay + dy * t), t};
}

export function routeProgress(route, position) {
  if (!route?.coordinates?.length || !position) return null;
  const coords = route.coordinates;
  let closest = {distanceMeters:Infinity, segmentIndex:0, t:0};
  for (let i = 1; i < coords.length; i++) {
    const found = nearestOnSegment(position, coords[i - 1], coords[i]);
    if (found.distanceMeters < closest.distanceMeters) closest = {...found, segmentIndex:i - 1};
  }
  let remainingMeters = haversineMeters(position, coords[closest.segmentIndex + 1]);
  for (let i = closest.segmentIndex + 2; i < coords.length; i++) remainingMeters += haversineMeters(coords[i - 1], coords[i]);
  // Pick the next maneuver by the nearest section ahead of the active route.
  let nextStep = null, nextStepDistance = Infinity;
  for (const step of route.steps || []) {
    const minIndex = Number.isInteger(step.routeIndex) ? step.routeIndex : -1;
    if (minIndex <= closest.segmentIndex) continue;
    let d = haversineMeters(position, coords[closest.segmentIndex + 1]);
    for (let j = closest.segmentIndex + 2; j <= minIndex; j++) d += haversineMeters(coords[j - 1], coords[j]);
    if (d < nextStepDistance) { nextStepDistance = d; nextStep = step; }
  }
  return {
    offRouteMeters: closest.distanceMeters,
    remainingMeters: Math.max(0, remainingMeters),
    nextStep, nextStepDistanceMeters: Number.isFinite(nextStepDistance) ? nextStepDistance : null,
    arrived: remainingMeters < 30 && closest.distanceMeters < 35
  };
}

export function metersLabel(distanceMeters) {
  if (!Number.isFinite(distanceMeters)) return '–';
  return distanceMeters >= 1000 ? `${(distanceMeters/1000).toLocaleString('de-DE',{maximumFractionDigits:1})} km` : `${Math.round(distanceMeters/10)*10} m`;
}
