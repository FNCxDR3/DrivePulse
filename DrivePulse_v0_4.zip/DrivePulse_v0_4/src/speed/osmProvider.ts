import type { OsmRoad } from './roadMatching.mjs';

/**
 * Non-production prototype: uses public Overpass as a limited online data
 * source, not as a high-frequency fleet tracking service. Every request
 * transmits the current approximate GPS coordinates to the operator.
 * No location history is sent by this module.
 */
export async function queryOsmRoads(latitude: number, longitude: number): Promise<OsmRoad[]> {
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
    throw new Error('Ungültige GPS-Position');
  }
  const query = `[out:json][timeout:12];way(around:250,${latitude.toFixed(6)},${longitude.toFixed(6)})["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|service|living_street|road|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$"];out tags geom;`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 14000);
  try {
    const response = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
      body: `data=${encodeURIComponent(query)}`, signal: controller.signal
    });
    if (!response.ok) throw new Error(`Kartendienst antwortet mit HTTP ${response.status}`);
    const json: unknown = await response.json();
    if (!json || typeof json !== 'object' || !('elements' in json) || !Array.isArray(json.elements)) {
      throw new Error('Ungültige Kartendaten erhalten');
    }
    return json.elements.filter((road: unknown): road is OsmRoad => {
      if (!road || typeof road !== 'object') return false;
      const item = road as Partial<OsmRoad>;
      return typeof item.id === 'number' && Number.isInteger(item.id) && !!item.tags && Array.isArray(item.geometry) &&
        item.geometry.length >= 2 && item.geometry.length <= 15000;
    }).slice(0, 500);
  } finally { clearTimeout(timer); }
}
