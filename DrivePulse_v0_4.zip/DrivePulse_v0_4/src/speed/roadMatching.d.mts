export type RoadTags = Record<string,string>;
export type OsmRoad = { id: number; tags: RoadTags; geometry: {lat:number;lon:number}[] };
export type RoadPoint = {latitude:number; longitude:number; accuracy:number; heading?:number|null; speedKmh?:number|null};
export type MatchedLimit =
  | {status:'known'; kmh:number; roadName:string; context:'urban'|'rural'|null; source:string}
  | {status:'unlimited'; roadName:string; context:'urban'|'rural'|null; source:string}
  | {status:'unknown'; reason:string; roadName?:string};
export function pointDistanceMeters(a: {latitude:number;longitude:number}, b:{latitude:number;longitude:number}):number;
export function parseSpeedValue(value: unknown): {kind:'known';kmh:number}|{kind:'unlimited'}|{kind:'unknown'};
export function contextFromTags(tags:RoadTags):'urban'|'rural'|null;
export function matchSpeedLimit(roads:OsmRoad[],point:RoadPoint):MatchedLimit;
