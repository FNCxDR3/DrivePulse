/** Reine Rechenfunktionen ohne React-Native-Abhängigkeiten (leicht testbar). */
export function haversineMeters(a, b) {
  const earthRadius = 6371000;
  const toRad = x => x * Math.PI / 180;
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);
  const dLat = lat2 - lat1;
  const dLon = toRad(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * earthRadius * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Berechnet GPS-Folgesample; Heuristik, keine geeichte Messung. */
export function measureStep(previous, current) {
  if (!Number.isFinite(current.latitude) || !Number.isFinite(current.longitude) ||
      !Number.isFinite(current.timestamp) || current.latitude < -90 || current.latitude > 90 ||
      current.longitude < -180 || current.longitude > 180 ||
      !Number.isFinite(current.accuracy) || current.accuracy > 35 || current.accuracy < 0) {
    return null;
  }
  const reported = Number.isFinite(current.speed) && current.speed >= 0
    ? current.speed * 3.6 : null;
  if (!previous) {
    return { distanceMeters: 0, speedKmh: reported !== null && reported <= 350 ? reported : 0 };
  }
  const elapsedSec = (current.timestamp - previous.timestamp) / 1000;
  if (elapsedSec <= 0) return null;
  const distance = haversineMeters(previous, current);
  const calculatedKmh = distance / elapsedSec * 3.6;
  // GPS-Ausreißer bei großen Zeitabständen oder unmöglichen Geschwindigkeiten ausschließen.
  if (calculatedKmh > 350 || distance > 1500) return null;
  const speedKmh = reported !== null && reported <= 350 ? reported : calculatedKmh;
  return {
    distanceMeters: elapsedSec <= 180 && distance >= 5 && speedKmh >= 3 ? distance : 0,
    speedKmh
  };
}

export function formatDuration(ms) {
  const totalMinutes = Math.max(0, Math.floor(ms / 60000));
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h}:${String(m).padStart(2, '0')}`;
}

/** Pkw ohne Anhänger, BKatV Anhang Tabelle 1(c), ohne Toleranz / Zusatzgebühren. */
export function fineForCar(overKmh, innerorts) {
  if (!Number.isFinite(overKmh) || overKmh < 1) return 0;
  const over = Math.floor(overKmh);
  const limits = [10, 15, 20, 25, 30, 40, 50, 60, 70, Infinity];
  const urban = [30, 50, 70, 115, 180, 260, 400, 560, 700, 800];
  const rural = [20, 40, 60, 100, 150, 200, 320, 480, 600, 700];
  const index = limits.findIndex(threshold => over <= threshold);
  return (innerorts ? urban : rural)[index];
}

/** BKatV Tabelle 1(c) / FeV Anlage 13, normale Pkw, Stand 17.10.2026.
 * Fahrverbot bei zwei Verstößen um mindestens 26 km/h binnen 12 Monaten
 * (Regel des § 4 Abs. 2 BKatV) bleibt abhängig vom Einzelfall.
 */
export function sanctionForCar(overKmh, innerorts) {
  const rounded = Number.isFinite(overKmh) ? Math.floor(overKmh) : 0;
  if (rounded <= 0) return {euro:0,points:0,banMonths:0,repeatBanPossible:false};
  const euro = fineForCar(rounded,innerorts);
  const points = rounded < 21 ? 0 : (rounded <= 30 || (!innerorts && rounded <= 40) ? 1 : 2);
  const banMonths = innerorts
    ? (rounded <= 30 ? 0 : rounded <= 50 ? 1 : rounded <= 60 ? 2 : 3)
    : (rounded <= 40 ? 0 : rounded <= 60 ? 1 : rounded <= 70 ? 2 : 3);
  const repeatBanPossible = rounded >= 26 && rounded <= (innerorts ? 30 : 40);
  return {euro,points,banMonths,repeatBanPossible};
}
