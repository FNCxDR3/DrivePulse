/** DrivePulse 0.4 – vector map WebView. Requires network/WebGL; never a legal sign detector. */
export const DRIVE_MAP_HTML = `<!doctype html>
<html lang="de"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<link href="https://unpkg.com/maplibre-gl@5.6.0/dist/maplibre-gl.css" rel="stylesheet" />
<style>
 html,body,#map{margin:0;height:100%;width:100%;overflow:hidden;background:#101a2b;}
 .maplibregl-control-container .maplibregl-ctrl-bottom-right {bottom:0;right:3px;}
 .maplibregl-ctrl-attrib{font:10px system-ui!important;opacity:.8;}
 .maplibregl-ctrl-logo{display:none!important}
 #notice{position:absolute;top:45%;left:9%;right:9%;border-radius:15px;background:#112039f2;padding:18px;color:#e7f6ff;font:14px system-ui;display:none;text-align:center;z-index:999;}
 .vehicle{width:28px;height:38px;filter:drop-shadow(0 4px 8px #000b)}
 .vehicle:before{content:'';display:block;position:absolute;top:0;left:4px;border-left:10px solid transparent;border-right:10px solid transparent;border-bottom:29px solid #43e8d0;}
 .vehicle:after{content:'';position:absolute;top:17px;left:12px;width:4px;height:10px;border-radius:2px;background:#071728}
 .destination{width:20px;height:20px;border-radius:50%;background:#ffb96f;border:3px solid white;box-shadow:0 0 0 5px #ffb96f55}
 .maplibregl-canvas:focus{outline:0}
</style>
<script src="https://unpkg.com/maplibre-gl@5.6.0/dist/maplibre-gl.js"></script>
</head><body><div id="map"></div><div id="notice">Die 3D-Karte konnte nicht geladen werden. Bitte Internetverbindung prüfen oder die iOS-Karte wählen.</div>
<script>
(function(){
 let map=null,gpsMarker=null,destMarker=null,ready=false,firstFix=false;
 let currentMode='drive',currentTheme='dark',lastGps=null,trackData=[],routeData=[];
 const report=(kind)=>{try{window.ReactNativeWebView.postMessage(kind)}catch(e){}};
 const showFailure=(msg)=>{document.getElementById('notice').style.display='block';report('error:'+msg)};
 if(!window.maplibregl || !maplibregl.supported({failIfMajorPerformanceCaveat:true})){
   showFailure('webgl');return;
 }
 function convert(arr){return (arr||[]).filter(x=>Array.isArray(x)&&x.length===2&&isFinite(x[0])&&isFinite(x[1])) .map(p=>[p[1],p[0]])}
 function geoLine(points){return {type:'Feature',properties:{},geometry:{type:'LineString',coordinates:points.length>=2?points:[]}}}
 function addRouteLayer(){
   if(map.getSource('dp-route'))return;
   map.addSource('dp-route',{type:'geojson',data:geoLine(routeData)});
   map.addLayer({id:'dp-route-glow',type:'line',source:'dp-route',paint:{'line-color':'#2568ea','line-width':18,'line-opacity':.20,'line-blur':9}});
   map.addLayer({id:'dp-route-core',type:'line',source:'dp-route',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#50a7ff','line-width':['interpolate',['linear'],['zoom'],10,4,16,9,20,15],'line-opacity':.98}});
   map.addSource('dp-track',{type:'geojson',data:geoLine(trackData)});
   map.addLayer({id:'dp-track-line',type:'line',source:'dp-track',paint:{'line-color':'#39d4b6','line-width':4,'line-opacity':.78}})
 }
 function addBuildings(){
   const style=map.getStyle();if(!style||!style.sources)return;
   const vector=Object.entries(style.sources).find(([k,v])=>v.type==='vector');
   if(!vector || map.getLayer('dp-buildings'))return;
   try{
     const label=(style.layers||[]).find(l=>l.type==='symbol');
     map.addLayer({id:'dp-buildings',type:'fill-extrusion',source:vector[0], 'source-layer':'building',
        minzoom:14,filter:['!=',['get','hide_3d'],true],
        paint:{'fill-extrusion-color':currentTheme==='dark'?'#304e68':'#c2ccd9',
          'fill-extrusion-height':['interpolate',['linear'],['zoom'],14,0,15.4,['coalesce',['to-number',['get','render_height']],['to-number',['get','height']],12]],
          'fill-extrusion-base':['coalesce',['to-number',['get','render_min_height']],0],
          'fill-extrusion-opacity':.76}},label?.id);
   }catch(e){report('info:buildings-unavailable')}
 }
 function refreshLayers(){try{addBuildings();addRouteLayer()}catch(e){report('error:map-layers')} }
 function easeToGps(instant){
   if(!lastGps)return;
   const bearing=currentMode==='drive'&&isFinite(lastGps.heading)&&lastGps.speedKmh>=8 ? lastGps.heading : 0;
   map.easeTo({center:[lastGps.lng,lastGps.lat],bearing,pitch:currentMode==='drive'?58:0,
     zoom:currentMode==='drive'?17.1:16.2,offset:currentMode==='drive'?[0,85]:[0,0],duration:instant?0:800,essential:true});
 }
 function fitRoute(){if(routeData.length<2)return;const b=new maplibregl.LngLatBounds();routeData.forEach(p=>b.extend(p));map.fitBounds(b,{padding:{top:180,bottom:220,left:45,right:45},maxZoom:15.5,duration:600});}
 function update(d){
   if(!ready || !d)return;
   if(d.mode && d.mode!==currentMode){currentMode=d.mode;if(lastGps && d.follow!==false)easeToGps(false)}
   if(d.theme && d.theme!==currentTheme){currentTheme=d.theme; map.setStyle(currentTheme==='dark'?'https://tiles.openfreemap.org/styles/dark':'https://tiles.openfreemap.org/styles/liberty')}
   if(d.gps && isFinite(d.gps.lat)&&isFinite(d.gps.lng)){
     lastGps={...d.gps,speedKmh: d.speedKmh || 0};const p=[d.gps.lng,d.gps.lat];
     if(!gpsMarker){const el=document.createElement('div');el.className='vehicle';
       gpsMarker=new maplibregl.Marker({element:el,rotationAlignment:'map',pitchAlignment:'map'}).setLngLat(p).addTo(map)}
     else gpsMarker.setLngLat(p);
     if(Number.isFinite(d.gps.heading))gpsMarker.setRotation(d.gps.heading);
     if(!firstFix || d.follow){easeToGps(!firstFix);firstFix=true;}
   }
   if(d.dest && isFinite(d.dest.lat)&&isFinite(d.dest.lng)){
      const p=[d.dest.lng,d.dest.lat];
      if(!destMarker){const el=document.createElement('div');el.className='destination';destMarker=new maplibregl.Marker({element:el}).setLngLat(p).addTo(map)}
      else destMarker.setLngLat(p);
   }else if(destMarker){destMarker.remove();destMarker=null}
   if(Array.isArray(d.route)) {routeData=convert(d.route); const s=map.getSource('dp-route');if(s)s.setData(geoLine(routeData))}
   if(Array.isArray(d.track)) {trackData=convert(d.track);const s=map.getSource('dp-track');if(s)s.setData(geoLine(trackData))}
   if(d.fitRoute)fitRoute();
 }
 try{
   map=new maplibregl.Map({container:'map',style:'https://tiles.openfreemap.org/styles/dark',center:[10.45,51.16],zoom:5,
      pitch:58,bearing:0,attributionControl:true,antialias:true,fadeDuration:80});
   map.on('style.load',refreshLayers);
   map.on('load',()=>{ready=true;refreshLayers();report('ready')});
   map.on('dragstart',()=>report('moved'));
   map.on('rotatestart',()=>report('moved'));
   map.on('error',(evt)=>{ if(!ready){showFailure('style-or-tiles')}else{report('info:tile-error')} });
   window.drivePulseUpdate=update;
 }catch(e){showFailure('map-init')}
})();
</script></body></html>`;
