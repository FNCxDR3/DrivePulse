/** Lightweight alternative map for private prototype testing (requires internet). */
export const LEAFLET_HTML = `<!DOCTYPE html>
<html lang="de"><head><meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<style>html,body,#map { height:100%; margin:0;padding:0;background:#d4e4df; }
.leaflet-control-attribution {font:11px system-ui!important;}
#error{display:none;position:absolute;top:32%;left:10%;right:10%;z-index:1000;background:#152235;color:#fff;padding:12px;border-radius:12px;text-align:center;font:13px system-ui;}</style>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head><body><div id="map"></div><div id="error">Kartendienst nicht verfügbar</div>
<script>
(function () {
  function report(x){if(window.ReactNativeWebView)window.ReactNativeWebView.postMessage(x);}
  if(!window.L){document.getElementById('error').style.display='block';report('error:leaflet');return;}
  var map=L.map('map',{zoomControl:false,preferCanvas:true}).setView([51.16,10.45],6);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom:19,minZoom:3,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>',
    updateWhenIdle:true,keepBuffer:2
  }).on('tileerror',function(){window.drivePulseTileErrors=(window.drivePulseTileErrors||0)+1;if(window.drivePulseTileErrors===6)report('error:tiles');}).addTo(map);
  var gpsMarker=null, destinationMarker=null, routeLine=null, trackLine=null, firstFix=false;
  map.on('dragstart',function(){report('moved');});
  window.drivePulseUpdate = function(d) {
    if(!d||!window.L)return;
    if(d.gps && Number.isFinite(d.gps.lat) && Number.isFinite(d.gps.lng)) {
      var p=[d.gps.lat,d.gps.lng];
      if(!gpsMarker){gpsMarker=L.circleMarker(p,{radius:8,color:'#ffffff',weight:3,fillColor:'#1986EA',fillOpacity:1}).addTo(map);}
      else gpsMarker.setLatLng(p);
      if(!firstFix || d.follow){map.setView(p,Math.max(15,map.getZoom()),{animate:firstFix});firstFix=true;}
    }
    if(d.dest && Number.isFinite(d.dest.lat) && Number.isFinite(d.dest.lng)) {
      var end=[d.dest.lat,d.dest.lng];
      if(!destinationMarker)destinationMarker=L.marker(end).addTo(map);
      else destinationMarker.setLatLng(end);
    } else if(destinationMarker){map.removeLayer(destinationMarker);destinationMarker=null;}
    if(Array.isArray(d.route)){
      if(routeLine){map.removeLayer(routeLine);routeLine=null;}
      if(d.route.length>1){routeLine=L.polyline(d.route,{color:'#2D73FF',weight:7,opacity:.94}).addTo(map);}
    }
    if(Array.isArray(d.track)){
      if(trackLine){map.removeLayer(trackLine);trackLine=null;}
      if(d.track.length>1)trackLine=L.polyline(d.track,{color:'#17AA91',weight:4}).addTo(map);
    }
    if(d.fitRoute && routeLine){map.fitBounds(routeLine.getBounds(),{padding:[28,28],maxZoom:16});}
  };
  report('ready');
})();
</script></body></html>`;
