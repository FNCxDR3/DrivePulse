import AsyncStorage from '@react-native-async-storage/async-storage';
import type { GPSPoint, Trip, TripData } from './types';
import { measureStep } from '../logic/metrics.mjs';

const KEY = 'drivepulse:local-trips:v1';
let queue: Promise<unknown> = Promise.resolve();
const initial = (): TripData => ({ active: null, trips: [] });

async function load(): Promise<TripData> {
  const raw = await AsyncStorage.getItem(KEY);
  if (!raw) return initial();
  try {
    const parsed = JSON.parse(raw) as TripData;
    return { active: parsed.active ?? null, trips: parsed.trips ?? [] };
  } catch {
    throw new Error('Gespeicherte Fahrtdaten sind beschädigt. Es wurde nichts überschrieben.');
  }
}

/** Seriell pro JS-Laufzeit; keine gleichzeitigen Writer in foreground/background verwenden. */
function mutate<T>(f: (data: TripData) => T | Promise<T>): Promise<T> {
  const next = queue.catch(() => undefined).then(async () => {
    const data = await load();
    const result = await f(data);
    await AsyncStorage.setItem(KEY, JSON.stringify(data));
    return result;
  });
  queue = next.catch(() => undefined);
  return next;
}

export function getTrips(): Promise<TripData> {
  return queue.catch(() => undefined).then(load);
}

export function startTrip(): Promise<Trip> {
  return mutate(data => {
    if (data.active) throw new Error('Es läuft bereits eine Fahrt.');
    data.active = {
      id: `${Date.now()}-${Math.round(Math.random() * 100000)}`,
      startedAt: Date.now(), distanceMeters: 0,
      maxSpeedKmh: 0, lastSpeedKmh: 0, points: [], mode: 'foreground'
    };
    return data.active;
  });
}

export function setTrackingMode(mode: Trip['mode']): Promise<void> {
  return mutate(data => { if (data.active) data.active.mode = mode; });
}

export function appendGPS(point: GPSPoint): Promise<void> {
  return mutate(data => {
    const trip = data.active;
    if (!trip) return;
    const previous = trip.points.at(-1);
    const measured = measureStep(previous, point);
    if (!measured) return;
    trip.points.push(point);
    trip.distanceMeters += measured.distanceMeters;
    trip.lastSpeedKmh = measured.speedKmh;
    trip.maxSpeedKmh = Math.max(trip.maxSpeedKmh, measured.speedKmh);
    // Routenpunkte werden lokal gespeichert; kein automatischer Upload.
  });
}

export function finishTrip(): Promise<Trip | null> {
  return mutate(data => {
    const trip = data.active;
    if (!trip) return null;
    trip.endedAt = Date.now();
    data.trips.unshift(trip);
    data.active = null;
    return trip;
  });
}

export function clearTrips(): Promise<void> {
  return mutate(data => {
    if (data.active) throw new Error('Erst die laufende Fahrt beenden.');
    data.trips = [];
  });
}
