export type GPSPoint = {
  latitude: number;
  longitude: number;
  timestamp: number;
  accuracy: number;
  speed: number | null;
  heading?: number | null;
};

export type Trip = {
  id: string;
  startedAt: number;
  endedAt?: number;
  distanceMeters: number;
  maxSpeedKmh: number;
  lastSpeedKmh: number;
  points: GPSPoint[];
  mode: 'background' | 'foreground';
};

export type TripData = {
  active: Trip | null;
  trips: Trip[];
};
