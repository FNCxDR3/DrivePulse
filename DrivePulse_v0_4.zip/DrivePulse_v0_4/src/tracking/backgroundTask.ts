import * as TaskManager from 'expo-task-manager';
import type * as Location from 'expo-location';
import { appendGPS } from './store';
import type { GPSPoint } from './types';

export const LOCATION_TASK = 'drivepulse-ongoing-drive-location';

export function toPoint(location: Location.LocationObject): GPSPoint {
  return {
    latitude: location.coords.latitude,
    longitude: location.coords.longitude,
    timestamp: location.timestamp,
    accuracy: location.coords.accuracy ?? 999,
    speed: location.coords.speed,
    heading: location.coords.heading
  };
}

if (!TaskManager.isTaskDefined(LOCATION_TASK)) {
  TaskManager.defineTask(LOCATION_TASK, async ({ data, error }) => {
    if (error || !data) return;
    const locations = (data as { locations?: Location.LocationObject[] }).locations ?? [];
    // Die Hintergrundaufzeichnung wird nur nach ausdrücklichem Fahrtstart registriert.
    for (const loc of locations.sort((a, b) => a.timestamp - b.timestamp)) {
      try { await appendGPS(toPoint(loc)); }
      catch (err) { console.warn('GPS-Speicherfehler', err); }
    }
  });
}
