# DrivePulse v0.4 – Karten- und Bußgeldkatalog-Test (17.10.2026)

**Entwicklungsprototyp – keine für den Straßenverkehr validierte Navigations-App.** Aktuelle Ausgabe ersetzt v0.3.1. Die App ist nicht im Store veröffentlicht. Ein Build mit echten iOS-GPS-Daten und eine reale Fahrprobe konnten hier nicht durchgeführt werden. Besonders Tempolimits und Abbiegehinweise bitte zunächst nur im Stand bzw. als Beifahrer testen.

## Neu in 0.4

- **Vektorbasierte dynamische Karte** mit [MapLibre GL JS](https://maplibre.org/maplibre-gl-js/docs/) und [OpenFreeMap](https://openfreemap.org/quick_start/) (ohne API-Key). Dunkle Oberfläche, 2D-Draufsicht und geneigte 3D-Fahrperspektive, Kamerafolgen mit GPS, Fahrzeug-Richtungsmarker und farblich hervorgehobene Routenlinie. Wo Daten vorhanden sind, werden Gebäude als räumliche Extrusion visualisiert. Die 3D-Gebäudehöhen sind Visualisierungen aus Kartendaten, keine garantiert genauen Gebäudehöhen.
- **Umschalter:** 3D, 2D, Tag/Nacht, iOS-Karte. Falls WebGL in Expo Go scheitert, schaltet die App auf die bereits in v0.3.1 erprobte Leaflet-2D-Karte um. Außerdem bleibt die native iOS-Karte als manuelle Auswahl erhalten. MapLibre wird über unpkg.com geladen, die Karte/Schriften über OpenFreeMap. Beides benötigt eine aktive Internetverbindung.
- **Separater Bußgeldkatalog**, im Karten-Footer und im Tacho erreichbar: frei wählbare Überschreitung, innerorts/außerorts, amtlicher **Pkw-Regelsatz** und reguläre Punkte und Fahrverbote. Die offizielle Geldbußentabelle 1(c) der [BKatV](https://www.gesetze-im-internet.de/bkatv_2013/anhang.html), die [FeV Anlage 13](https://www.gesetze-im-internet.de/fev_2010/anlage_13.html) sowie [§ 4 BKatV](https://www.gesetze-im-internet.de/bkatv_2013/__4.html) sind die Quellen (Stand: 17.10.2026).
- **Live-Bußgeldanzeige** verwendet weiterhin das automatisch zugeordnete Straßentempolimit. Wenn Straße, Tempolimit, Ortslage oder GPS nicht eindeutig sind, zeigt die App bewusst „Unbekannt“ oder innerorts-/außerorts-Werte statt einer behaupteten exakten Strafe.
- **Weitere Tests:** 24 reine Logiktests für Bußgelder, Punkte, Fahrverbote, GPS- und Routenfunktionen.

## Wichtige Grenzen der Tempolimit-Erkennung

- Der bisherige **OSM/Overpass-Prototyp** ist als Experiment weiter eingebaut. Tempo-30-Zonen, temporäre Baustellen, Wechselverkehrszeichen, Zeitbedingungen, Beschilderung und einander überlagernde Straßen können nicht überall zuverlässig ermittelt werden. Die Position wird mit OSM-Straßenlinien verglichen; „maxspeed“ kann fehlen. Eine Lücke darf nicht mit einer erfundenen Beschränkung gefüllt werden. Bei uneindeutiger Zuordnung wird daher keine Geschwindigkeit behauptet.
- Die Daten der **amtlichen Bußgeldtabelle** werden lokal mitgeliefert und sind auch offline über den Katalog abrufbar. Eine amtliche und flächendeckende **Echtzeit-Tempolimit-Datenbank** ist hingegen nicht integriert.
- Mapbox bietet in einer Beta-API `maxspeed` über das Map Matching an, **verlangt aber, dass dessen Ergebnis auf einer Mapbox-Karte mit einem Mapbox SDK/einer Mapbox-Bibliothek dargestellt wird**: [Mapbox-Dokumentation](https://docs.mapbox.com/api/navigation/map-matching/). Daher wird diese API **nicht** unzulässig mit der OpenFreeMap-Karte gemischt. Eine spätere lizenzkonforme native Mapbox-Variante erfordert Token/Abrechnung und einen eigenen iOS-Build.
- **Pkw ohne Anhänger**: Bußgeldkatalog gilt in diesem Simulator ausdrücklich nicht für Busse, Lkw oder Sonderfälle. Beim Live-Vergleich wird keine Radartoleranz abgezogen (GPS ist nicht geeicht); Verwaltungsgebühren und Vorsatz, Wiederholungstäterdetails, Probezeit u. a. werden nicht abschließend berücksichtigt.

## Weiterhin aus Version 0.3.1 enthalten

- GPS-Tacho, Nominatim-Zielsuche ohne Autocomplete, OSRM-Demo-Routing, Sprachnavigation (experimentell), begrenzte Routenneuberechnung, manuell startbare Fahrtaufzeichnung, Statistiken und lokale Speicherung.
- **Kein Live-Verkehr**, keine garantierte Routenqualität, keine zuverlässig automatische Fahrterkennung bei geschlossener App, Freunde/Live-Freigabe noch nicht verfügbar.
- **Expo Go unterstützt nicht die benötigte native Hintergrund-Ortung** bei gesperrtem Gerät; dafür ist ein eigener iOS-Development-Build nötig. Auch damit können iOS-Systemlimits die Aufzeichnung einschränken.
- Datenschutz: Fahrten bleiben lokal im AsyncStorage; die aktuelle GPS-Position geht an Overpass für Tempolimits, Start/Ziel an OSRM für Routen; Suchanfragen an Nominatim; Vektorkarten-Anfragen an OpenFreeMap. Diese Betreiber können Anfragen protokollieren. Kein Account und kein Teilen von Nutzerpositionen mit Freunden.
- Die öffentlichen Nominatim-, Overpass- und OSRM-Demo-Endpunkte sind **keine zuverlässige Produktionsinfrastruktur**. Vor breiter Nutzung sind eigene Infrastruktur oder vertraglich geeignete Anbieter erforderlich.

## Test auf deinem iPhone mit GitHub Codespaces

1. `DrivePulse_v0_4.zip` in das Repository `FNCxDR3/DrivePulse` hochladen (GitHub-Website → Upload files → Commit changes). Die bestehende v0.3.1 bleibt unberührt.
2. Bei Bedarf den alten Expo-Prozess im alten Terminal durch `Ctrl+C` stoppen. Neues Terminal öffnen. **Jeden Befehl einzeln** ausführen:

```bash
cd /workspaces/DrivePulse
git pull
unzip -o DrivePulse_v0_4.zip
cd DrivePulse_v0_4
npm install
npx expo install --fix
npx expo start --tunnel --clear --port 8083
```

3. `exp://`-Adresse aus dem Terminal auf dem iPhone in Safari öffnen → **In Expo Go öffnen**. Dieselbe Expo-Anmeldung wie in Codespaces verwenden. Sollte Port 8083 schon belegt sein, im Terminal ein anderes freies Port bestätigen/angeben.
4. Karte → **3D / 2D** testen, Einstellungen **Tag/Nacht**, oben Zieleingabe, unten **€ Katalog**. Noch nicht als alleinige Verkehrsnavigation verwenden.

**Hinweis:** `npm install` wurde in dieser Erstellungsumgebung nicht erfolgreich über die npm-Registry getestet (kein Netzwerkzugriff); daher ist **die vollständige Expo-Kompilierung nicht verifiziert**. Die Datei `App.tsx` und das eingebettete WebView-JavaScript wurden syntaktisch geprüft und alle 24 lokal ausführbaren Logiktests bestanden. Erst der iPhone-Test bestätigt, ob Expo SDK 57, WebView und MapLibre auf deinem Gerät zusammenspielen.

## Quellen

- [Bundesamtliche BKatV Tabelle 1(c)](https://www.gesetze-im-internet.de/bkatv_2013/anhang.html)
- [FeV Anlage 13 – Punkte](https://www.gesetze-im-internet.de/fev_2010/anlage_13.html)
- [BKatV § 4 Abs. 2 – Wiederholung](https://www.gesetze-im-internet.de/bkatv_2013/__4.html)
- [MapLibre Kamera-API](https://maplibre.org/maplibre-gl-js/docs/API/type-aliases/CameraOptions/)
- [OpenFreeMap Quick Start](https://openfreemap.org/quick_start/)
- [OSM-Tile-Policy](https://operations.osmfoundation.org/policies/tiles/) – in v0.4 nicht mehr als Standard-Tile-Service benutzt
- [Mapbox Map Matching maxspeed – Beta und Einschränkungen](https://docs.mapbox.com/api/navigation/map-matching/)
