# DrivePulse v0.6 – kostenloses, regionales Offline-Tempolimit-Paket

**Stand 17. Oktober 2026 · Nicht für sicherheitskritische Navigation zugelassen.** Auf dem iPhone wurde diese neue Version noch nicht getestet. Die integrierte Kartengestaltung ist weiterhin experimentell; der Standardmodus ist die bisher funktionierende OSM-Karte. Offizielle Bußgeldtabellen sind offline hinterlegt. **Die regionalen Geschwindigkeitsdaten werden erst nach einmaliger Datenpaket-Erstellung tatsächlich mitgeliefert – die ZIP enthält noch keinen Geofabrik-Extrakt.**

## Was v0.6 tatsächlich ändert

- Kein ständiger Overpass-Abruf mehr. Die Tempolimit-Erkennung verwendet einen **lokalen JSON-Index** aus Geofabrik/OSM-Wegen in der Region Nürnberg/Fürth/Veitsbronn. Beim Fahrbetrieb werden hierfür keine Koordinaten an Overpass gesendet.
- Index betrachtet Straßenabstand, vorhandene Fahrtrichtung, parallele Straßen, richtungsabhängige Einschränkungen, unsichere und bedingte Limits. Bei nicht eindeutiger Situation: „Unbekannt“, keine erfundene Grenze.
- Ohne einmaligen Datenimport erkennt die App ausdrücklich **keine** Limits; der Profil-Tab zeigt den fehlenden Datenstand an. Vor dem ersten Start **`npm run data:region`** ausführen.
- Bußgeldrechner für **normale Pkw ohne Anhänger** (Deutschland, BKatV Anlage Tabelle 1(c)), mit Punkten und möglichen Regelfahrverboten, bleibt unabhängig vom Kartenstatus nutzbar. Ohne sichere Zuordnung innerorts/außerorts zeigt die App zwei alternative Beträge, keine vorgetäuschte eindeutige Geldbuße.
- GPS-Position und Fahrstatistik bleiben erhalten. Navigation, Adresssuche und Kartenkacheln nutzen weiterhin externe Testdienste. Die 3D-Karte kann weiter ausfallen; ihre zuverlässige Behebung ist **nicht** Teil der Offline-Umstellung.

## Wie die kostenlosen Daten entstehen

Der Geofabrik-Mittelfranken-Extrakt umfasst aktuell ungefähr 90–100 MB `.osm.pbf`. Das Skript lädt ihn **einmalig in den Codespace** und erstellt daraus eine kleinere `src/speed/data/region.json` mit Straßen-Geometrien, `maxspeed`-Attributen und einem räumlichen Index. Die PBF-Zwischendatei wird anschließend gelöscht. Das Datenpaket wird beim Erzeugen ins App-Bundle aufgenommen. Dafür ist **beim Aufbau** Internet nötig, **bei der Geschwindigkeitserkennung** nicht.

Der aktuell programmierte Ausschnitt ist auf eine rechteckige Region begrenzt, ungefähr Längengrad 10,72–11,30 und Breitengrad 49,33–49,65 (einschließlich Fürth, Nürnberg und Veitsbronn). Dies ist **nicht ganz Mittelfranken**. Daten außerhalb dieser Region werden nicht erraten. Die OSM-Rohdaten sind keine behördliche Live-Schilddatenbank und können falsch/veraltet sein.

Quellen: [Geofabrik Mittelfranken](https://download.geofabrik.de/europe/germany/bayern/mittelfranken.html), [OSM-Tag `maxspeed`](https://wiki.openstreetmap.org/wiki/Key:maxspeed), [OSM Lizenz ODbL](https://www.openstreetmap.org/copyright).

## Installation auf dem iPhone via Codespaces + Expo Go

ZIP herunterladen und in das GitHub-Repository `FNCxDR3/DrivePulse` hochladen. `effective carnival`-Codespace öffnen und in einem **neuen Terminal** jede Zeile einzeln ausführen:

```bash
cd /workspaces/DrivePulse
git pull
unzip -o DrivePulse_v0_6.zip
cd DrivePulse_v0_6
npm install
npm run data:region
npm run data:check
npx expo install --fix
npx expo start --tunnel --clear --port 8085
```

Wenn der Server auf Port 8085 bereits belegt ist, nach Aufforderung anderen Port wählen bzw. den alten Prozess zuerst beenden. Expo Go mit demselben Expo-Konto wie Expo CLI verwenden. Expo-Link `exp://...` aus dem Terminal auf dem iPhone öffnen.

**`npm run data:region` ist der entscheidende zusätzliche Schritt.** Er baut unter Linux im Codespace eine lokale Python-Virtualenv, installiert `osmium`, lädt das Geofabrik-PBF und generiert die regionalen Straßendaten. Die Datenpaket-Erzeugung kann je nach Codespace/Netz einige Minuten benötigen. Anschließend sollte `npm run data:check` eine positive Anzahl von Straßen melden. Falls der Geofabrik-Server oder die Paket-Registry nicht erreichbar ist, **bricht dieser Schritt mit Fehlermeldung ab**. Dann ist **noch kein** Offline-Tempolimit verfügbar; bitte nicht mit „vollständig installiert“ verwechseln.

Der Kartendaten-Index verbleibt im Codespace. Er ist **nicht automatisch** in GitHub gesichert. Wenn der Codespace gelöscht wird, ist ein neuer Datenaufbau erforderlich, sofern du den generierten JSON-Index nicht selbst ins Repository commitest.

## Test

```bash
npm run test:logic
python3 tests/test_region_builder.py
```

Die Node-Tests verwenden absichtlich nur synthetische Teststraßen (keine behaupteten echten Tempolimits). Die Python-Tests prüfen den lokalen Parser und seine Geometrie-Filter. **Ein Geofabrik-Download und ein echter GPS-Fahrtest konnten in der Erstellungsumgebung nicht durchgeführt werden.**

## Datenschutz, Lizenz, Grenzen

- Es gibt **keinen API-Key, keine kostenpflichtige API, keine Kontopflicht für Straßendaten**. Geofabrik liefert kostenfreie OSM-Extrakte (Open Database License). MapTiles/Navigation sind weiterhin netzabhängige Dienste anderer Anbieter; sie haben Nutzungsbedingungen und sind derzeit nur für einen privaten Prototyp gedacht.
- Keine Übermittlung der GPS-Position an Overpass für die Tempolimits. Online-Kartentiles werden separat heruntergeladen, Adresssuche (Nominatim/Geräte-Geocoder) und Routenplanung (OSRM-Testdienst) bleiben online.
- Wichtig: Straßenschilder, temporäre Baustellen, Schilderzusätze und elektronische Limitwechsel haben Vorrang. Die App kann eine rechtlich falsche Grenze anzeigen oder „Unbekannt“. Keine echte Blitzerkennung und keine geeichte Geschwindigkeitsmessung.
- Bußgelder sind Regelsätze ohne Messtoleranz-/Gebühren- und Einzelfallbewertung. Rechtsquellen: [BKatV-Anhang Tabelle 1(c)](https://www.gesetze-im-internet.de/bkatv_2013/anhang.html), [FeV Anlage 13](https://www.gesetze-im-internet.de/fev_2010/anlage_13.html), [BKatV §4](https://www.gesetze-im-internet.de/bkatv_2013/__4.html).
- Automatischer Fahrtbeginn, verlässlich laufende Hintergrundortung bei geschlossener App und Freundesfunktionen bleiben **offen**. Expo Go allein reicht für Hintergrund-GPS auf iOS nicht aus.
