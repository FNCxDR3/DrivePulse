import {matchSpeedLimit} from './roadMatching.mjs';

/** The pack is OSM tagging, not a verified representation of every actual traffic sign. */
export function packetStatus(pack, point) {
  if (!pack || pack.schema !== 1 || !pack.roads?.length || !pack.grid || !pack.cellDegrees)
    return {available:false,reason:'Regionales Offline-Straßenpaket fehlt. Einmal „npm run data:region“ ausführen.'};
  const box=pack.bbox;
  if (!Array.isArray(box) || box.length!==4)
    return {available:false,reason:'Straßenpaket enthält keinen gültigen räumlichen Bereich.'};
  if (!Number.isFinite(point?.latitude) || !Number.isFinite(point?.longitude))
    return {available:false,reason:'GPS-Position fehlt.'};
  if (point.longitude < box[0] || point.longitude > box[2] || point.latitude < box[1] || point.latitude > box[3])
    return {available:false,reason:'Außerhalb des geladenen Straßenpakets (Region Nürnberg/Fürth).'};
  return {available:true,reason:'Offline-Straßendaten verfügbar'};
}

export function nearbyOfflineRoads(pack,point) {
  if (!packetStatus(pack,point).available) return [];
  const div=pack.cellDegrees;
  const x=Math.floor(point.latitude/div),y=Math.floor(point.longitude/div);
  const ids=new Set();
  // 1 cell margin so slight GPS drift / roads near boundaries still work.
  for(let i=-1;i<=1;i++) for(let j=-1;j<=1;j++) {
    const key=`${x+i}:${y+j}`;
    for(const id of pack.grid[key] || []) ids.add(id);
  }
  return [...ids].map(id=>pack.roads[id]).filter(Boolean);
}

export function matchOfflineSpeed(pack,point) {
  const ready=packetStatus(pack,point);
  if(!ready.available) return {status:'unknown',reason:ready.reason};
  const roads=nearbyOfflineRoads(pack,point);
  if(!roads.length) return {status:'unknown',reason:'In diesem Kartenabschnitt keine befahrbare Straße gespeichert.'};
  const match=matchSpeedLimit(roads,point);
  if (match.status==='unknown') return match;
  return {...match,source:'OpenStreetMap · lokales Geofabrik-Straßenpaket'};
}
