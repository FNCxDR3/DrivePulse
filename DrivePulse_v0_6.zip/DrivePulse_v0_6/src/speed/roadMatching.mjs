/**
 * Pure OSM road matching for a personal prototype. A GPS point alone cannot always
 * identify the correct road. Ambiguous, conditional and incomplete limits are unknown.
 * OSM geometry is used only for estimating the nearest segment, not reliable map matching.
 */
const ROAD_TYPES = new Set([
  'motorway', 'trunk', 'primary', 'secondary', 'tertiary', 'unclassified',
  'residential', 'living_street', 'service', 'road', 'motorway_link',
  'trunk_link', 'primary_link', 'secondary_link', 'tertiary_link'
]);

const RAD = Math.PI / 180;
const METERS_LAT = 111195;
export function pointDistanceMeters(a, b) {
  const dlat = (a.latitude - b.latitude) * METERS_LAT;
  const dlon = (a.longitude - b.longitude) * METERS_LAT * Math.cos((a.latitude + b.latitude) * RAD / 2);
  return Math.hypot(dlat, dlon);
}

function smallAngleDifference(a, b) {
  return Math.abs(((a - b + 540) % 360) - 180);
}

function segmentDistance(point, first, last) {
  const scale = METERS_LAT * Math.cos(point.latitude * RAD);
  const ax = (first.lon - point.longitude) * scale;
  const ay = (first.lat - point.latitude) * METERS_LAT;
  const bx = (last.lon - point.longitude) * scale;
  const by = (last.lat - point.latitude) * METERS_LAT;
  const dx = bx - ax, dy = by - ay;
  const denom = dx * dx + dy * dy;
  if (denom < 0.01) return { distance: Math.hypot(ax, ay), bearing: null };
  const f = Math.min(1, Math.max(0, -(ax * dx + ay * dy) / denom));
  return {
    distance: Math.hypot(ax + f * dx, ay + f * dy),
    bearing: (Math.atan2(dx, dy) * 180 / Math.PI + 360) % 360
  };
}

/** Parse only unambiguous speed tags. mph is converted to km/h. */
export function parseSpeedValue(value) {
  if (typeof value !== 'string') return { kind: 'unknown' };
  const raw = value.trim().toLowerCase();
  if (raw === 'none') return { kind: 'unlimited' };
  if (raw === 'de:urban') return { kind: 'known', kmh: 50 };
  if (raw === 'de:rural') return { kind: 'known', kmh: 100 };
  if (raw === 'de:living_street') return {kind:'unknown'}; // Schrittgeschwindigkeit ist keine feste Zahl
  if (raw === 'de:motorway') return { kind: 'unlimited' };
  const zone = raw.match(/^de:(?:zone:?|zone)([0-9]{1,3})$/);
  if (zone) return { kind: 'known', kmh: Number(zone[1]) };
  const match = raw.match(/^(\d{1,3})(?:\s*(km\/h|kmh|kph|mph))?$/);
  if (!match) return { kind: 'unknown' };
  const kmh = Math.round(Number(match[1]) * (match[2] === 'mph' ? 1.609344 : 1));
  return kmh > 0 && kmh <= 250 ? { kind: 'known', kmh } : { kind: 'unknown' };
}

/**
 * Returns innerorts/außerorts ONLY if OSM explicitly tags the implicit
 * German context. A street name, road class or GPS point is not sufficient.
 */
export function contextFromTags(tags) {
  const markers = [tags['maxspeed:type'], tags['source:maxspeed'], tags['zone:maxspeed']].filter(x => typeof x === 'string');
  if (markers.some(x => /^DE:urban$/i.test(x))) return 'urban';
  if (markers.some(x => /^DE:rural$|^DE:motorway$/i.test(x))) return 'rural';
  return null;
}

function effectiveSpeed(tags, bearing, heading) {
  // In these cases a fixed displayed number could be legally misleading.
  if (tags['maxspeed:conditional'] || tags['maxspeed:variable'] && tags['maxspeed:variable'] !== 'no' ||
      tags['maxspeed:lanes'] || tags['maxspeed:lanes:forward'] || tags['maxspeed:lanes:backward'] ||
      tags['maxspeed:wet'] || tags['maxspeed:night'] || tags['maxspeed:school'] ||
      tags['maxspeed:conditional:forward'] || tags['maxspeed:conditional:backward'] ||
      tags['maxspeed:forward:conditional'] || tags['maxspeed:backward:conditional']) {
    return {kind:'unknown', reason:'Zeit-, Wetter-, Spur- oder Wechselbeschränkung'};
  }
  let raw = tags['maxspeed:motorcar'] ?? tags.maxspeed;
  if (tags['maxspeed:forward'] || tags['maxspeed:backward']) {
    if (bearing === null || heading === null) return { kind: 'unknown', reason: 'Richtung der Straße nicht sicher' };
    const delta = smallAngleDifference(heading, bearing);
    if (delta >= 65 && delta <= 115) return { kind:'unknown', reason:'Fahrtrichtung nicht sicher' };
    const directional = delta < 90 ? tags['maxspeed:forward'] : tags['maxspeed:backward'];
    if (directional !== undefined) raw = directional;
  }
  // Only explicit source/type is used to infer an implicit limit; no guess
  // based on road class or type of surroundings.
  if (raw === undefined) raw = tags['maxspeed:type'] ?? tags['source:maxspeed'] ?? tags['zone:maxspeed'];
  const result = parseSpeedValue(raw);
  return result.kind === 'unknown' ? {...result, reason:'Kein eindeutiger Tempolimit-Datensatz'} : result;
}

/** @param {Array<{id:number,tags:object,geometry:{lat:number,lon:number}[]}>} roads */
export function matchSpeedLimit(roads, point) {
  if (!point || !Number.isFinite(point.latitude) || !Number.isFinite(point.longitude) ||
      !Number.isFinite(point.accuracy) || point.accuracy < 0 || point.accuracy > 25) {
    return {status:'unknown', reason:'GPS-Signal zu ungenau'};
  }
  const candidates = [];
  const heading = Number.isFinite(point.heading) && point.heading >= 0 && point.heading < 360 && point.speedKmh >= 12
    ? point.heading : null;
  for (const road of roads || []) {
    if (!road?.tags || !ROAD_TYPES.has(road.tags.highway) || !Array.isArray(road.geometry) || road.geometry.length < 2) continue;
    if (road.tags.access === 'no' || road.tags.motor_vehicle === 'no' || road.tags.motorcar === 'no') continue;
    let best = null;
    for (let i = 1; i < road.geometry.length; i++) {
      const c = segmentDistance(point, road.geometry[i-1], road.geometry[i]);
      if (!best || c.distance < best.distance) best = c;
    }
    if (!best) continue;
    const maxDistance = Math.min(32, Math.max(12, point.accuracy + 8));
    if (best.distance > maxDistance) continue;
    if (heading !== null && best.bearing !== null) {
      const direction = smallAngleDifference(heading, best.bearing);
      const deviation = road.tags.oneway === 'yes' ? direction :
          road.tags.oneway === '-1' ? Math.abs(180 - direction) : Math.min(direction, 180 - direction);
      if (deviation > 60) continue;
    }
    const resolved = effectiveSpeed(road.tags, best.bearing, heading);
    candidates.push({road, distance:best.distance, resolved});
  }
  candidates.sort((a,b) => a.distance - b.distance);
  if (!candidates.length) return {status:'unknown', reason:'Keine Straße sicher zugeordnet'};
  const winner = candidates[0];
  // At intersections, parallel streets and stacked roads the nearest line
  // cannot uniquely determine the legal speed limit.
  const competing = candidates.find((c, i) => i > 0 && c.distance <= winner.distance + 10 &&
      (c.resolved.kind !== winner.resolved.kind || c.resolved.kmh !== winner.resolved.kmh));
  if (competing) return {status:'unknown', reason:'Mehrere mögliche Straßen mit unterschiedlichen Tempolimits'};
  const context = contextFromTags(winner.road.tags);
  const roadName = typeof winner.road.tags.name === 'string' ? winner.road.tags.name : 'Straße ohne Namen';
  if (winner.resolved.kind === 'unlimited') return {status:'unlimited', roadName, context, source:'OpenStreetMap'};
  if (winner.resolved.kind === 'known') return {status:'known', kmh:winner.resolved.kmh, roadName, context, source:'OpenStreetMap'};
  return {status:'unknown', reason:winner.resolved.reason, roadName};
}
