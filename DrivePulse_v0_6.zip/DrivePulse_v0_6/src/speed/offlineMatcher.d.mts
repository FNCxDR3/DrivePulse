import type { RoadPoint, MatchedLimit, OsmRoad } from './roadMatching.mjs';
export type OfflinePack = {schema:number;name:string;generatedAt:string|null;source:string;bbox:number[];cellDegrees:number;roads:OsmRoad[];grid:Record<string,number[]>};
export function packetStatus(pack:OfflinePack,point:RoadPoint):{available:boolean;reason:string};
export function nearbyOfflineRoads(pack:OfflinePack,point:RoadPoint):OsmRoad[];
export function matchOfflineSpeed(pack:OfflinePack,point:RoadPoint):MatchedLimit;
