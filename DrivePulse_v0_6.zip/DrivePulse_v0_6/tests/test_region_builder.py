"""Tests geo indexing/filtering without pretending to have downloaded Geofabrik data."""
import importlib.util
import sys
import types
import pathlib
import unittest

fake=types.ModuleType('osmium')
fake.SimpleHandler=type('SimpleHandler',(object,),{})
fake.InvalidLocationError=ValueError
sys.modules['osmium']=fake
spec=importlib.util.spec_from_file_location('builder',pathlib.Path(__file__).parents[1]/'scripts'/'build_region.py')
builder=importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)

class Tags(list):pass
class Node:
    def __init__(self, lat, lon):self.lat=lat;self.lon=lon;self.location=self
    def valid(self):return True
class Road:
    def __init__(self,id,tags,coords):
        self.id=id
        self.tags=[types.SimpleNamespace(k=k,v=v) for k,v in tags.items()]
        self.nodes=[Node(*pt) for pt in coords]

class OfflineBuilderTests(unittest.TestCase):
    def test_only_real_road_geom_is_kept(self):
        handler=builder.Roads()
        handler.way(Road(12,{'highway':'residential','maxspeed':'30','name':'Testweg','amenity':'x'},[(49.477,10.998),(49.478,10.998)]))
        handler.way(Road(22,{'highway':'footway','maxspeed':'30'},[(49.477,10.999),(49.478,10.999)]))
        handler.way(Road(33,{'highway':'residential','maxspeed':'40'},[(48,10.998),(48.001,10.998)]))
        self.assertEqual(len(handler.roads),1)
        self.assertEqual(handler.roads[0]['tags']['maxspeed'],'30')
        self.assertNotIn('amenity',handler.roads[0]['tags'])
        key=builder.cellkey(49.477,10.998)
        self.assertIn(0,handler.grid[key])

if __name__=='__main__':unittest.main()
