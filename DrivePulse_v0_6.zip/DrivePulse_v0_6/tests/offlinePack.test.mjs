import test from 'node:test';
import assert from 'node:assert/strict';
import {packetStatus,nearbyOfflineRoads,matchOfflineSpeed} from '../src/speed/offlineMatcher.mjs';
const center={latitude:49.477,longitude:10.998,accuracy:6,heading:0,speedKmh:48};
const road=(id,limit,lon=10.998)=>({id,tags:{highway:'residential',name:`Weg ${id}`,maxspeed:limit,'source:maxspeed':'DE:urban'},geometry:[{lat:49.4769,lon},{lat:49.4771,lon}]});
const pack={schema:1,name:'Testpaket',generatedAt:'test',source:'test',bbox:[10.9,49.4,11.2,49.55],cellDegrees:.005,roads:[road(1,'30')],grid:{}};
const key=(lat,lon)=>`${Math.floor(lat/.005)}:${Math.floor(lon/.005)}`;
pack.grid[key(49.477,10.998)]=[0];
test('missing data remains unknown; never pretend limits exist',()=>{
 assert.equal(matchOfflineSpeed({...pack,roads:[]},center).status,'unknown');
 assert.equal(packetStatus(pack,{...center,longitude:12}).available,false);
});
test('pack indexes roads by geographic grid, not location upload',()=>{
 assert.equal(nearbyOfflineRoads(pack,center).length,1);
 assert.equal(matchOfflineSpeed(pack,center).kmh,30);
 assert.match(matchOfflineSpeed(pack,center).source,/lokales/);
});
test('out-of-region locations do not inherit nearby limits',()=>{
 const r=matchOfflineSpeed(pack,{...center,longitude:11.6});
 assert.equal(r.status,'unknown');assert.match(r.reason,/Außerhalb/);
});
test('ambiguous parallel road remains unknown even with a valid stored 30',()=>{
 const extra=road(2,'50',10.99805); const alt={...pack,roads:[...pack.roads,extra],grid:{[key(49.477,10.998)]:[0,1]}};
 assert.equal(matchOfflineSpeed(alt,center).status,'unknown');
});
test('conditional restrictions cannot be treated as constant offline',()=>{
 const alt={...pack,roads:[{...pack.roads[0],tags:{...pack.roads[0].tags,'maxspeed:conditional':'20 @ (Mo-Fr 07:00-16:00)'}}]};
 assert.equal(matchOfflineSpeed(alt,center).status,'unknown');
});
