import fs from 'node:fs';
const p=JSON.parse(fs.readFileSync(new URL('../src/speed/data/region.json',import.meta.url)));
console.log(p.roads?.length? `Offline-Paket: ${p.name}; ${p.roads.length} Straßen; Stand ${p.generatedAt}`:'Kein Offline-Straßenpaket installiert. Bitte npm run data:region ausführen.');
