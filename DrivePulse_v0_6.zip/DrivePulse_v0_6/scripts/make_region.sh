#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "Erstelle Python-Umgebung für das einmalige Verarbeiten der Geofabrik-Daten …"
python3 -m venv .osmvenv
.osmvenv/bin/python -m pip -q install --disable-pip-version-check osmium
.osmvenv/bin/python scripts/build_region.py "$@"
