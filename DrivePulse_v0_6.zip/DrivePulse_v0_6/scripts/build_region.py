#!/usr/bin/env python3
"""Offline OSM speed-tag subset for Fürth / Nürnberg / Veitsbronn.

Downloads official Geofabrik Mittelfranken extract, WITHOUT invented road data.
Install pyosmium in Codespaces via `npm run data:region`.
The source is a map of OSM way tags, not the actually signposted legal speed.

Generated JSON is automatically included in subsequent Expo Metro reloads.
"""
import argparse
import datetime as dt
import gzip
import json
import math
import os
import pathlib
import shutil
import tempfile
import urllib.request

try:
    import osmium
except ImportError:
    raise SystemExit('Das Paket osmium fehlt. Bitte npm run data:region ausführen.')

URL = 'https://download.geofabrik.de/europe/germany/bayern/mittelfranken-latest.osm.pbf'
HERE = pathlib.Path(__file__).resolve().parent.parent
OUTPUT = HERE / 'src' / 'speed' / 'data' / 'region.json'
# Include Veitsbronn, Fürth, Erlangen south and Nürnberg city/outer districts.
BBOX = (10.72, 49.33, 11.30, 49.65)  # minlon, minlat, maxlon, maxlat
CELL = 0.005
HIGHWAYS = {
    'motorway','trunk','primary','secondary','tertiary','unclassified',
    'residential','living_street','service','road','motorway_link','trunk_link',
    'primary_link','secondary_link','tertiary_link'
}
SPEED_KEYS = {
    'highway','name','oneway','access','motor_vehicle','motorcar',
    'maxspeed','maxspeed:type','source:maxspeed','zone:maxspeed',
    'maxspeed:forward','maxspeed:backward','maxspeed:motorcar',
    'maxspeed:conditional','maxspeed:variable','maxspeed:lanes',
    'maxspeed:lanes:forward','maxspeed:lanes:backward',
    'maxspeed:wet','maxspeed:night','maxspeed:school', 'maxspeed:advisory',
    'maxspeed:conditional:forward','maxspeed:conditional:backward',
    'maxspeed:forward:conditional','maxspeed:backward:conditional',
    'maxspeed:hgv','maxspeed:trailer'
}

def cellkey(lat,lon):
    return f'{math.floor(lat/CELL)}:{math.floor(lon/CELL)}'

def geometry_keys(geometry):
    seen = set()
    for p,q in zip(geometry, geometry[1:]):
        a,b=sorted((math.floor(p['lat']/CELL),math.floor(q['lat']/CELL)))
        c,d=sorted((math.floor(p['lon']/CELL),math.floor(q['lon']/CELL)))
        # include adjacent cells at segment/boundary as a conservative margin
        for la in range(a-1,b+2):
            for lo in range(c-1,d+2):
                seen.add(f'{la}:{lo}')
    return seen

class Roads(osmium.SimpleHandler):
    def __init__(self):
        super().__init__()
        self.roads=[]
        self.grid={}
        self.segments=0
    def way(self, w):
        tags = {t.k:t.v for t in w.tags if t.k in SPEED_KEYS}
        if tags.get('highway') not in HIGHWAYS:return
        if len(w.nodes) < 2:return
        try:
            geom=[{'lat':round(n.lat,6),'lon':round(n.lon,6)} for n in w.nodes if n.location.valid()]
        except (osmium.InvalidLocationError, ValueError): return
        if len(geom)<2:return
        # Only retain ways intersecting regional bbox (with small margin).
        if min(n['lon'] for n in geom)>BBOX[2]+.008 or max(n['lon'] for n in geom)<BBOX[0]-.008:return
        if min(n['lat'] for n in geom)>BBOX[3]+.008 or max(n['lat'] for n in geom)<BBOX[1]-.008:return
        idx=len(self.roads)
        self.roads.append({'id':int(w.id),'tags':tags,'geometry':geom})
        self.segments+=len(geom)-1
        for key in geometry_keys(geom):
            self.grid.setdefault(key,[]).append(idx)

def main():
    parser=argparse.ArgumentParser(description='Mittelfranken-Straßen aus originalen OSM-Daten verarbeiten')
    parser.add_argument('--pbf',help='Bereits vorhandenes Geofabrik-PBF (kein Download nötig)')
    args=parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='drivepulse_osm_') as tmp:
        if args.pbf:
            pbf=pathlib.Path(args.pbf)
            if not pbf.is_file(): raise SystemExit(f'PBF nicht gefunden: {pbf}')
        else:
            pbf=pathlib.Path(tmp)/'mittelfranken.osm.pbf'
            print('Lade Mittelfranken von Geofabrik (ca. 91–100 MB). Das kann dauern …',flush=True)
            req=urllib.request.Request(URL,headers={'User-Agent':'DrivePulse offline regional speed pack personal prototype (https://github.com/FNCxDR3/DrivePulse)'})
            with urllib.request.urlopen(req,timeout=120) as response, pbf.open('wb') as dest:
                shutil.copyfileobj(response,dest)
            print(f'Quelle geladen: {pbf.stat().st_size/1e6:.1f} MB',flush=True)
        handler=Roads()
        print('Filtere Straßen und Tempolimit-Tags…',flush=True)
        handler.apply_file(str(pbf),locations=True)
        if not handler.roads:raise SystemExit('Abbruch: Keine Straßen gefunden; bisheriges Paket bleibt unangetastet.')
        result={
          'schema':1,'name':'Region Nürnberg / Fürth / Veitsbronn',
          'generatedAt':dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds'),
          'source':'Geofabrik Mittelfranken, © OpenStreetMap-Mitwirkende (ODbL 1.0)',
          'sourceUrl':URL,'bbox':list(BBOX),'cellDegrees':CELL,
          'roads':handler.roads,'grid':handler.grid
        }
        OUTPUT.parent.mkdir(parents=True,exist_ok=True)
        staging=OUTPUT.with_suffix('.json.tmp')
        with staging.open('w',encoding='utf-8') as stream:
            json.dump(result,stream,ensure_ascii=False,separators=(',',':'))
        os.replace(staging,OUTPUT)
        print(f'FERTIG: {len(handler.roads)} Straßen, {handler.segments} Segmente, {OUTPUT.stat().st_size/1e6:.1f} MB',flush=True)
        print('Keine API-Abfrage pro Fahrt. Bei neuer Karte App mit Expo neu starten.',flush=True)

if __name__=='__main__':main()
