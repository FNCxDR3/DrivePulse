# DrivePulse 0.3 – Navigationstest (17.10.2026)

**Status: Entwicklungsprototyp, keine verkehrssichere oder produktionsreife Navigations-App.** Der Quellcode ist auf iOS/Android mit Expo SDK 57 ausgelegt. Tests der GPS- und Routinglogik sind automatisiert; ein vollständiger iOS-/Android-Build und eine echte Straßenfahrt wurden für Version 0.3 **noch nicht durchgeführt**.

## Implementiert

- **Live-Karte** über `react-native-maps` (Apple Maps auf iOS) mit GPS-Punkt, Folgen/Zentrieren, Kameraansicht beim Navigieren und einer blauen Routenlinie.
- **Zielsuche** nach Adressen/Orten **nur nach manueller Suchauslösung**, ohne Autocomplete über Nominatim. Während gemessener Fahrt gesperrt.
- **Route berechnen und starten** über die öffentliche OSRM-Testinstanz; Straßenlinien, Abbiegehinweise auf Deutsch, verbleibende Strecke und überschlägige Restzeit. **Kein Live-Verkehr oder Online-Staumeldungen**. Bei deutlicher und mehrfach gemessener Routenabweichung erfolgt eine begrenzte Neuberechnung. Experimentelle **Sprachansage** via Expo Speech (iOS benötigt aktivierten Ton).
- **Live-Tacho per GPS** und automatische Abfrage der im OSM-Straßenobjekt hinterlegten Höchstgeschwindigkeit. Kein manueller Tempolimit-Wähler. Bei fehlendem/uneindeutigem Limit steht „unbekannt“; Beschilderung und Wetterregeln gehen vor.
- **Bußgeld-Simulator für normale Pkw** nach BKatV Anhang Tabelle 1(c), mit Punkten und Regelfahrverbot aus FeV Anlage 13; abhängig von gesicherter Innerorts-/Außerorts-Zuordnung. Bei unbekannter Ortslage zeigt er beide Bußgeldbeträge. **Ohne behördlichen Messtoleranzabzug, Verfahrenskosten oder Sondertatbestände.** Keine Geschwindigkeitsmessung in amtlicher Qualität. Regel zum möglichen Fahrverbot bei wiederholtem Verstoß vereinfacht bezeichnet, keine individuelle rechtliche Bewertung.
- **Manuell startbare Fahrtaufzeichnung** unabhängig von aktiver Navigation, gespeicherte GPS-Route, Dauer, Distanz und Spitze. Tages-, Wochen-, Monats-, Gesamtauswertung, Löschung. Fahrten liegen lokal im AsyncStorage. **Keine automatische Fahrterkennung ohne App-Start**.
- **Hintergrundaufzeichnung** im Quellcode vorbereitet, aber **nicht über Expo Go** verfügbar, sondern erst in einem nativen Development Build testbar. Ein von Nutzerseite vollständig beendeter Prozess wird nicht zuverlässig weiter aufzeichnen.
- Freunde, Profile, Challenges und Live-Standortfreigabe sind noch **nicht** implementiert (nur Platzhalter).

## Quellen und Grenzen

- [Bundesrecht: Bußgeldkatalog-Verordnung, Anhang Tabelle 1](https://www.gesetze-im-internet.de/bkatv_2013/anhang.html), Stand 17.10.2026.
- [Bundesrecht: FeV Anlage 13](https://www.gesetze-im-internet.de/fev_2010/anlage_13.html) Punkte.
- [Expo: Location](https://docs.expo.dev/versions/latest/sdk/location/); Background Location erfordert einen Development Build.
- [Expo: react-native-maps](https://docs.expo.dev/versions/latest/sdk/map-view/).
- [OSRM Route API](https://project-osrm.org/docs/v26.5.0/http).
- [Nominatim Nutzungsregeln](https://operations.osmfoundation.org/policies/nominatim/) – höchstens eine Anfrage/s, **keine** Autocomplete-Abfragen. Die öffentliche Instanz hat keine Betriebsgarantie und ist nicht für breite App-Nutzung gedacht.
- [OpenStreetMap Lizenz](https://www.openstreetmap.org/copyright), © OpenStreetMap-Mitwirkende (ODbL).

**Wichtige Grenzen:** Öffentliche OSM-Daten sind unvollständig oder veraltet; eine GPS-Position kann nicht sicher die richtige Fahrspur und die geltende Höchstgeschwindigkeit identifizieren. Gerade bei Baustellen, variablen Schildern, Kreuzungen und komplexen Straßen gilt die reale Beschilderung. Routingservice, Overpass und Nominatim sind **nicht für produktiven Einsatz**, größere Nutzerzahlen oder garantierte Echtzeit geeignet. Vor Veröffentlichung ist ein kommerziell betriebener Routing-/Geocoding- und Speed-Limit-Dienst oder eigene Infrastruktur nötig. Kein vollwertiger Ersatz für Google Maps.

## Datenschutz

- Lokale Fahrtenhistorie wird derzeit ohne zusätzliche Ende-zu-Ende-Verschlüsselung im AsyncStorage abgelegt.
- Aktuelle präzise GPS-Position wird für das Tempolimit an Overpass übertragen.
- Suchanfragen gehen an Nominatim; Start-/Zielkoordinaten der Route an den OSRM-Demodienst. Diese Betreiber können Zugriffe protokollieren. Es wird **keine automatische Synchronisation deiner Fahrtenhistorie** durchgeführt.
- Es gibt aktuell keine Benutzerkonten oder live geteilte Standorte.

## Auf dem iPhone mit GitHub Codespaces testen

1. ZIP-Datei `DrivePulse_v0_3.zip` ins Repository hochladen, sodass sie neben `DrivePulse_v0_2.zip` liegt. Danach in Codespaces das Terminal verwenden:

   ```bash
   cd /workspaces/DrivePulse
   git pull
   unzip -o DrivePulse_v0_3.zip
   cd DrivePulse_v0_3
   npm install
   npx expo install --fix
   npx expo login
   npx expo start --tunnel --clear
   ```

2. Vorher **alten Expo-Server per Ctrl+C beenden**, sonst verwendet Expo einen weiteren Port und eine neue `exp://`-Adresse. In Expo Go dasselbe Expo-Konto wie im Terminal verwenden; `exp://`-Adresse öffnen.
3. In DrivePulse zur **Karte** wechseln, GPS erlauben, auf das Fadenkreuz tippen, ein Ziel eingeben und **Suchen** drücken, dann einen Treffer und **Navigation starten** auswählen.
4. Noch nicht im Straßenverkehr darauf verlassen – zunächst stationär und anschließend nur als Beifahrer testen. Ein Fahrer darf das Handy während der Fahrt nicht bedienen.

**Tests:** `npm run test:logic` für 21 automatisierte Logiktests. Am Erstellungsort waren die npm-Registry und ein vollständiger React-Native-Build nicht verfügbar. Daher wurde nur die TypeScript-Syntax geparst; die erfolgreiche Kompilierung der gesamten App und die Laufzeit im Expo Go **kann nicht bestätigt werden**.
