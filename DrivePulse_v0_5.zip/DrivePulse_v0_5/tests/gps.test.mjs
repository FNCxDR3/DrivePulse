import test from 'node:test';
import assert from 'node:assert/strict';
import {gpsFixState, speedFromFixes} from '../src/gps/fix.mjs';
const t=1700000000000;
const p={latitude:49.475,longitude:10.99,timestamp:t,accuracy:5,speed:null};
test('Location permission alone is not a GPS fix',()=>{
 assert.equal(gpsFixState(null,t).ok,false);
 assert.equal(gpsFixState(p,t).ok,true);
 assert.equal(gpsFixState(p,t+31000).ok,false);
 assert.equal(gpsFixState({...p,accuracy:85},t).ok,false);
 assert.equal(gpsFixState({...p,latitude:999},t).ok,false);
});
test('GPS speed uses actual native meters/second first',()=>{
 assert.ok(Math.abs(speedFromFixes(null,{...p,speed:10})-36)<1e-9);
 assert.equal(speedFromFixes(null,p),null);
});
test('GPS fallback only when two accurate fixes have meaningful motion',()=>{
 const moved={...p,longitude:10.9905,timestamp:t+5000,accuracy:5};
 const speed=speedFromFixes(p,moved);
 assert.ok(speed>20&&speed<40);
 assert.equal(speedFromFixes({...p,accuracy:100},moved),null);
 assert.equal(speedFromFixes(p,{...p,timestamp:t+5000}),null);
 assert.equal(speedFromFixes(p,{...moved,timestamp:t+30000}),null);
});
