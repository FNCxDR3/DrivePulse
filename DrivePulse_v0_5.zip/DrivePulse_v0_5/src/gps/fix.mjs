/** Pure diagnostic helpers; GPS speed is not a calibrated police measurement. */
const toRad = x => x*Math.PI/180;
export function isValidCoordinate(p) {
  return !!p && Number.isFinite(p.latitude) && Number.isFinite(p.longitude) &&
    Math.abs(p.latitude)<=90 && Math.abs(p.longitude)<=180;
}
export function gpsFixState(p, now = Date.now()) {
  if (!isValidCoordinate(p) || !Number.isFinite(p.timestamp)) return {ok:false,reason:'Noch keine GPS-Position empfangen'};
  const age = now-p.timestamp;
  if (age < -10000 || age > 30000) return {ok:false,reason:'GPS-Position veraltet'};
  if (!Number.isFinite(p.accuracy) || p.accuracy<0 || p.accuracy>35)
    return {ok:false,reason:'GPS ungenau (±'+Math.round(p.accuracy||0)+' m)'};
  return {ok:true,reason:'GPS live · ±'+Math.round(p.accuracy)+' m'};
}
function distance(a,b){
  const lat1=toRad(a.latitude),lat2=toRad(b.latitude);
  const dlat=lat2-lat1,dlon=toRad(b.longitude-a.longitude);
  const h=Math.sin(dlat/2)**2+Math.cos(lat1)*Math.cos(lat2)*Math.sin(dlon/2)**2;
  return 12742000*Math.asin(Math.min(1,Math.sqrt(h)));
}
/** Prefer native device speed; derive speed from two accurate fixes only on meaningful movement. */
export function speedFromFixes(previous,current){
  if(!isValidCoordinate(current)) return null;
  if(Number.isFinite(current.speed)&&current.speed>=0&&current.speed<=70) return current.speed*3.6;
  if(!previous||!isValidCoordinate(previous)) return null;
  if(![previous.accuracy,current.accuracy,previous.timestamp,current.timestamp].every(Number.isFinite)) return null;
  if(previous.accuracy>15||current.accuracy>15) return null;
  const dt=(current.timestamp-previous.timestamp)/1000;
  if(dt<1||dt>15) return null;
  const m=distance(previous,current);
  if(m<Math.max(8,previous.accuracy+current.accuracy)) return null;
  const kmh=m/dt*3.6;
  return kmh<=250?kmh:null;
}
