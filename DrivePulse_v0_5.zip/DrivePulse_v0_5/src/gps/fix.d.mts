export type Fix = {latitude:number; longitude:number;timestamp:number; accuracy:number;speed?:number|null};
export function gpsFixState(p:Fix|null|undefined, now?:number):{ok:boolean;reason:string};
export function speedFromFixes(previous:Fix|null,current:Fix):number|null;
