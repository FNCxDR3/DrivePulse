import type { OsmRoad } from './roadMatching.mjs';

/**
 * Test-only OpenStreetMap speed-tag lookup. Overpass servers serve the SAME
 * contributor-maintained OSM dataset; they are not independent verification.
 * Calls send current coordinates to the selected server and are rate limited
 * in App.tsx. Do not treat as a production/live traffic-sign service.
 */
const ENDPOINTS = [
  'https://overpass.private.coffee/api/interpreter',
  'https://overpass-api.de/api/interpreter'
];
function isRoad(x: unknown): x is OsmRoad {
  if (!x || typeof x !== 'object') return false;
  const v = x as Partial<OsmRoad>;
  return Number.isSafeInteger(v.id) && !!v.tags && typeof v.tags === 'object' &&
    Array.isArray(v.geometry) && v.geometry.length >= 2 && v.geometry.length <= 12000;
}
async function fetchOne(endpoint: string, query: string): Promise<OsmRoad[]> {
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), 11000);
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'User-Agent':'DrivePulsePrototype/0.5 (+https://github.com/FNCxDR3/DrivePulse)'
      },
      body: 'data=' + encodeURIComponent(query),
      signal: abort.signal
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const json: unknown = await response.json();
    if (!json || typeof json !== 'object' || !('elements' in json) || !Array.isArray(json.elements))
      throw new Error('Kartendienst liefert ungültiges JSON');
    return (json.elements as unknown[]).filter(isRoad).slice(0,350);
  } finally {clearTimeout(timer);}
}
export async function queryOsmRoads(latitude: number, longitude: number): Promise<OsmRoad[]> {
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude)>90 || Math.abs(longitude)>180)
    throw new Error('GPS-Position ungültig');
  const query = `[out:json][timeout:10];way(around:180,${latitude.toFixed(6)},${longitude.toFixed(6)})["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|service|living_street|road|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$"];out tags geom;`;
  const failures: string[] = [];
  for (const endpoint of ENDPOINTS) {
    try {return await fetchOne(endpoint, query);}
    catch (e) {failures.push(new URL(endpoint).hostname + ': ' + (e instanceof Error ? e.message : 'nicht erreichbar'));}
  }
  throw new Error('Beide OSM-Server nicht erreichbar (' + failures.join('; ') + ')');
}
