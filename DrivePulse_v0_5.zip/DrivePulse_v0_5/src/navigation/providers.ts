import { parseRouteResponse } from './routing.mjs';

/** External DEMO SERVICES ONLY. Replace with a production SLA before public release. */
export type GeoDestination = { id: string; name: string; latitude: number; longitude: number };
export type GeoPoint = {latitude:number; longitude:number};

async function fetchJson(url: string, headers: Record<string,string> = {}, timeoutMs = 14000): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {signal:controller.signal, headers});
    if (!response.ok) throw new Error(`Kartendienst HTTP ${response.status}`);
    return await response.json();
  } finally {clearTimeout(timer);}
}

/** Nominatim public instance: explicit searches ONLY, max 1 request/s and no autocomplete. */
let lastSearchAt = 0;
export async function searchDestinations(query: string, near?: GeoPoint | null): Promise<GeoDestination[]> {
  const q = query.trim();
  if (q.length < 3) throw new Error('Bitte mindestens drei Zeichen als Ziel eingeben.');
  if (Date.now() - lastSearchAt < 1200) throw new Error('Bitte eine Sekunde vor der nächsten Suche warten.');
  lastSearchAt = Date.now();
  // Prefer nearby results without restricting the search to the current city.
  const bias = near && Number.isFinite(near.latitude) && Number.isFinite(near.longitude) ?
    `&viewbox=${(near.longitude-0.5).toFixed(5)},${(near.latitude+0.4).toFixed(5)},${(near.longitude+0.5).toFixed(5)},${(near.latitude-0.4).toFixed(5)}&bounded=0` : '';
  const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&addressdetails=1&accept-language=de&q=' + encodeURIComponent(q) + bias;
  const result = await fetchJson(url, {
    'Accept-Language':'de',
    'User-Agent':'DrivePulsePrototype/0.5 (https://github.com/FNCxDR3/DrivePulse)',
  }, 16000);
  if (!Array.isArray(result)) throw new Error('Der Suchdienst hat eine ungültige Antwort geliefert.');
  return result.filter((x:unknown): x is Record<string,unknown> => !!x && typeof x === 'object')
    .map(x => ({ id:String(x.place_id || x.osm_id || ''), name:String(x.display_name || ''),
      latitude:Number(x.lat), longitude:Number(x.lon) }))
    .filter(x => Number.isFinite(x.latitude) && Number.isFinite(x.longitude) && x.name.length > 0).slice(0,8);
}

export async function getDrivingRoute(from: GeoPoint, to: GeoPoint) {
  const valid = (p:GeoPoint) => Number.isFinite(p.latitude) && Math.abs(p.latitude) <= 90 && Number.isFinite(p.longitude) && Math.abs(p.longitude) <= 180;
  if (!valid(from) || !valid(to)) throw new Error('Die GPS- oder Zielkoordinaten sind ungültig.');
  const points = [from,to].map(p => `${p.longitude.toFixed(6)},${p.latitude.toFixed(6)}`).join(';');
  const url = `https://router.project-osrm.org/route/v1/driving/${points}?overview=full&geometries=geojson&steps=true`;
  return parseRouteResponse(await fetchJson(url, {}, 18000));
}
