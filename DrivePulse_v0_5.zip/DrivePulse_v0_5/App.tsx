import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, AppState, Linking, Modal, Pressable, ScrollView,
  StatusBar, StyleSheet, Text, View, TextInput, Keyboard, Platform
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Marker, Polyline, type Region } from 'react-native-maps';
import { WebView } from 'react-native-webview';
import { DRIVE_MAP_HTML } from './src/map/driveMapHtml';
import { LEAFLET_HTML } from './src/map/leafletHtml';
import * as Location from 'expo-location';
import * as Speech from 'expo-speech';
import * as TaskManager from 'expo-task-manager';
import { appendGPS, clearTrips, finishTrip, getTrips, setTrackingMode, startTrip } from './src/tracking/store';
import { LOCATION_TASK, toPoint } from './src/tracking/backgroundTask';
import type { GPSPoint, Trip, TripData } from './src/tracking/types';
import { fineForCar, sanctionForCar, formatDuration } from './src/logic/metrics.mjs';
import { gpsFixState, speedFromFixes } from './src/gps/fix.mjs';
import { matchSpeedLimit, pointDistanceMeters } from './src/speed/roadMatching.mjs';
import type { MatchedLimit, OsmRoad, RoadPoint } from './src/speed/roadMatching.mjs';
import { queryOsmRoads } from './src/speed/osmProvider';
import { searchDestinations, getDrivingRoute, type GeoDestination } from './src/navigation/providers';
import { routeProgress, maneuverInstruction, metersLabel, type DrivingRoute } from './src/navigation/routing.mjs';

const C = {
  bg: '#0B111D', panel: '#152235', panel2: '#1B2D45', border: '#2C4057',
  white: '#F8FAFD', muted: '#A2B6CB', accent: '#43DBC4', amber: '#FFBD68', red: '#FF747A'
};
const DEFAULT_REGION: Region = { latitude: 51.16, longitude: 10.45, latitudeDelta: 5, longitudeDelta: 5 };
const INITIAL_DATA: TripData = { active: null, trips: [] };
type Page = 'Karte' | 'Tacho' | 'Statistik' | 'Freunde' | 'Profil';
type Period = 'Heute' | 'Woche' | 'Monat' | 'Gesamt';

function fmtKm(meters: number) { return (meters / 1000).toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 }); }
function fmtSpeed(kmh: number) { return Math.round(Math.max(0, kmh)).toLocaleString('de-DE'); }
function fmtDate(date: number) { return new Date(date).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function elapsedMs(trip: Trip, now: number) { return Math.max(0, (trip.endedAt ?? now) - trip.startedAt); }
function calcMeanKmh(trip: Trip, now: number) { const hours = elapsedMs(trip, now) / 3600000; return hours > 0 ? trip.distanceMeters / 1000 / hours : 0; }
function withinPeriod(trip: Trip, period: Period, now: number) {
  const day = new Date(now); const start = new Date(day);
  if (period === 'Gesamt') return true;
  start.setHours(0, 0, 0, 0);
  if (period === 'Woche') start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  if (period === 'Monat') start.setDate(1);
  return trip.startedAt >= start.getTime();
}

function Chip({ children, active, onPress }: {children: React.ReactNode; active?: boolean; onPress: () => void}) {
  return <Pressable onPress={onPress} style={[styles.chip, active && styles.chipActive]}>
    <Text style={[styles.chipText, active && styles.chipTextActive]}>{children}</Text>
  </Pressable>;
}
function MainButton({ label, onPress, danger = false, disabled = false }: {label: string; onPress: () => void; danger?: boolean; disabled?: boolean}) {
  return <Pressable disabled={disabled} onPress={onPress} style={[styles.mainButton, danger && styles.dangerButton, disabled && {opacity: .5}]}>
    <Text style={[styles.mainButtonText, danger && {color: C.white}]}>{label}</Text>
  </Pressable>;
}
function Label({children}: {children: React.ReactNode}) { return <Text style={styles.label}>{children}</Text>; }
function Metric({ label, value, unit }: {label: string; value: string | number; unit?: string}) {
  return <View style={styles.metric}><Text style={styles.metricLabel}>{label}</Text>
    <View style={styles.metricNumber}><Text style={styles.metricValue}>{value}</Text>
      {!!unit && <Text style={styles.metricUnit}> {unit}</Text>}</View>
  </View>;
}
function Info({children}: {children: React.ReactNode}) { return <Text style={styles.info}>{children}</Text>; }

function DrivePulse() {
  const [page, setPage] = useState<Page>('Karte');
  const [data, setData] = useState<TripData>(INITIAL_DATA);
  const [pos, setPos] = useState<GPSPoint | null>(null);
  const [liveSpeed, setLiveSpeed] = useState<number | null>(null);
  const [gpsAccess, setGpsAccess] = useState(false);
  const gpsAccessRef = useRef(false);
  const [gpsDetail, setGpsDetail] = useState('Warte auf Standortfreigabe');
  const [limitError, setLimitError] = useState('');
  // Die native Kartenansicht kann in Expo Go leer bleiben. Ein vom MapKit-
  // Renderer unabhängiger WebView-Kartenmodus ermöglicht einen Vergleich.
  const [mapProvider, setMapProvider] = useState<'vector' | 'classic' | 'native'>('classic');
  const [cameraMode, setCameraMode] = useState<'drive' | 'top'>('top');
  const [mapTheme, setMapTheme] = useState<'dark' | 'day'>('dark');
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [catalogOver, setCatalogOver] = useState('20');
  const [catalogUrban, setCatalogUrban] = useState(true);
  const [webMapReady, setWebMapReady] = useState(false);
  const [webMapError, setWebMapError] = useState('');
  const webMapRef = useRef<WebView>(null);
  // In a WebView, failed CDN/style requests do not always trigger onError.
  // Never leave the driver looking at an endless loading spinner.
  useEffect(() => {
    if (page !== 'Karte' || mapProvider === 'native' || webMapReady) return;
    const timeout = setTimeout(() => {
      if (mapProvider === 'vector') {
        setWebMapReady(false);
        setWebMapError('3D-Karte antwortet nicht. OSM-Karte wird geöffnet.');
        setMapProvider('classic');
      } else {
        setWebMapError('Auch die OSM-Karte lädt nicht. Bitte Internetverbindung prüfen oder iOS-Karte versuchen.');
      }
    }, mapProvider === 'vector' ? 12000 : 18000);
    return () => clearTimeout(timeout);
  }, [page, mapProvider, webMapReady]);
  const lastWebRouteRef = useRef<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [period, setPeriod] = useState<Period>('Woche');
  const [now, setNow] = useState(Date.now());
  const [limitState, setLimitState] = useState<MatchedLimit>({status:'unknown', reason:'GPS noch nicht aktiv'});
  const [checkingLimit, setCheckingLimit] = useState(false);
  const [destinationQuery, setDestinationQuery] = useState('');
  const [searchResults, setSearchResults] = useState<GeoDestination[]>([]);
  const [selectedDestination, setSelectedDestination] = useState<GeoDestination | null>(null);
  const [drivingRoute, setDrivingRoute] = useState<DrivingRoute | null>(null);
  const [navigationActive, setNavigationActive] = useState(false);
  const [followVehicle, setFollowVehicle] = useState(true);
  const [routeBusy, setRouteBusy] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [routeError, setRouteError] = useState('');
  const [searchBusy, setSearchBusy] = useState(false);
  const navigationRef = useRef<{active:boolean;destination:GeoDestination|null;route:DrivingRoute|null}>({active:false,destination:null,route:null});
  const rerouteRef = useRef({lastAt:0, offRouteSamples:0, running:false});
  const voicedStepRef = useRef('');
  const voiceEnabledRef = useRef(true);
  useEffect(() => {voiceEnabledRef.current = voiceEnabled; if (!voiceEnabled) void Speech.stop();}, [voiceEnabled]);
  const cameraLastAt = useRef(0);
  const mapRef = useRef<MapView>(null);
  const subscription = useRef<Location.LocationSubscription | null>(null);
  const activeRef = useRef<Trip | null>(null);
  const roadsCacheRef = useRef<{latitude:number;longitude:number;roads:OsmRoad[];at:number}|null>(null);
  const requestRef = useRef<{latitude:number;longitude:number;at:number}|null>(null);
  const requestRunningRef = useRef(false);
  const latestRoadPointRef = useRef<RoadPoint|null>(null);
  const priorFixRef = useRef<GPSPoint|null>(null);
  const mountedRef = useRef(true);

  const maybeReroute = useCallback((loc: Location.LocationObject) => {
    const nav = navigationRef.current;
    if (!nav.active || !nav.destination || !nav.route) return;
    if ((loc.coords.accuracy ?? 999) > 25) {rerouteRef.current.offRouteSamples = 0; return;}
    const progress = routeProgress(nav.route, loc.coords);
    if (!progress) return;
    const next = progress.nextStep;
    if (voiceEnabledRef.current && next && progress.nextStepDistanceMeters != null &&
        progress.nextStepDistanceMeters <= 300 && (loc.coords.speed ?? -1) >= 0 &&
        !progress.arrived) {
      const identity = `${next.type}:${next.location.latitude.toFixed(5)}:${next.location.longitude.toFixed(5)}`;
      if (voicedStepRef.current !== identity) {
        voicedStepRef.current = identity;
        const instruction = maneuverInstruction(next);
        const lead = progress.nextStepDistanceMeters > 45 ? `In etwa ${Math.round(progress.nextStepDistanceMeters / 10) * 10} Metern: ` : '';
        void Speech.stop().then(() => Speech.speak(lead + instruction, {language:'de-DE',rate:0.95})).catch(() => undefined);
      }
    }
    if (progress.arrived) return;
    if (progress.offRouteMeters > 75) rerouteRef.current.offRouteSamples++;
    else rerouteRef.current.offRouteSamples = 0;
    if (rerouteRef.current.offRouteSamples < 3 || rerouteRef.current.running || Date.now() - rerouteRef.current.lastAt < 45000) return;
    rerouteRef.current.running = true;
    rerouteRef.current.lastAt = Date.now();
    rerouteRef.current.offRouteSamples = 0;
    const dest = nav.destination;
    void getDrivingRoute(loc.coords, dest).then(r => {
      if (mountedRef.current && navigationRef.current.active && navigationRef.current.destination?.id === dest.id) {
        navigationRef.current.route = r;
        setDrivingRoute(r);
        setRouteError('Route nach Standortabweichung neu berechnet.');
      }
    }).catch(() => {if (mountedRef.current) setRouteError('Neuberechnung momentan nicht möglich.');})
      .finally(() => {rerouteRef.current.running = false;});
  }, []);

  useEffect(() => {
    if (page !== 'Karte' || !pos || !followVehicle || mapProvider !== 'native') return;
    if (Date.now() - cameraLastAt.current < 1200) return;
    cameraLastAt.current = Date.now();
    mapRef.current?.animateCamera({center:{latitude:pos.latitude,longitude:pos.longitude},
      zoom: cameraMode === 'drive' ? 17.3 : 16, pitch: cameraMode === 'drive' ? 58 : 0,
      heading: cameraMode === 'drive' && pos.heading != null && pos.heading >= 0 && (pos.speed ?? 0) > 3.3 ? pos.heading : 0}, {duration:750});
  }, [page,pos,followVehicle,navigationActive,mapProvider,cameraMode]);

  // Live-Kartendaten werden nur bei App-Nutzung online abgefragt. Eine
  // bereits gestartete Fahrt zeichnet der separate Hintergrundtask lokal auf.
  // Die öffentliche Overpass-API ist lediglich eine Testdatenquelle; nach
  // mindestens 30 Sekunden erneut anfragen und aktuelle Position nie erraten.
  const updateAutoLimit = useCallback((loc: Location.LocationObject) => {
    const latest: RoadPoint = {
      latitude:loc.coords.latitude, longitude:loc.coords.longitude,
      accuracy:loc.coords.accuracy ?? 999,
      heading:loc.coords.heading,
      speedKmh:loc.coords.speed != null && loc.coords.speed >= 0 ? loc.coords.speed * 3.6 : null
    };
    latestRoadPointRef.current = latest;
    const cache = roadsCacheRef.current;
    const distance = cache ? pointDistanceMeters(latest, cache) : Infinity;
    if (cache && distance < 225 && Date.now() - cache.at < 300000) {
      setLimitState(matchSpeedLimit(cache.roads, latest));
    } else {
      setLimitState({status:'unknown',reason:'Für diesen Abschnitt keine aktuellen Kartendaten'});
    }
    // Nicht bei ungenauen GPS-Positionen oder parallel laufender Abfrage neu anfragen.
    if (latest.accuracy < 0 || latest.accuracy > 25 || requestRunningRef.current) {
      if (latest.accuracy > 25) setLimitError('GPS für Straßenzuordnung zu ungenau: ±' + Math.round(latest.accuracy) + ' m');
      return;
    }
    const before = requestRef.current;
    const since = before ? Date.now() - before.at : Infinity;
    const changedRoadArea = !cache || distance >= 175 || Date.now() - cache.at > 300000;
    const moved = before ? pointDistanceMeters(latest, before) : Infinity;
    if (!changedRoadArea || (since < 30000) || (moved < 70 && since < 120000)) return;
    const at = Date.now();
    requestRef.current = {latitude:latest.latitude, longitude:latest.longitude, at};
    requestRunningRef.current = true;
    setCheckingLimit(true);
    setLimitError('');
    void (async () => {
      try {
        const roads = await queryOsmRoads(latest.latitude, latest.longitude);
        if (!mountedRef.current) return;
        roadsCacheRef.current = {latitude:latest.latitude,longitude:latest.longitude,roads,at:Date.now()};
        if (!roads.length) setLimitError('Keine befahrbaren Straßen in OSM gefunden');
        const newest = latestRoadPointRef.current;
        if (newest && pointDistanceMeters(newest, latest) < 225) {
          setLimitState(matchSpeedLimit(roads, newest));
        } else {
          setLimitState({status:'unknown',reason:'Straßenabschnitt seit Abfrage gewechselt'});
        }
      } catch (e) {
        if (mountedRef.current) {
          setLimitError(e instanceof Error ? e.message : 'Fehler bei Online-Tempolimits');
          roadsCacheRef.current = null;
          setLimitState({status:'unknown',reason:'Kartendienst nicht erreichbar oder Anfrage begrenzt'});
        }
      } finally {
        requestRunningRef.current = false;
        if (mountedRef.current) setCheckingLimit(false);
      }
    })();
  }, []);

  const refresh = useCallback(async () => {
    try {
      const restored = await getTrips();
      activeRef.current = restored.active;
      setData(restored);
      setNow(Date.now());
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Fahrtdaten können nicht geladen werden.');
    }
  }, []);

  // Keep permission and actual location fix separate. In particular, "erlaubt"
  // does NOT mean a valid or recent location was received.
  const consumeLocation = useCallback((loc: Location.LocationObject) => {
    if (!mountedRef.current) return;
    const point = toPoint(loc);
    const speed = speedFromFixes(priorFixRef.current, point);
    priorFixRef.current = point;
    setPos(point);
    setLiveSpeed(speed);
    setGpsDetail(gpsFixState(point).reason);
    // Only a new, reasonably accurate fix may be used for live speed-limit matching.
    if (gpsFixState(point).ok) updateAutoLimit(loc);
    else setLimitState({status:'unknown',reason:'GPS-Signal für Straßenerkennung nicht genau genug'});
    maybeReroute(loc);
    if (activeRef.current?.mode === 'foreground') {
      void appendGPS(point).catch(e => console.warn('Fahrtdaten speichern:', e));
    }
  }, [updateAutoLimit,maybeReroute]);

  const establishWatch = useCallback(async () => {
    if (subscription.current) return;
    setGpsDetail('GPS wird gestartet …');
    subscription.current = await Location.watchPositionAsync({
      accuracy: Location.Accuracy.BestForNavigation, timeInterval: 1000, distanceInterval: 0
    }, consumeLocation, message => {
      if (mountedRef.current) setGpsDetail('GPS-Fehler: ' + message);
    });
  }, [consumeLocation]);

  const acquireCurrentFix = useCallback(async () => {
    setGpsDetail('Suche GPS-Position … (im Freien testen)');
    try {
      const current = await Location.getCurrentPositionAsync({accuracy:Location.Accuracy.High});
      consumeLocation(current);
    } catch (e) {
      if (mountedRef.current) setGpsDetail('Kein aktuelles GPS-Signal: ' + (e instanceof Error ? e.message : 'Standortdienst nicht erreichbar'));
    }
  }, [consumeLocation]);

  useEffect(() => {
    mountedRef.current = true;
    let mounted = true;
    void refresh();
    void (async () => {
      try {
        const enabled = await Location.hasServicesEnabledAsync();
        if (!mounted) return;
        if (!enabled) {setGpsDetail('iPhone-Standortdienste ausgeschaltet'); return;}
        const p = await Location.getForegroundPermissionsAsync();
        if (!mounted) return;
        if (p.status !== 'granted') {setGpsDetail('Standortfreigabe fehlt – GPS aktivieren');return;}
        gpsAccessRef.current = true;
        setGpsAccess(true);
        // Last-known fix quickly centers the map. It is NOT a live speed reading.
        const last = await Location.getLastKnownPositionAsync({maxAge:120000,requiredAccuracy:150});
        if (last && mounted) {setPos(toPoint(last));setLiveSpeed(null);}
        if (mounted) {
          await establishWatch();
          void acquireCurrentFix();
        }
      } catch (e) {if (mounted) setGpsDetail('GPS-Start fehlgeschlagen: '+ (e instanceof Error ? e.message:'unbekannt'));}
    })();
    const refreshTimer = setInterval(() => { if (AppState.currentState === 'active') void refresh(); }, 2500);
    const stateChange = AppState.addEventListener('change', state => {
      if (state === 'active') {void refresh(); if(gpsAccessRef.current) void acquireCurrentFix();}
    });
    return () => {
      mounted = false;
      mountedRef.current = false;
      clearInterval(refreshTimer);
      stateChange.remove();
      subscription.current?.remove();
      subscription.current = null;
    };
  }, [refresh, establishWatch, acquireCurrentFix]);

  async function enableGPS() {
    try {
      setBusy(true); setError('');
      if (!(await Location.hasServicesEnabledAsync())) {
        setGpsDetail('Standortdienste in den iPhone-Einstellungen aktivieren');
        setError('Die iPhone-Standortdienste sind deaktiviert.');return false;
      }
      const result = await Location.requestForegroundPermissionsAsync();
      if (result.status !== 'granted') {
        setGpsDetail('Standortberechtigung verweigert');
        setError('Bitte erlaube in Einstellungen → Datenschutz & Sicherheit → Ortungsdienste → Expo Go den genauen Standort.');
        return false;
      }
      gpsAccessRef.current = true;
      setGpsAccess(true);
      await establishWatch();
      // Do not block the entire UI waiting indefinitely for a high-accuracy fix.
      void acquireCurrentFix();
      return true;
    } catch (e) {
      setGpsDetail('GPS konnte nicht gestartet werden');
      setError(e instanceof Error ? e.message : 'GPS konnte nicht gestartet werden.');return false;
    } finally { setBusy(false); }
  }

  async function begin() {
    if (busy || data.active) return;
    const ok = gpsAccess || await enableGPS();
    if (!ok) return;
    try {
      setBusy(true); setError('');
      const trip = await startTrip();
      activeRef.current = trip;
      let mode: Trip['mode'] = 'foreground';
      try {
        const available = await TaskManager.isAvailableAsync();
        if (available) {
          const p = await Location.requestBackgroundPermissionsAsync();
          if (p.status === 'granted') {
            await Location.startLocationUpdatesAsync(LOCATION_TASK, {
              accuracy: Location.Accuracy.High,
              distanceInterval: 5,
              timeInterval: 2000,
              activityType: Location.ActivityType.AutomotiveNavigation,
              pausesUpdatesAutomatically: false,
              showsBackgroundLocationIndicator: true,
              foregroundService: {
                notificationTitle: 'DrivePulse zeichnet eine Fahrt auf',
                notificationBody: 'Tippe auf die App, um deine Fahrt zu beenden.',
                killServiceOnDestroy: false
              }
            });
            mode = 'background';
          }
        }
      } catch (e) {
        // Nicht verschleiern: Aufnahme läuft dann nur im Vordergrund weiter.
        setError('Hintergrund-GPS nicht verfügbar: Fahrt wird nur bei offener App erfasst.');
      }
      await setTrackingMode(mode);
      activeRef.current = {...trip, mode};
      if (mode === 'foreground') setError('Nur Vordergrund-Aufzeichnung aktiv. Für Hintergrund-GPS wird eine eigene App-Version und „Immer erlauben“ benötigt.');
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Fahrt konnte nicht gestartet werden.');
      await refresh();
    } finally { setBusy(false); }
  }

  async function stop() {
    if (busy) return;
    try {
      setBusy(true); setError('');
      // In Expo Go steht Hintergrund-Tracking nicht zur Verfügung; dann nichts stoppen.
      // Bei einer echten Hintergrundaufnahme muss der Dienst vor dem Abschluss stoppen.
      if (activeRef.current?.mode === 'background' &&
          await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK)) {
        await Location.stopLocationUpdatesAsync(LOCATION_TASK);
      }
      activeRef.current = null;
      await finishTrip();
      await refresh();
      setPage('Statistik');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Fahrt konnte nicht beendet werden.');
      await refresh();
    } finally { setBusy(false); }
  }

  function confirmStop() {
    Alert.alert('Fahrt beenden?', 'Deine bisherigen Kilometer werden lokal gespeichert.', [
      { text: 'Weiterfahren', style: 'cancel' },
      { text: 'Beenden', onPress: () => { void stop(); } }
    ]);
  }

  function confirmClear() {
    Alert.alert('Alle Fahrten löschen?', 'Diese Aktion kann nicht rückgängig gemacht werden.', [
      { text: 'Abbrechen', style: 'cancel' },
      { text: 'Unwiderruflich löschen', style: 'destructive', onPress: async () => {
        try { await clearTrips(); await refresh(); } catch (e) { setError(e instanceof Error ? e.message : 'Löschen fehlgeschlagen.'); }
      }}
    ]);
  }

  const active = data.active;
  const gpsHealth = gpsFixState(pos, now);
  const hasFreshGps = gpsHealth.ok;
  const speed = hasFreshGps ? (liveSpeed ?? 0) : 0;
  const freshSpeed = hasFreshGps ? liveSpeed : null;
  const knownLimit = hasFreshGps && limitState.status === 'known' ? limitState.kmh : null;
  const excess = knownLimit !== null && freshSpeed !== null ? freshSpeed - knownLimit : null;
  const fineUrban = excess !== null ? fineForCar(excess, true) : null;
  const fineRural = excess !== null ? fineForCar(excess, false) : null;
  const hasFine = excess !== null && excess >= 1;
  const sanction = hasFine && limitState.status === 'known' && limitState.context
    ? sanctionForCar(excess!, limitState.context === 'urban') : null;
  // In die WebView werden nur die notwendigen Sichtbarkeitsdaten übertragen.
  // Fahrtenhistorie bleibt auf dem Gerät; Kartenkacheln sind Online-Abfragen.
  useEffect(() => {
    if (page !== 'Karte' || mapProvider === 'native' || !webMapReady) return;
    const key = drivingRoute
      ? `${selectedDestination?.id ?? ''}:${drivingRoute.distanceMeters}:${drivingRoute.coordinates.length}` : '';
    const sendGeometry = lastWebRouteRef.current !== key;
    lastWebRouteRef.current = key;
    const payload = {
      gps: hasFreshGps && pos ? {lat:pos.latitude,lng:pos.longitude,heading:pos.heading ?? null} : null,
      speedKmh: liveSpeed ?? 0, mode: cameraMode, theme:mapTheme,
      dest: selectedDestination ? {lat:selectedDestination.latitude,lng:selectedDestination.longitude,
        name:selectedDestination.name.slice(0,120)} : null,
      follow: followVehicle && (!sendGeometry || navigationActive),
      fitRoute: sendGeometry && !!drivingRoute && !navigationActive,
      route: sendGeometry ? (drivingRoute?.coordinates ?? []).map(p => [p.latitude,p.longitude]) : undefined,
      track: route.length >= 2 ? route.filter((_,i) => i % Math.max(1,Math.ceil(route.length/600)) === 0)
        .map(p=>[p.latitude,p.longitude]) : []
    };
    webMapRef.current?.injectJavaScript(`window.drivePulseUpdate(${JSON.stringify(payload)}); true;`);
  }, [webMapReady,page,mapProvider,pos,selectedDestination,drivingRoute,followVehicle,navigationActive,cameraMode,mapTheme,liveSpeed,hasFreshGps,active?.distanceMeters]);
  const routeStatus = routeProgress(drivingRoute, hasFreshGps ? pos : null);
  const moving = (liveSpeed ?? 0) > 8 && hasFreshGps;
  const remainingTimeSeconds = routeStatus && drivingRoute?.distanceMeters
    ? drivingRoute.durationSeconds * Math.min(1,routeStatus.remainingMeters / drivingRoute.distanceMeters) : null;
  const fineText = !hasFine ? (excess === null ? '–' : '0 €') :
    limitState.status === 'known' && limitState.context === 'urban' ? `${fineUrban} €` :
    limitState.status === 'known' && limitState.context === 'rural' ? `${fineRural} €` :
    `${fineUrban} / ${fineRural} €`;
  const fineDescription = excess === null ? 'Keine verlässliche Berechnung möglich' :
    excess < 1 ? 'Kein berechneter Überschuss' :
    limitState.status === 'known' && limitState.context === null ?
      `+${Math.floor(excess)} km/h · innerorts / außerorts` :
      `+${Math.floor(excess)} km/h · ${limitState.status === 'known' && limitState.context === 'urban' ? 'innerorts' : 'außerorts'}`;
  const filtered = useMemo(() => data.trips.filter(t => withinPeriod(t, period, now)), [data.trips, period, now]);
  const totalMeters = filtered.reduce((sum, t) => sum + t.distanceMeters, 0);
  const totalMs = filtered.reduce((sum, t) => sum + elapsedMs(t, now), 0);
  const maxSpeed = Math.max(0, ...filtered.map(t => t.maxSpeedKmh));
  const avgSpeed = totalMs ? totalMeters / totalMs * 3600 : 0;
  const route = active?.points.map(p => ({ latitude: p.latitude, longitude: p.longitude })) ?? [];

  async function findDestination() {
    if (searchBusy || moving || navigationActive) return;
    Keyboard.dismiss(); setSearchBusy(true); setRouteError(''); setSearchResults([]);
    setDrivingRoute(null); setSelectedDestination(null); navigationRef.current = {active:false,destination:null,route:null};
    try {
      let matches: GeoDestination[] = [];
      let onlineFailure = '';
      try { matches = await searchDestinations(destinationQuery, hasFreshGps ? pos : null); }
      catch (e) { onlineFailure = e instanceof Error ? e.message : 'Suchdienst ausgefallen'; }
      if (!matches.length) {
        // Apple/Android geocoder is independent of Nominatim and can resolve
        // street + house number, though its result still needs user confirmation.
        try {
          const native = await Location.geocodeAsync(destinationQuery.trim());
          matches = native.filter(x=>Number.isFinite(x.latitude)&&Number.isFinite(x.longitude))
            .slice(0,5).map((x,i)=>({id:`native-${i}-${x.latitude}-${x.longitude}`,
              name:`${destinationQuery.trim()} · Geräte-Geocoder (Zielposition prüfen)`,
              latitude:x.latitude,longitude:x.longitude}));
        } catch (e) { /* Keep original query error visible below. */ }
      }
      setSearchResults(matches);
      if (!matches.length) setRouteError(onlineFailure ?
        'Online-Zielsuche: '+onlineFailure+'; auch Geräte-Geocoder fand nichts.' :
        'Adresse nicht gefunden. Bitte Straße, Hausnummer, PLZ und Ort vollständig eingeben.');
    } catch (e) {setRouteError(e instanceof Error ? e.message : 'Zielsuche derzeit nicht erreichbar.');}
    finally {setSearchBusy(false);}
  }

  async function chooseDestination(dest: GeoDestination) {
    if (moving || routeBusy) return;
    Keyboard.dismiss();setSearchResults([]);setSelectedDestination(dest);
    setDestinationQuery(dest.name.split(',').slice(0,2).join(','));setRouteError('');
    const current = pos;
    if (!current || !hasFreshGps) {
      setDrivingRoute(null);
      setRouteError('Für die Routenberechnung zunächst GPS aktivieren und ein aktuelles Signal abwarten.');
      return;
    }
    setRouteBusy(true);
    try {
      const result = await getDrivingRoute(current, dest);
      setDrivingRoute(result);
      navigationRef.current = {active:false,destination:dest,route:result};
      setFollowVehicle(false);
      setTimeout(() => mapRef.current?.fitToCoordinates(result.coordinates,
        {edgePadding:{top:145,right:45,bottom:240,left:45},animated:true}),250);
    } catch (e) {setDrivingRoute(null);setRouteError(e instanceof Error ? e.message : 'Route konnte nicht berechnet werden.');}
    finally {setRouteBusy(false);}
  }

  async function startNavigation() {
    if (routeBusy || !selectedDestination) return;
    setRouteBusy(true);setRouteError('');
    try {
      if (!gpsAccess && !await enableGPS()) throw new Error('Standortzugriff wird für die Navigation benötigt.');
      if (!gpsFixState(pos).ok) throw new Error('Kein aktuelles GPS-Signal. GPS prüfen und im Freien erneut versuchen.');
      const result = await getDrivingRoute(pos!, selectedDestination);
      navigationRef.current = {active:true,destination:selectedDestination,route:result};
      voicedStepRef.current = '';
      rerouteRef.current = {lastAt:Date.now(),offRouteSamples:0,running:false};
      setDrivingRoute(result);setNavigationActive(true);setFollowVehicle(true);
    } catch (e) {setRouteError(e instanceof Error ? e.message : 'Navigation konnte nicht gestartet werden.');}
    finally {setRouteBusy(false);}
  }

  function stopNavigation() {
    navigationRef.current = {active:false,destination:null,route:null};
    voicedStepRef.current = '';
    void Speech.stop().catch(() => undefined);
    setNavigationActive(false);setDrivingRoute(null);setSelectedDestination(null);
    setSearchResults([]);setDestinationQuery('');setRouteError('');setFollowVehicle(true);
  }

  function mapContent() {
    return <View style={styles.mapContainer}>
      {mapProvider !== 'native' ? <WebView
        key={mapProvider}
        ref={webMapRef} style={StyleSheet.absoluteFillObject}
        originWhitelist={['*']}
        source={{html:mapProvider==='vector'?DRIVE_MAP_HTML:LEAFLET_HTML,baseUrl:'https://github.com/FNCxDR3/DrivePulse/'}}
        javaScriptEnabled domStorageEnabled
        // Kennung für OSM-Testkacheln (keine Nutzung für den produktiven Verkehr).
        applicationNameForUserAgent="DrivePulsePrototype/0.4 (+https://github.com/FNCxDR3/DrivePulse)"
        onMessage={(event) => {
          const message = event.nativeEvent.data;
          if (message === 'ready') { lastWebRouteRef.current = null; setWebMapError(''); setWebMapReady(true); }
          else if (message === 'moved') setFollowVehicle(false);
          else if (message.startsWith('error:')) {
            if (mapProvider==='vector') { setMapProvider('classic');setWebMapReady(false);setWebMapError('3D nicht verfügbar: 2D-Kompatibilitätskarte aktiviert.'); }
            else setWebMapError('Karte nicht erreichbar. Verbindung prüfen oder iOS-Karte verwenden.');
          }
        }}
        onError={() => {if(mapProvider==='vector'){setMapProvider('classic');setWebMapReady(false);setWebMapError('3D nicht verfügbar: 2D-Kompatibilitätskarte aktiviert.');}else setWebMapError('Kartenansicht nicht erreichbar. Bitte zum nativen Modus wechseln.');}}
      /> : <MapView
        ref={mapRef} style={StyleSheet.absoluteFillObject}
        initialRegion={DEFAULT_REGION} showsUserLocation={gpsAccess}
        showsMyLocationButton={false} showsCompass mapType="standard"
        onPanDrag={()=>setFollowVehicle(false)}
      >
        {route.length > 1 && <Polyline coordinates={route} strokeColor="#22B9A2" strokeWidth={4} />}
        {!!drivingRoute && <Polyline coordinates={drivingRoute.coordinates} strokeColor="#327BF6" strokeWidth={7} />}
        {selectedDestination && <Marker coordinate={{latitude:selectedDestination.latitude,longitude:selectedDestination.longitude}} title={selectedDestination.name} pinColor="#327BF6"/>}
      </MapView>}
      <View style={styles.mapControls}>
        <Pressable style={[styles.mapControl,{backgroundColor:cameraMode==='drive'?'#237b78':'#111e32'}]}
          onPress={()=>{setCameraMode('drive');setFollowVehicle(true); if(mapProvider==='classic'){setMapProvider('vector');setWebMapReady(false);setWebMapError('');}}} accessibilityLabel="3D Fahrperspektive">
          <Text style={styles.mapModeText}>3D</Text>
        </Pressable>
        <Pressable style={[styles.mapControl,{backgroundColor:cameraMode==='top'?'#237b78':'#111e32'}]}
          onPress={()=>{setCameraMode('top');setFollowVehicle(true); if(mapProvider==='classic'){setMapProvider('vector');setWebMapReady(false);setWebMapError('');}}} accessibilityLabel="2D Draufsicht">
          <Text style={styles.mapModeText}>2D</Text>
        </Pressable>
        <Pressable style={styles.mapControl} onPress={()=>setMapTheme(x=>x==='dark'?'day':'dark')} accessibilityLabel="Kartenfarbe umschalten">
          <Text style={styles.mapModeText}>{mapTheme==='dark'?'☀':'☾'}</Text>
        </Pressable>
        <Pressable style={styles.mapControl} onPress={()=>{setMapProvider(x=>x==='vector'?'classic':x==='classic'?'native':'vector');setWebMapReady(false);setWebMapError('');}} accessibilityLabel="Kartenanbieter wechseln">
          <Text style={styles.mapModeText}>{mapProvider==='vector'?'OSM':mapProvider==='classic'?'iOS':'3D'}</Text>
        </Pressable>
      </View>
      {!!webMapError && <View pointerEvents="none" style={styles.mapDiagnostic}><Text style={styles.mapDiagnosticText}>{webMapError}</Text></View>}
      {mapProvider !== 'native' && !webMapReady && !webMapError &&
        <View pointerEvents="none" style={styles.mapLoading}><ActivityIndicator color={C.accent}/><Text style={styles.mapDiagnosticText}>Karte wird geladen …</Text></View>}
      {!navigationActive ? <View style={styles.searchCard}>
        <Text style={styles.searchTitle}>⌖  WOHIN GEHT DIE FAHRT?</Text>
        <View style={styles.searchRow}>
          <TextInput style={styles.destinationInput} value={destinationQuery}
            onChangeText={setDestinationQuery} onSubmitEditing={()=>{void findDestination();}}
            placeholder="Straße Hausnummer, PLZ Ort" placeholderTextColor="#758BA6"
            returnKeyType="search" autoCorrect={false} editable={!moving && !searchBusy} />
          <Pressable accessibilityLabel="Ziel suchen" style={[styles.searchButton,(searchBusy || moving)&&{opacity:.5}]} disabled={searchBusy || moving} onPress={()=>{void findDestination();}}>
            <Text style={{fontWeight:'800',color:C.bg}}>{searchBusy?'…':'Suchen'}</Text>
          </Pressable>
        </View>
        {moving && <Text style={styles.mapDisclaimer}>Zieleingabe während der Fahrt gesperrt.</Text>}
        {searchResults.map(item => <Pressable key={item.id} onPress={()=>{void chooseDestination(item);}} style={styles.searchResult}>
          <Text style={styles.resultTitle} numberOfLines={2}>⌖ {item.name}</Text>
        </Pressable>)}
        {!!selectedDestination && <View style={styles.routeSummary}>
          <Text style={styles.routeDestination} numberOfLines={1}>Ziel: {selectedDestination.name}</Text>
          <Text style={styles.secondary}>{drivingRoute ? `${metersLabel(drivingRoute.distanceMeters)} · ca. ${Math.ceil(drivingRoute.durationSeconds/60)} Min. (ohne Verkehr)` : 'Route noch nicht verfügbar'}</Text>
          <MainButton label={routeBusy?'Route wird geladen…':'▶ Navigation starten'} disabled={routeBusy || !drivingRoute} onPress={()=>{void startNavigation();}} />
          <Pressable onPress={stopNavigation} style={{padding:6,alignSelf:'center'}}><Text style={styles.secondary}>Ziel entfernen</Text></Pressable>
        </View>}
        {!!routeError && <Text style={styles.mapError}>{routeError}</Text>}
        <Text style={styles.osmCredit}>KARTE  ·  OPENFREEMAP / MAPLIBRE     ROUTING  ·  TESTDIENST</Text>
      </View> : <View style={styles.navigationCard}>
        <Text style={styles.navigationEyebrow}>NAVIGATION LÄUFT</Text>
        <Text style={styles.navigationInstruction} numberOfLines={2}>{routeStatus?.arrived ? 'Ziel erreicht' : maneuverInstruction(routeStatus?.nextStep ?? null)}</Text>
        <Text style={styles.navigationDetail}>{routeStatus?.nextStepDistanceMeters != null ? `In ${metersLabel(routeStatus.nextStepDistanceMeters)}` : 'Der Route folgen'}</Text>
        <Text style={styles.navigationDetail}>{routeStatus ? `${metersLabel(routeStatus.remainingMeters)} verbleibend · ca. ${Math.ceil((remainingTimeSeconds ?? 0)/60)} Min.` : 'GPS-Signal abwarten'}</Text>
        {routeStatus?.arrived && <Text style={styles.navigationDetail}>Bitte die Navigation beenden, wenn du geparkt hast.</Text>}
        {!!routeError && <Text style={styles.mapError}>{routeError}</Text>}
        <View style={{flexDirection:'row',gap:8,marginTop:4}}>
          <Pressable onPress={()=>setVoiceEnabled(x=>!x)} style={[styles.stopNavButton,{flex:1,backgroundColor:C.panel2,marginTop:0}]}><Text style={{color:C.white,fontWeight:'800'}}>{voiceEnabled?'Ton an':'Ton aus'}</Text></Pressable>
          <Pressable onPress={stopNavigation} style={[styles.stopNavButton,{flex:2,marginTop:0}]}><Text style={{color:C.white,fontWeight:'800'}}>■ Beenden</Text></Pressable>
        </View>
      </View>}
      <View style={styles.mapFooter}>
        <View style={{flex: 1}}>
          <Text style={styles.metricLabel}>AKTUELLES TEMPO</Text>
          <Text style={styles.mapFooterSpeed}>{hasFreshGps ? fmtSpeed(speed) : '–'} <Text style={{fontSize: 16}}>km/h</Text></Text>
          <Text style={styles.mapSpeedLimit}>Tempolimit: {hasFreshGps && limitState.status === 'known' ? `${limitState.kmh} km/h` : hasFreshGps && limitState.status === 'unlimited' ? 'laut OSM ohne festes Limit*' : 'unbekannt'}</Text>
          <Text style={{color:hasFine?C.amber:C.muted,fontSize:13,fontWeight:'800',marginTop:4}}>Bußgeld-Schätzung: {fineText}</Text>
          <Text style={{color:hasFreshGps?C.accent:C.amber,fontSize:10,marginTop:3}} numberOfLines={2}>{hasFreshGps ? 'GPS live' : gpsDetail} · {limitState.status==='unknown'?limitState.reason : limitState.roadName}</Text>
          {!!limitError && <Text style={{color:C.amber,fontSize:10,marginTop:3}} numberOfLines={1}>Online: {limitError}</Text>}
        </View>
        <View style={{alignItems:'center',gap:7}}>
        <Pressable style={styles.catalogMiniButton} onPress={()=>setCatalogOpen(true)}><Text style={{fontSize:11,fontWeight:'900',color:'#071321'}}>€ Katalog</Text></Pressable>
        <Pressable style={styles.roundButton} onPress={() => {
          setFollowVehicle(true);
          if (hasFreshGps && pos) mapRef.current?.animateCamera({center:{latitude:pos.latitude,longitude:pos.longitude},zoom:cameraMode==='drive'?17:16,pitch:cameraMode==='drive'?58:0},{duration:450});
          else if(gpsAccess) void acquireCurrentFix(); else void enableGPS();
        }}><Text style={{color:C.bg,fontSize:22}}>⌖</Text></Pressable>
        </View>
      </View>
    </View>;
  }

  function speedContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <View style={styles.eyebrowRow}><Text style={styles.eyebrow}>LIVE FAHR-DASHBOARD</Text>
        <Text style={[styles.pill, {color: active ? C.accent : C.muted}]}>{active ? '● AUFZEICHNUNG' : '○ BEREIT'}</Text></View>
      <View style={styles.speedPanel}>
        <Text style={styles.metricLabel}>AKTUELLE GPS-GESCHWINDIGKEIT</Text>
        <Text style={[styles.hugeSpeed, {color: excess !== null && excess >= 3 ? C.red : C.white}]}>{hasFreshGps ? fmtSpeed(speed) : '–'}</Text>
        <Text style={styles.speedUnit}>km/h</Text>
        <View style={styles.separator}/>
        <View style={styles.pillRow}>
          <View style={{flex:1}}><Text style={styles.metricLabel}>ERKANNTES TEMPOLIMIT · ONLINE</Text>
            <Text style={styles.limitValue}>{knownLimit !== null ? `${knownLimit} km/h` : hasFreshGps && limitState.status === 'unlimited' ? 'Keine feste Grenze*' : 'Unbekannt'}</Text>
          </View>
          <Text style={styles.speedBadge}>{excess !== null && excess >= 1 ? `+${fmtSpeed(excess)} km/h` : checkingLimit ? '● Abfrage läuft' : '● Kartendaten'}</Text>
        </View>
        <Text style={styles.roadName}>{limitState.status !== 'unknown' ? `${limitState.roadName} · © OpenStreetMap` : (limitState.roadName ?? limitState.reason)}</Text>
        {!!limitError && <Info>Online-Abfrage: {limitError}</Info>}
        <Info>GPS: {gpsHealth.reason}. {gpsDetail}</Info>
        <MainButton label="GPS / Tempolimit erneut prüfen" disabled={busy || checkingLimit} onPress={()=>{
          requestRef.current=null;roadsCacheRef.current=null;setLimitState({status:'unknown',reason:'Neue Abfrage gestartet'});
          if (!gpsAccess) void enableGPS(); else {void acquireCurrentFix();}
        }} />
        <Info>{checkingLimit ? 'Lade Straßeninformationen von OpenStreetMap …' : 'Automatische Zuordnung via GPS und OpenStreetMap. Fehlende oder widersprüchliche Daten werden nicht geschätzt.'}</Info>
      </View>
      <View style={[styles.finePanel, {borderColor: hasFine ? '#69373D' : C.border}]}>
        <View style={styles.pillRow}><Text style={styles.fineHeading}>BUẞGELD-SIMULATOR</Text><Text style={{color:hasFine ? C.red : C.accent}}>● SIMULATION</Text></View>
        <View style={styles.pillRow}><Text style={styles.fineValue}>{fineText}</Text><Text style={styles.fineDetail}>{fineDescription}</Text></View>
        {sanction && <Text style={styles.sanctionText}>{sanction.points ? `${sanction.points} Punkt${sanction.points > 1 ? 'e' : ''}` : 'Keine Punkte'} · {sanction.banMonths ? `${sanction.banMonths} Mon. Regelfahrverbot` : sanction.repeatBanPossible ? 'Fahrverbot bei Wiederholung möglich' : 'Kein Regelfahrverbot'}</Text>}
        <Info>Nur normale Pkw, Rohüberschreitung anhand GPS, ohne Mess-Toleranzabzug, Gebühren oder Einzelfälle. Keine geeichte Messung, keine Blitzer-Erkennung.</Info>
      </View>
      <MainButton label="⚖ Bußgeldkatalog ansehen" onPress={()=>setCatalogOpen(true)} />
      <Info>* Kartendaten können von Verkehrszeichen, Baustellen und zeitabhängigen Beschränkungen abweichen. Entscheidend sind immer die tatsächlichen Verkehrsregeln. Tempolimitdaten: © OpenStreetMap-Mitwirkende (ODbL).</Info>
      <View style={styles.columns}>
        <Metric label="STRECKE" value={fmtKm(active?.distanceMeters ?? 0)} unit="km" />
        <Metric label="FAHRZEIT" value={active ? formatDuration(elapsedMs(active, now)) : '0:00'} unit="h:min" />
      </View>
      <View style={styles.columns}>
        <Metric label="HÖCHSTWERT" value={fmtSpeed(active?.maxSpeedKmh ?? 0)} unit="km/h" />
        <Metric label="Ø GESCHW." value={active ? fmtSpeed(calcMeanKmh(active, now)) : '0'} unit="km/h" />
      </View>
      {!gpsAccess && <MainButton label="GPS aktivieren" disabled={busy} onPress={()=>{ void enableGPS(); }} />}
      <MainButton disabled={busy} danger={!!active} label={busy?'Bitte warten…':active?'■ Fahrt beenden':'+ Fahrt starten'} onPress={active?confirmStop:()=>{void begin();}} />
      {active && <Info>{active.mode === 'background' ? 'Hintergrund-Aufzeichnung angefordert. Bildschirm kann gesperrt werden; Betriebssystem kann Updates einschränken.' : 'Aufzeichnung nur bei geöffneter App. Für Hintergrund-GPS eigenen Build installieren und Berechtigung erteilen.'}</Info>}
    </ScrollView>;
  }

  function statsContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Deine Statistiken</Text>
      <Text style={styles.subtitle}>Alle Fahrten bleiben auf diesem Gerät gespeichert.</Text>
      <View style={styles.pillRow}>{(['Heute','Woche','Monat','Gesamt'] as Period[]).map(x => <Chip key={x} active={x===period} onPress={()=>setPeriod(x)}>{x}</Chip>)}</View>
      <View style={styles.columns}><Metric label="KILOMETER" value={fmtKm(totalMeters)} unit="km" /><Metric label="FAHRDAUER" value={formatDuration(totalMs)} unit="h:min" /></View>
      <View style={styles.columns}><Metric label="HÖCHSTGESCHW." value={fmtSpeed(maxSpeed)} unit="km/h" /><Metric label="Ø GESCHW." value={fmtSpeed(avgSpeed)} unit="km/h" /></View>
      <View style={styles.sectionRow}><Label>DEINE FAHRTEN</Label><Text style={styles.secondary}>{filtered.length} Fahrten</Text></View>
      {filtered.length === 0 ? <View style={styles.empty}><Text style={styles.emptyIcon}>↗</Text><Text style={styles.emptyTitle}>Noch keine Fahrten</Text><Text style={styles.secondary}>Starte deine erste Fahrt im Bereich „Tacho“.</Text></View>
        : filtered.map(t => <View key={t.id} style={styles.tripRow}>
          <View style={{flex:1}}><Text style={styles.tripHeading}>{fmtDate(t.startedAt)}</Text><Text style={styles.secondary}>{formatDuration(elapsedMs(t, now))} h:min · Spitze {fmtSpeed(t.maxSpeedKmh)} km/h</Text></View>
          <Text style={styles.tripDistance}>{fmtKm(t.distanceMeters)} km</Text>
        </View>)}
    </ScrollView>;
  }

  function catalogContent() {
    const km = Math.min(200, Math.max(0, Math.floor(Number(catalogOver) || 0)));
    const selected = sanctionForCar(km,catalogUrban);
    return <Modal visible={catalogOpen} animationType="slide" transparent onRequestClose={()=>setCatalogOpen(false)}>
      <View style={styles.catalogBackdrop}>
        <View style={styles.catalogSheet}>
          <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
            <View><Text style={styles.catalogEyebrow}>DEUTSCHLAND · PKW</Text><Text style={styles.catalogTitle}>Bußgeldkatalog</Text></View>
            <Pressable onPress={()=>setCatalogOpen(false)} style={styles.catalogClose}><Text style={{color:C.white,fontSize:24}}>×</Text></Pressable>
          </View>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{gap:14,paddingBottom:32}}>
            <Text style={styles.catalogSub}>Amtliche BKatV-Regelsätze · Stand 17.10.2026 · ohne Mess-Toleranzabzug, Gebühren und besondere Umstände.</Text>
            <View style={{flexDirection:'row',gap:9}}>
              <Chip active={catalogUrban} onPress={()=>setCatalogUrban(true)}>Innerorts</Chip>
              <Chip active={!catalogUrban} onPress={()=>setCatalogUrban(false)}>Außerorts</Chip>
            </View>
            <Text style={styles.metricLabel}>ÜBERSCHREITUNG (KM/H) · SIMULATION</Text>
            <TextInput value={catalogOver} onChangeText={setCatalogOver} keyboardType="number-pad" maxLength={3} placeholder="20" placeholderTextColor={C.muted} style={styles.catalogInput} />
            <View style={{flexDirection:'row',gap:6,justifyContent:'space-between'}}>
              {[10,20,30,40,50].map(n=><Chip key={n} active={km===n} onPress={()=>setCatalogOver(String(n))}>+{n}</Chip>)}
            </View>
            <View style={styles.catalogResult}>
              <Text style={styles.metricLabel}>MÖGLICHER REGELSATZ</Text>
              <Text style={{fontSize:48,fontWeight:'900',color:C.white}}>{selected.euro} €</Text>
              <Text style={{color:C.muted,fontWeight:'700'}}>{selected.points} Punkt{selected.points===1?'':'e'} · {selected.banMonths ? `${selected.banMonths} Monat${selected.banMonths>1?'e':''} Regelfahrverbot` : 'Kein reguläres Fahrverbot'}</Text>
              {selected.repeatBanPossible && <Info>Bei wiederholten Verstößen um mindestens 26 km/h kann ein Fahrverbot hinzukommen (§ 4 Abs. 2 BKatV).</Info>}
            </View>
            <Text style={styles.catalogEyebrow}>REGELSÄTZE IM ÜBERBLICK</Text>
            {[[1,10],[11,15],[16,20],[21,25],[26,30],[31,40],[41,50],[51,60],[61,70],[71,200]].map(([low,high])=>{
              const s=sanctionForCar(high,catalogUrban);
              return <View key={low} style={styles.catalogRow}>
                <Text style={{color:C.white,fontWeight:'700',width:100}}>{low===71?'> 70':low===1?'bis 10':`${low}–${high}`} km/h</Text>
                <Text style={{color:C.white,flex:1,textAlign:'right',fontWeight:'800'}}>{s.euro} €</Text>
                <Text style={{color:C.muted,width:88,textAlign:'right',fontSize:11}}>{s.points} P. · {s.banMonths} Mon.</Text>
              </View>;
            })}
            <Text onPress={()=>{void Linking.openURL('https://www.gesetze-im-internet.de/bkatv_2013/anhang.html');}} style={styles.catalogLink}>Amtliche Quelle: Bußgeldkatalog-Verordnung, Tabelle 1(c) ↗</Text>
            <Text onPress={()=>{void Linking.openURL('https://www.gesetze-im-internet.de/fev_2010/anlage_13.html');}} style={styles.catalogLink}>Amtliche Quelle: Fahrerlaubnis-Verordnung, Anlage 13 ↗</Text>
            <Info>Die GPS-Anzeige ist keine amtlich verwertbare Geschwindigkeitsmessung. Ein ausgegebener Betrag ist keine tatsächlich verhängte Geldbuße.</Info>
          </ScrollView>
        </View>
      </View>
    </Modal>;
  }

  function friendsContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Freunde & Community</Text>
      <Text style={styles.subtitle}>Deine Fahrten bleiben privat, bis du etwas ausdrücklich freigibst.</Text>
      <View style={styles.empty}><Text style={styles.emptyIcon}>♧</Text>
        <Text style={styles.emptyTitle}>Freundesbereich in Planung</Text>
        <Text style={[styles.secondary,{textAlign:'center',lineHeight:21}]}>Freunde hinzufügen, Kilometer vergleichen, sichere Challenges und eine freiwillige Live-Freundeskarte sind für eine spätere Version vorgesehen.</Text>
      </View>
      <Label>DATENSCHUTZ</Label>
      <Info>Es existiert noch kein Benutzerkonto, kein Freundeserver und keine Standortübertragung. Andere können deine Fahrdaten in dieser Version nicht sehen.</Info>
    </ScrollView>;
  }

  function profileContent() {
    return <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>Einstellungen</Text>
      <Text style={styles.subtitle}>DrivePulse · GPS- und Tempolimit-Test 0.5</Text>
      <View style={styles.profileCard}>
        <Label>GPS & BERECHTIGUNGEN</Label>
        <Text style={styles.cardTitle}>{gpsAccess?'Standortberechtigung erteilt':'Standort nicht freigegeben'}</Text>
        <Info>Empfang: {gpsHealth.reason}. {gpsDetail}</Info>
        <Info>Tempolimit-Abfrage: {checkingLimit?'läuft':limitState.status==='known'?`${limitState.kmh} km/h / ${limitState.roadName}`:limitState.status==='unlimited'?'Kein festes Limit laut Karte':limitState.reason}. {limitError}</Info>
        <MainButton label="GPS erneut erfassen" onPress={()=>{void enableGPS();}} disabled={busy} />
        <Info>Die manuell gestartete Aufzeichnung kann in einem eigenen Entwicklungs-Build mit „Immer erlauben“ bei gesperrtem Bildschirm weiterlaufen.</Info>
        <MainButton label="iPhone-Einstellungen öffnen" onPress={()=>{void Linking.openSettings();}} />
      </View>
      <View style={styles.profileCard}>
        <Label>DEINE DATEN</Label>
        <Text style={styles.cardTitle}>Lokal gespeicherte Fahrten</Text>
        <Info>{data.trips.length} abgeschlossene Fahrten. Gespeicherte Routen bleiben lokal. Für die automatische Tempolimitabfrage wird die aktuelle GPS-Position an einen der beiden eingesetzten Overpass-Kartendienste übertragen (private.coffee oder FOSSGIS). Der Betreiber kann Anfragen protokollieren. Die dynamische Karte lädt Vektorkarten von OpenFreeMap; MapLibre wird über ein CDN geladen. Bei Zielsuche werden Suchbegriffe an Nominatim und bei fehlenden Ergebnissen an den Geräte-Geocoder übertragen; bei Routenberechnung Start- und Zielposition an OSRM. Der Gerätespeicher ist nicht zusätzlich verschlüsselt.</Info>
        <Pressable disabled={!!active} onPress={confirmClear} style={[styles.deleteButton, !!active && {opacity:.35}]}><Text style={{color:C.red,fontWeight:'700'}}>Alle gespeicherten Fahrten löschen</Text></Pressable>
      </View>
      <View style={styles.profileCard}>
        <Label>PROJEKTSTATUS</Label>
        <Info>✓ GPS-Tacho, 2D-/3D-Vektorkarte (Test), iOS-Karten-Fallback, Statistiken</Info>
        <Info>△ Hintergrundaufzeichnung erst nach eigenem iOS/Android-Build testbar</Info>
        <Info>△ Tempolimit: Online-OSM-Matching, nur bei eindeutigem Abschnitt; keine Echtzeit-Verkehrsschilder</Info>
        <Info>△ Navigation mit OSRM-Testdienst, Zielsuche und experimentellen Sprachansagen; ohne Verkehrsdaten</Info>
        <Info>○ Automatischer Fahrtbeginn und Freunde folgen</Info>
      </View>
    </ScrollView>;
  }

  const tabs: {key:Page;icon:string}[] = [
    {key:'Karte',icon:'◇'}, {key:'Tacho',icon:'◉'}, {key:'Statistik',icon:'▥'},
    {key:'Freunde',icon:'♧'}, {key:'Profil',icon:'⚙'}
  ];

  return <SafeAreaView style={styles.safe} edges={['top','bottom']}>
    <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
    <View style={styles.header}>
      <View><Text style={styles.brand}>DRIVE<Text style={{color:C.accent}}>PULSE</Text></Text><Text style={styles.brandSub}>YOUR DRIVE. YOUR DATA.</Text></View>
      <View style={[styles.gpsIndicator,{backgroundColor:gpsAccess?'#204B47':C.panel2}]}><Text style={{color:hasFreshGps?C.accent:gpsAccess?C.amber:C.muted,fontSize:11,fontWeight:'700'}}>● {hasFreshGps?'GPS LIVE':gpsAccess?'GPS WARTET':'GPS AUS'}</Text></View>
    </View>
    {!!error && <Pressable onPress={()=>setError('')} style={styles.error}><Text style={{color:C.white,fontSize:12,flex:1}}>{error}</Text><Text style={{color:C.white}}>×</Text></Pressable>}
    <View style={styles.body}>
      {page==='Karte' && mapContent()}
      {page==='Tacho' && speedContent()}
      {page==='Statistik' && statsContent()}
      {page==='Freunde' && friendsContent()}
      {page==='Profil' && profileContent()}
    </View>
    <View style={styles.tabBar}>
      {tabs.map(tab => <Pressable key={tab.key} onPress={()=>setPage(tab.key)} style={styles.tab} accessibilityRole="tab" accessibilityState={{selected:page===tab.key}}>
        <Text style={[styles.tabIcon,{color:page===tab.key?C.accent:C.muted}]}>{tab.icon}</Text>
        <Text style={[styles.tabText,{color:page===tab.key?C.accent:C.muted}]}>{tab.key}</Text>
      </Pressable>)}
    </View>
    {catalogContent()}
    {busy && <View pointerEvents="none" style={styles.busyDot}><ActivityIndicator size="small" color={C.accent}/></View>}
  </SafeAreaView>;
}

export default function App() { return <SafeAreaProvider><DrivePulse/></SafeAreaProvider>; }

const styles = StyleSheet.create({
  mapControls:{position:'absolute',top:182,right:14,flexDirection:'column',gap:7},
  mapControl:{backgroundColor:'#111e32',minWidth:46,height:41,justifyContent:'center',alignItems:'center',paddingHorizontal:8,borderWidth:1,borderColor:'#4c6677',borderRadius:13,shadowColor:'#07121d',shadowOpacity:.42,shadowRadius:6},
  catalogMiniButton:{backgroundColor:'#62e6d2',paddingHorizontal:11,paddingVertical:11,borderRadius:11},
  catalogBackdrop:{flex:1,justifyContent:'flex-end',backgroundColor:'#0009'},
  catalogSheet:{backgroundColor:'#101d2c',height:'91%',borderTopLeftRadius:25,borderTopRightRadius:25,padding:20,gap:16,borderColor:'#416072',borderWidth:1},
  catalogEyebrow:{fontWeight:'800',fontSize:10,letterSpacing:1.5,color:'#61dccc'},
  catalogTitle:{fontSize:26,fontWeight:'900',color:C.white,marginTop:5},
  catalogClose:{backgroundColor:'#263a4d',height:40,width:40,alignItems:'center',justifyContent:'center',borderRadius:14},
  catalogSub:{color:C.muted,fontSize:12,lineHeight:19},
  catalogInput:{color:C.white,backgroundColor:'#1b3045',borderColor:C.border,borderWidth:1,padding:16,borderRadius:13,fontWeight:'900',fontSize:24},
  catalogResult:{backgroundColor:'#183544',borderWidth:1,borderColor:'#33897f',borderRadius:17,padding:19,gap:8},
  catalogRow:{paddingVertical:12,paddingHorizontal:7,borderBottomWidth:1,borderBottomColor:'#2c4057',flexDirection:'row',alignItems:'center'},
  catalogLink:{color:'#57d5fb',textDecorationLine:'underline',fontSize:12},

  safe: {flex:1,backgroundColor:C.bg},
  header:{minHeight:66,flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:18,borderBottomWidth:1,borderBottomColor:C.border},
  brand:{fontWeight:'900',fontSize:22,letterSpacing:1.5,color:C.white}, brandSub:{color:C.muted,fontSize:9,letterSpacing:2.5,marginTop:2},
  gpsIndicator:{paddingHorizontal:10,paddingVertical:8,borderRadius:9},
  body:{flex:1},scrollContent:{padding:16,paddingBottom:28,gap:12},
  eyebrowRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:2},
  eyebrow:{color:C.muted,letterSpacing:2,fontSize:11,fontWeight:'700'},pill:{fontSize:11,fontWeight:'800'},
  speedPanel:{backgroundColor:C.panel,borderRadius:19,borderWidth:1,borderColor:C.border,padding:18,alignItems:'center'},
  metricLabel:{color:C.muted,fontSize:10,fontWeight:'800',letterSpacing:1.15},
  hugeSpeed:{fontSize:105,lineHeight:114,fontWeight:'800',fontVariant:['tabular-nums'],marginTop:4},
  speedUnit:{color:C.muted,fontSize:16,marginTop:-12,marginBottom:12},
  separator:{height:1,backgroundColor:C.border,width:'100%',marginVertical:15},
  pillRow:{width:'100%',flexDirection:'row',flexWrap:'wrap',gap:7,alignItems:'center',justifyContent:'space-between'},
  limitValue:{color:C.white,fontSize:24,fontWeight:'900',marginTop:3},speedBadge:{color:C.amber,fontSize:12,fontWeight:'800'},
  roadName:{alignSelf:'stretch',color:C.muted,fontSize:12,marginTop:10,marginBottom:6},
  chip:{backgroundColor:C.panel2,paddingHorizontal:10,paddingVertical:8,borderRadius:9,borderWidth:1,borderColor:C.border},
  chipActive:{backgroundColor:'#235C59',borderColor:C.accent},chipText:{fontSize:12,color:C.muted,fontWeight:'700'},chipTextActive:{color:C.white},
  finePanel:{backgroundColor:'#211E2B',borderWidth:1,borderRadius:16,padding:15,gap:8},
  fineHeading:{color:C.white,fontSize:12,letterSpacing:.8,fontWeight:'800'},
  fineValue:{color:C.white,fontSize:36,fontWeight:'900'},fineDetail:{color:C.muted,fontSize:12,maxWidth:'47%',textAlign:'right'},
  info:{color:C.muted,fontSize:12,lineHeight:18},
  columns:{flexDirection:'row',gap:10},metric:{flex:1,minWidth:0,backgroundColor:C.panel,borderRadius:15,borderColor:C.border,borderWidth:1,padding:15,gap:8},
  metricNumber:{flexDirection:'row',alignItems:'baseline',flexWrap:'wrap'},metricValue:{fontSize:27,color:C.white,fontWeight:'800',fontVariant:['tabular-nums']},metricUnit:{color:C.muted,fontSize:11},
  mainButton:{borderRadius:14,backgroundColor:C.accent,alignItems:'center',padding:17,marginTop:5},
  dangerButton:{backgroundColor:'#BD4655'},mainButtonText:{fontSize:15,fontWeight:'900',color:C.bg},
  title:{color:C.white,fontWeight:'900',fontSize:25,marginTop:4},subtitle:{color:C.muted,fontSize:12,marginBottom:12,lineHeight:20},
  sectionRow:{marginTop:12,flexDirection:'row',justifyContent:'space-between'},label:{color:C.muted,fontSize:11,fontWeight:'900',letterSpacing:1.25},
  secondary:{color:C.muted,fontSize:12,lineHeight:18},
  empty:{alignItems:'center',backgroundColor:C.panel,borderColor:C.border,borderWidth:1,borderRadius:16,padding:25,gap:10,marginVertical:6},
  emptyIcon:{fontSize:34,color:C.accent},emptyTitle:{fontSize:17,fontWeight:'800',color:C.white},
  tripRow:{backgroundColor:C.panel,borderRadius:13,padding:15,flexDirection:'row',alignItems:'center',gap:8,borderWidth:1,borderColor:C.border},
  tripHeading:{color:C.white,fontSize:14,fontWeight:'700',marginBottom:5},tripDistance:{fontSize:15,color:C.accent,fontWeight:'800'},
  profileCard:{backgroundColor:C.panel,borderColor:C.border,borderWidth:1,borderRadius:15,padding:17,gap:12},
  cardTitle:{color:C.white,fontSize:18,fontWeight:'800'},deleteButton:{padding:12,borderWidth:1,borderColor:'#6F4148',borderRadius:10,alignItems:'center'},
  tabBar:{height:66,borderTopWidth:1,borderTopColor:C.border,backgroundColor:C.bg,flexDirection:'row',paddingTop:8},
  tab:{flex:1,alignItems:'center',justifyContent:'center',gap:3},tabIcon:{fontSize:21,fontWeight:'700'},tabText:{fontSize:10,fontWeight:'700'},
  mapContainer:{flex:1,backgroundColor:'#101a2b'},
  mapModeButton:{position:'absolute',top:164,right:12,backgroundColor:'#0B111DE8',borderColor:C.border,borderWidth:1,paddingVertical:8,paddingHorizontal:12,borderRadius:9},
  mapModeText:{color:C.white,fontWeight:'800',fontSize:11},
  mapLoading:{position:'absolute',top:'49%',alignSelf:'center',alignItems:'center',gap:10,padding:14,backgroundColor:'#0B111DDD',borderRadius:12},
  mapDiagnostic:{position:'absolute',top:'47%',left:30,right:30,backgroundColor:'#0B111DEB',padding:14,borderRadius:12},
  mapDiagnosticText:{color:C.white,fontSize:12,textAlign:'center'},
  searchCard:{position:'absolute',top:12,left:12,right:12,borderRadius:19,backgroundColor:'#0d192beb',padding:13,gap:9,maxHeight:'64%',borderWidth:1,borderColor:'#31445d'},
  searchTitle:{color:C.white,fontSize:16,fontWeight:'800'},
  searchRow:{flexDirection:'row',alignItems:'center',gap:7},
  destinationInput:{flex:1,borderWidth:1,borderColor:C.border,borderRadius:10,backgroundColor:C.panel,paddingHorizontal:11,paddingVertical:10,color:C.white,fontSize:14,minHeight:44},
  searchButton:{backgroundColor:C.accent,borderRadius:10,minHeight:44,justifyContent:'center',paddingHorizontal:11},
  searchResult:{paddingVertical:9,borderBottomWidth:1,borderBottomColor:C.border},resultTitle:{color:C.white,fontSize:13},
  routeSummary:{paddingTop:8,borderTopWidth:1,borderTopColor:C.border,gap:5},
  routeDestination:{color:C.white,fontSize:13,fontWeight:'700'},
  mapError:{color:C.amber,fontSize:12,lineHeight:18},mapDisclaimer:{color:C.amber,fontSize:12},
  navigationCard:{position:'absolute',top:12,left:12,right:12,borderRadius:16,backgroundColor:'#153754',padding:15,gap:6},
  navigationEyebrow:{color:C.accent,fontSize:10,fontWeight:'900',letterSpacing:2},
  navigationInstruction:{color:C.white,fontSize:19,fontWeight:'900'},navigationDetail:{color:'#D1E3F0',fontSize:13},
  stopNavButton:{padding:12,borderRadius:10,backgroundColor:'#AA4954',alignItems:'center',marginTop:4},
  sanctionText:{color:C.white,fontSize:13,fontWeight:'700'},
  mapTop:{position:'absolute',top:12,left:15,right:15,borderRadius:12,backgroundColor:C.bg,padding:14},
  mapTopTitle:{color:C.white,fontSize:18,fontWeight:'800'},mapTopSub:{color:C.muted,fontSize:11,marginTop:4},osmCredit:{color:C.muted,fontSize:9,marginTop:4},
  mapFooter:{position:'absolute',bottom:14,left:14,right:14,backgroundColor:'#0d192bef',borderWidth:1,borderColor:'#31445d',borderRadius:19,padding:14,flexDirection:'row',alignItems:'center'},
  mapFooterSpeed:{fontSize:28,color:C.white,fontWeight:'800'},mapSpeedLimit:{color:C.accent,fontSize:12,marginTop:4},roundButton:{height:45,width:45,backgroundColor:C.accent,alignItems:'center',justifyContent:'center',borderRadius:30},
  error:{marginHorizontal:16,marginTop:9,padding:10,flexDirection:'row',alignItems:'center',backgroundColor:'#8B4047',borderRadius:8,gap:10},
  busyDot:{position:'absolute',top:70,right:18},
});
