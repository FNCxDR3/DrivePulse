# DrivePulse v0.5 – GPS-, Adress- und Tempolimit-Diagnose

**Stand: 17. Oktober 2026. Private Testversion. Keine verlässliche oder für den Straßenverkehr validierte Navigations-App.** Diese Version ist noch nicht auf dem iPhone kompiliert bzw. mit echter Fahrt erprobt. Die 28 lokal ausführbaren Logiktests bestehen; das bestätigt weder die Erreichbarkeit der Kartendienste noch die Korrektheit einzelner Geschwindigkeitsbegrenzungen.

## Neuerungen gegenüber v0.4.1

- **GPS-Status getrennt:** „GPS AUS“ (keine Berechtigung), „GPS WARTET“ (Freigabe erteilt, aber kein ausreichender aktueller Fix), „GPS LIVE“ (aktuelle ausreichend genaue Position). Die Berechtigung allein gilt nicht mehr als erfolgreicher GPS-Empfang.
- **GPS-Diagnose im Profil und Tacho:** Anzeige möglicher Fehler, Signalqualität bzw. Alter der Ortung. Button „GPS erneut erfassen“ und direkte Verknüpfung zu den iPhone-App-Einstellungen. Ein zuletzt bekannter Standort wird nur zur Orientierung verwendet, nicht als aktuelle Fahrgeschwindigkeit.
- **Adresssuche:** Bisheriger Nominatim-Testdienst mit räumlicher Bevorzugung nahe des Standorts; falls ohne Ergebnis, Versuch über den Geräte-Geocoder. Bitte vollständige Adresse mit Hausnummer, PLZ und Ort eingeben und das vorgeschlagene Ziel vor dem Routenstart prüfen.
- **Tempolimit-Diagnose:** Falls die GPS-Position ungenau ist, der Straßenabschnitt nicht eindeutig zugeordnet werden kann oder der Kartendienst fehlschlägt, erscheint eine Begründung. Zweiter Overpass-Endpunkt als Ausweichmöglichkeit. **Beide Endpunkte verwenden dieselben OpenStreetMap-Daten**, die deshalb keine unabhängig verifizierte Quelle der geltenden Beschilderung sind.
- **Bußgeldkatalog:** Separat abrufbare Pkw-Regelsätze für Geschwindigkeitsverstöße innerorts und außerorts mit Punkten und regulären Fahrverboten. Die Live-Anzeige bleibt bei fehlendem GPS-/Tempolimit unbekannt; sie erfindet keine Beträge. Beträge beziehen sich auf die im Programm hinterlegten Regelsätze und ersetzen keinen Bescheid.
- **Karten:** Klassische OSM-Ansicht ist als Standard aktiviert, 2D-/3D-Vektorkarte und native Kartenansicht sind testweise weiterhin auswählbar. Die 3D-Ansicht kann in Expo Go ausfallen.
- **Bestehende Funktionen:** GPS-Tacho, manuelle Fahrtaufzeichnung, lokal gespeicherte Fahrstatistik, experimentelle Routenberechnung, Ziel- und Abbiegehinweise. Automatische Fahrtaufzeichnung ohne geöffnetes Programm und Freunde/Standortfreigabe sind noch nicht implementiert.

## Grenzen / Datenschutz

- GPS-Positionsbestimmung benötigt Standortberechtigung und ein ausreichendes Satelliten-/Systemsignal; in Gebäuden oder bei ungenauen Standortdaten muss man mit Ausfällen rechnen.
- **Tempolimits bleiben experimentell.** OSM-Attribute können fehlen oder falsch sein. Baumaßnahmen, Zusatzzeichen, elektronische oder zeitlich eingeschränkte Limits werden nicht durchgehend berücksichtigt. Die tatsächlich gültige Beschilderung ist maßgeblich.
- **Bußgeldberechnung nur für normale Pkw ohne Anhänger**, orientiert an der deutschen BKatV/FeV. Keine verbindliche Rechtsauskunft; mögliche Mess-Toleranzabzüge, Gebühren, Besonderheiten von Vorsatz/Wiederholung etc. sind nicht abschließend eingerechnet. Die GPS-Geschwindigkeit ist keine geeichte Messung.
- Fahrten bleiben lokal auf dem Gerät. Für Tempolimits werden Standortkoordinaten an einen Overpass-Server übertragen, Kartendaten online geladen, Suchbegriffe an Nominatim bzw. Geräte-Geocoder und Routenanfragen mit Start/Ziel an den OSRM-Demodienst gesendet. Die jeweiligen Dienstbetreiber können Anfragen protokollieren.
- Die öffentlichen Nominatim-, Overpass- und OSRM-Demo-Dienste sind nicht als belastbare produktive Navigationsinfrastruktur ausgelegt. Häufige Abfragen können begrenzt oder blockiert werden.
- Expo Go unterstützt die gewünschte native Hintergrund-Ortung nicht vollständig. Dafür ist später ein eigens gebauter iOS-Entwicklungs-Build nötig.

## Installation / Test in GitHub Codespaces am iPhone

1. `DrivePulse_v0_5.zip` herunterladen, über GitHub-Webseite ins Repository `FNCxDR3/DrivePulse` hochladen und den Commit bestätigen.
2. Alten Expo-Prozess beenden (sonst ggf. anderen Port wählen) und ein neues Codespaces-Terminal öffnen.
3. **Jede Zeile einzeln** ausführen:

```bash
cd /workspaces/DrivePulse
git pull
unzip -o DrivePulse_v0_5.zip
cd DrivePulse_v0_5
npm install
npx expo install --fix
npx expo start --tunnel --clear --port 8085
```

4. Die im Terminal angezeigte `exp://`-Adresse in Expo Go öffnen. In Expo CLI und Expo Go muss dasselbe Expo-Konto angemeldet sein.
5. **Zuerst im Stand testen:** Profil → „GPS erneut erfassen“ und angezeigte Diagnose ansehen. Für Zielsuche Straße, Hausnummer, PLZ, Ort eingeben. Danach unter Tacho die Tempolimit-Diagnose ansehen, und unabhängig davon den „€ Katalog“ testen.

Bei Problemen hilft ein Screenshot der konkreten Fehlermeldung aus App bzw. Codespaces-Terminal. Nicht als alleinige Navigation während der Fahrt verwenden.

## Quellen für die hinterlegten Regelungen / Infrastruktur

- [Bußgeldkatalog-Verordnung, Anlage (Geschwindigkeitsverstöße)](https://www.gesetze-im-internet.de/bkatv_2013/anhang.html)
- [FeV, Anlage 13 (Punkte)](https://www.gesetze-im-internet.de/fev_2010/anlage_13.html)
- [BKatV § 4 (Fahrverbote)](https://www.gesetze-im-internet.de/bkatv_2013/__4.html)
- [Expo Location](https://docs.expo.dev/versions/latest/sdk/location/)
- [OSM maxspeed](https://wiki.openstreetmap.org/wiki/Key:maxspeed)
- [Overpass API](https://wiki.openstreetmap.org/wiki/Overpass_API)
- [Nominatim Nutzungsbedingungen](https://operations.osmfoundation.org/policies/nominatim/)
- [OSRM Projekt](https://project-osrm.org/)
